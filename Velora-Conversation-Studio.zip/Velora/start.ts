import { startServer } from './server';
startServer().catch(error=>{console.error(error.message);process.exitCode=1;});
