import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { installLocalSessions } from './src/security';
import { createSimulation } from './src/service';
import { parseVeloraIntent } from './src/utils/veloraEngine';

export function createApp(options: { apiKey?:string; model?:string; fetcher?: typeof fetch } = {}) {
  const app=express();
  app.disable('x-powered-by');
  app.use((_req,res,next)=>{res.set('X-Content-Type-Options','nosniff');res.set('Referrer-Policy','no-referrer');res.set('X-Frame-Options','DENY');next();});
  app.use(express.json({limit:'128kb'}));
  installLocalSessions(app);
  const sim=createSimulation();
  const apiKey=options.apiKey?.trim();
  const configured=!!apiKey && !apiKey.startsWith('MY_');
  app.get('/api/config',(_req,res)=>res.json({provider:configured?'OPENAI':'DEMO',simulationOnly:true,voice:'device'}));
  app.get('/api/windows-service/status',(_req,res)=>res.json(sim.snapshot()));
  app.all(['/api/windows-service/client-auth-token','/api/windows-service/request-confirmation'],(_req,res)=>res.status(410).json({error:'Removed. Use the authenticated action confirmation flow.'}));
  app.post('/api/windows-service/pairing',(req,res)=>{
    if(!sim.pairing(req.body?.action)) return res.status(400).json({error:'Invalid simulation pairing action.'});
    res.json(sim.snapshot());
  });
  app.post('/api/windows-service/policy',(req,res)=>{
    if(!sim.policy(req.body?.actionId,req.body?.approved,req.body?.requiresConfirmation)) return res.status(400).json({error:'Invalid policy update.'});
    res.json(sim.snapshot());
  });
  app.post('/api/simulation/settings',(req,res)=>{
    if(!sim.settings(req.body?.screenState,req.body?.allowLockScreenPcActions)) return res.status(400).json({error:'Invalid simulation setting.'});
    res.json(sim.snapshot());
  });
  app.post('/api/windows-service/execute',(req,res)=>{
    const b=req.body||{};
    const error=sim.request(res.locals.sessionId,b.timestampMs,b.nonce);
    if(error) return res.status(400).json({error});
    if(b.authToken!==undefined) return res.status(403).json({validation:{allowed:false,status:'UNAUTHORIZED_TOKEN',reason:'Body credentials are not supported.'}});
    if(typeof b.actionId!=='string') return res.status(400).json({error:'Action required.'});
    const result=sim.execute(res.locals.sessionId,b.actionId,b.payload,b.confirmationToken);
    res.status(result.allowed?200:403).json({validation:result,executionSummary:result.executionSummary,...sim.snapshot()});
  });
  app.post('/api/actions/confirm',(req,res)=>{
    const b=req.body||{};
    const error=sim.request(res.locals.sessionId,b.timestampMs,b.nonce);
    if(error) return res.status(400).json({error});
    if(typeof b.token!=='string' || b.confirmed!==true) return res.status(400).json({error:'Explicit confirmation required.'});
    const stored=sim.pending(res.locals.sessionId,b.token);
    if(!stored) return res.status(403).json({error:'Confirmation expired or was already used.'});
    const result=sim.execute(res.locals.sessionId,stored.actionId,stored.payload,b.token);
    res.status(result.allowed?200:403).json({validation:result,executionSummary:result.executionSummary,...sim.snapshot()});
  });
  app.post('/api/actions/cancel',(req,res)=>{if(typeof req.body?.token==='string') sim.cancel(res.locals.sessionId,req.body.token);res.json({cancelled:true});});
  app.post('/api/android/execute',(req,res)=>{
    const b=req.body||{}; const error=sim.request(res.locals.sessionId,b.timestampMs,b.nonce);
    if(error) return res.status(400).json({error});
    const result=sim.android(b.actionId,b.payload);
    res.status(result.status==='FAILED'?400:200).json({...result,...sim.snapshot()});
  });
  app.post('/api/velora/command',async(req,res)=>{
    const b=req.body||{};
    const error=sim.request(res.locals.sessionId,b.timestampMs,b.nonce);
    if(error) return res.status(400).json({error});
    if(typeof b.utterance!=='string'||!b.utterance.trim()||b.utterance.length>4000) return res.status(400).json({error:'Enter a command under 4,000 characters.'});
    if(b.preferences?.wakeWord!==undefined && (typeof b.preferences.wakeWord!=='string'||b.preferences.wakeWord.length>40)) return res.status(400).json({error:'Invalid wake word.'});
    if(b.availableRoutines!==undefined && (!Array.isArray(b.availableRoutines)||b.availableRoutines.length>100)) return res.status(400).json({error:'Invalid routines.'});
    if(b.history!==undefined && (!Array.isArray(b.history)||b.history.length>24||b.history.some((m:any)=>!m||!['user','assistant'].includes(m.role)||typeof m.content!=='string'||m.content.length>4000))) return res.status(400).json({error:'Invalid conversation history.'});
    const intent=parseVeloraIntent(b.utterance,b.preferences?.wakeWord,b.availableRoutines||[]);
    const receipts:any[]=[];
    const plan=intent.orderedPlan || (intent.suggestedPcAction?[{targetDomain:'WINDOWS_PC',actionId:intent.suggestedPcAction,payload:intent.actionPayload}]:intent.suggestedAndroidAction?[{targetDomain:'ANDROID_DEVICE',actionId:intent.suggestedAndroidAction,payload:intent.actionPayload}]:[]);
    const gated=plan.length>1 && plan.some(a=>a.targetDomain==='WINDOWS_PC' && sim.snapshot().policies.find(p=>p.id===a.actionId)?.requiresConfirmation);
    if(gated) intent.clarificationMessage='This sequence includes an action requiring confirmation. Send each command separately; no steps were executed.';
    if(!gated && !intent.isNegated && !['AMBIGUOUS','UNSUPPORTED'].includes(intent.targetDomain)) {
      for(const a of plan) {
        const result=a.targetDomain==='WINDOWS_PC'?sim.execute(res.locals.sessionId,a.actionId,a.payload):sim.android(a.actionId,a.payload);
        const status=result.status;
        receipts.push({target:a.targetDomain==='WINDOWS_PC'?'WINDOWS_COMPANION_SERVICE (Simulated)':'S25_ULTRA_SYSTEM (Simulated)',actionId:a.actionId,payload:a.payload,status,summary:'reason' in result?result.reason:result.summary,confirmationToken:'newConfirmationToken' in result?result.newConfirmationToken:undefined});
        if(!['APPROVED','SIMULATED_SUCCESS'].includes(status)) break;
      }
    }
    let providerStatus=configured?'OPENAI':'DEMO';
    let spokenResponse=intent.clarificationMessage || (receipts.length?receipts.map(r=>r.summary).join(' '):intent.targetDomain==='ROUTINE_EXECUTION'?'Routine selected.':intent.targetDomain==='CAMERA_VISION'?'The vision panel contains synthetic examples. Live camera analysis is not implemented.':'I’m here. This is the local demo; configure OpenAI for open-ended conversation. You can test my voice and expressions now.');
    if(configured && !intent.clarificationMessage && !plan.length && intent.targetDomain==='GENERAL_ASSISTANT') {
      try {
        const r=await (options.fetcher||fetch)('https://api.openai.com/v1/chat/completions',{method:'POST',signal:AbortSignal.timeout(20_000),headers:{Authorization:`Bearer ${apiKey}`,'Content-Type':'application/json'},body:JSON.stringify({model:options.model||'gpt-4o-mini',messages:[{role:'system',content:'You are Velora, a helpful conversational assistant in a local prototype. Be warm. You cannot perform native phone or PC actions. Never claim to have executed them. Your avatar is a fictional character selected by the user.' + (b.preferences?.verbosity==='DETAILED'?' Give useful detail when appropriate.':' Keep replies concise.')},...(b.history||[]),{role:'user',content:b.utterance}]})});
        if(!r.ok) throw new Error(`HTTP ${r.status}`);
        const data=await r.json() as any;
        if(typeof data.choices?.[0]?.message?.content!=='string') throw new Error('Invalid response');
        spokenResponse=data.choices[0].message.content;
      } catch {providerStatus='ERROR';spokenResponse='OpenAI could not complete this request. Check your connection and API configuration. No fallback answer was substituted.';}
    }
    res.json({intent,spokenResponse,providerStatus,toolExecutionReceipts:receipts,reasoningSteps:['Local command validation',...receipts.map(r=>`${r.actionId}: ${r.status}`)],...sim.snapshot()});
  });
  app.post('/api/velora/camera-assist',(req,res)=>{
    const patterns:Record<string,[string,string,string]>={
      'win11-bsod-panel':['Gradle test log','Synthetic example of a build-memory error. No camera image has been analyzed.','CLEAR_TEMP_CACHE'],
      's25-usb-adb-bridge':['Assistant settings example','Illustrative settings screen. Device eligibility has not been verified.','GET_STATUS'],
      'workstation-thermals':['Thermal test display','Synthetic temperatures for UI testing; these are not sensor readings.','GET_STATUS'],
    };
    const p=patterns[req.body?.sceneId];
    if(!p) return res.status(400).json({error:'Select a supported synthetic scene.'});
    res.json({detectedComponent:p[0],diagnosticSummary:p[1],suggestedActionLabel:p[2],suggestedPcActionId:p[2],analysisType:'Synthetic rule only',isSyntheticTestPattern:true});
  });
  app.use('/api',(_req,res)=>res.status(404).json({error:'Unknown API endpoint.'}));
  app.use((err:any,_req:any,res:any,_next:any)=>res.status(err.type==='entity.too.large'?413:400).json({error:'Invalid request.'}));
  return app;
}

export async function startServer() {
  const dotenv=await import('dotenv');dotenv.config();
  if(process.env.HOST && !['127.0.0.1','localhost','::1'].includes(process.env.HOST)) throw new Error('This prototype supports loopback only.');
  const app=createApp({apiKey:process.env.OPENAI_API_KEY,model:process.env.OPENAI_MODEL});
  const root=path.dirname(fileURLToPath(import.meta.url));
  if(process.env.NODE_ENV==='production') {
    app.use(express.static(path.join(root,'dist')));
    app.get('*',(_req,res)=>res.sendFile(path.join(root,'dist/index.html')));
  } else {
    const {createServer}=await import('vite');
    const vite=await createServer({server:{middlewareMode:true},appType:'spa'});app.use(vite.middlewares);
  }
  const port=Number(process.env.PORT)||3000;
  return app.listen(port,'127.0.0.1',()=>console.log(`Velora local preview: http://127.0.0.1:${port}`));
}
