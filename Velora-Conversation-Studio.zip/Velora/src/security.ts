import crypto from 'node:crypto';
import type { Express, Request, Response, NextFunction } from 'express';

export function installLocalSessions(app: Express) {
  const sessions = new Map<string, { csrf: string; expires: number; window: number; count: number }>();
  app.use('/api', (req: Request, res: Response, next: NextFunction) => {
    res.set('Cache-Control', 'no-store');
    const host = req.headers.host || '';
    // This console intentionally supports loopback only. Reject DNS rebinding and cross-site requests.
    if (!/^(127\.0\.0\.1|localhost|\[::1\])(?::\d+)?$/.test(host) ||
        (req.headers.origin && req.headers.origin !== `http://${host}`) ||
        (req.headers['sec-fetch-site'] && !['same-origin', 'none'].includes(String(req.headers['sec-fetch-site'])))) {
      return res.status(403).json({ error: 'Use the local Velora console.' });
    }
    next();
  });
  app.get('/api/session', (req, res) => {
    if (req.get('X-Velora-Client') !== 'studio') return res.status(403).json({ error: 'Local client header required.' });
    const now = Date.now();
    for (const [id, s] of sessions) if (s.expires <= now) sessions.delete(id);
    const cookie = req.headers.cookie?.match(/(?:^|;\s*)velora=([a-f0-9]{64})(?:;|$)/)?.[1];
    if (cookie && sessions.has(cookie)) return res.json({ csrf: sessions.get(cookie)!.csrf });
    if (sessions.size >= 128) return res.status(429).json({ error: 'Too many local sessions. Restart the console.' });
    const id = crypto.randomBytes(32).toString('hex');
    const csrf = crypto.randomBytes(32).toString('hex');
    sessions.set(id, { csrf, expires: now + 2 * 60 * 60_000, window: now, count: 0 });
    res.cookie('velora', id, { httpOnly: true, sameSite: 'strict', maxAge: 2 * 60 * 60_000, path: '/' });
    res.json({ csrf });
  });
  app.use('/api', (req: Request, res: Response, next: NextFunction) => {
    const id = req.headers.cookie?.match(/(?:^|;\s*)velora=([a-f0-9]{64})(?:;|$)/)?.[1];
    const session = id && sessions.get(id);
    if (!session || session.expires <= Date.now()) return res.status(401).json({ error: 'Local session required.' });
    if (req.get('X-Velora-CSRF') !== session.csrf) return res.status(403).json({ error: 'Session verification failed.' });
    if (Date.now() - session.window > 60_000) { session.window = Date.now(); session.count = 0; }
    if (++session.count > 240) return res.status(429).json({ error: 'Please wait before sending more requests.' });
    res.locals.sessionId = id;
    next();
  });
}
