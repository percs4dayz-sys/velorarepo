import React, { useEffect, useRef, useState } from 'react';
import { apiFetch } from './api';
import { CommandCenterView } from './components/CommandCenterView';
import { WindowsServiceView } from './components/WindowsServiceView';
import { RoutinesAndVisionView } from './components/RoutinesAndVisionView';
import { KotlinArchitectureView } from './components/KotlinArchitectureView';
import { AvatarConversation } from './components/AvatarConversation';
import { INITIAL_ROUTINES } from './data/kotlinBlueprintData';
import { parseVeloraIntent, type VeloraRoutine, type PcActionPolicy, type RoutineExecutionReport, type StepExecutionResult } from './utils/veloraEngine';
import type { VeloraPreferences, S25UltraDeviceState, WindowsWorkstationState, ConversationTurn, AuditLogEntry } from './types/velora';

const defaults:VeloraPreferences={wakeWord:'Velora',voicePersona:'Nova-Warm',speechRate:1,verbosity:'CONCISE',allowLockScreenPcActions:false,cameraAutoOcr:false,requireBiometricForLock:false};
function readSaved<T>(key:string,fallback:T):T {try{return JSON.parse(localStorage.getItem(key)||'null')||fallback;}catch{return fallback;}}
function save(key:string,value:unknown){try{localStorage.setItem(key,JSON.stringify(value));}catch{ /* Storage may be unavailable. */ }}
type Result={allowed:boolean;status:string;reason:string;confirmationToken?:string};

export default function App(){
  const [activeTab,setActiveTab]=useState<'command'|'windows'|'routines'|'architecture'>('command');
  const [preferences,setPreferences]=useState<VeloraPreferences>(()=>({...defaults,...readSaved('velora_1_0_preferences',defaults)}));
  const [routines,setRoutines]=useState<VeloraRoutine[]>(()=>{const saved=readSaved('velora_1_0_routines',INITIAL_ROUTINES);return Array.isArray(saved)?saved:INITIAL_ROUTINES;});
  const [s25State,setS25State]=useState<S25UltraDeviceState>({batteryPercent:88,npuTempCelsius:34,screenState:'UNLOCKED',assistantRoleGranted:false,dspHotwordArmed:false,dndEnabled:false,torchEnabled:false,activeTimerSeconds:null});
  const [workstation,setWorkstation]=useState<WindowsWorkstationState>({hostname:'Demo workstation',osVersion:'Simulation',serviceVersion:'Local prototype',pairedDeviceName:'Demo S25 Ultra',pairedDeviceModel:'Simulation',isPaired:true,tokenFingerprint:'local session',isSimulated:true,locked:false,audioMuted:false,volumeLevel:64,sleepTimerSuspended:false,devEnvRunning:false,cpuLoadPercent:18,gpuTempCelsius:52,ramUsedGb:24.8,ramTotalGb:64,activeForegroundWindow:'Simulated desktop',uptimeHours:0,lastHeartbeatIso:''});
  const [policies,setPolicies]=useState<PcActionPolicy[]>([]);
  const [auditLog,setAuditLog]=useState<AuditLogEntry[]>([]);
  const [conversation,setConversation]=useState<ConversationTurn[]>([]);
  const [busy,setBusy]=useState(false);
  const [networkError,setNetworkError]=useState<string|null>(null);
  const [provider,setProvider]=useState('DEMO');
  const [pending,setPending]=useState<{token:string;label:string}|null>(null);
  const confirmationResolver=useRef<((confirmed:boolean)=>void)|null>(null);
  useEffect(()=>save('velora_1_0_preferences',preferences),[preferences]);
  useEffect(()=>save('velora_1_0_routines',routines),[routines]);
  useEffect(()=>()=>{confirmationResolver.current?.(false);},[]);
  function update(data:any){if(data.workstation)setWorkstation(data.workstation);if(data.s25State)setS25State(data.s25State);if(data.policies)setPolicies(data.policies);if(data.auditLog)setAuditLog(data.auditLog);}
  async function post(url:string,body:unknown){const res=await apiFetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const data=await res.json();update(data);return {res,data};}
  async function syncSettings(){const {res,data}=await post('/api/simulation/settings',{screenState:s25State.screenState,allowLockScreenPcActions:preferences.allowLockScreenPcActions});if(!res.ok)throw new Error(data.error);}
  useEffect(()=>{let live=true;(async()=>{try{const r=await apiFetch('/api/windows-service/status');if(!r.ok)throw new Error('Cannot load local simulation.');const data=await r.json();if(live)update(data);const cfg=await apiFetch('/api/config');const c=await cfg.json();if(live)setProvider(c.provider||'DEMO');}catch(e){if(live)setNetworkError(String(e));}})();return()=>{live=false;};},[]);
  async function confirmToken(token:string):Promise<Result>{
    const {res,data}=await post('/api/actions/confirm',{token,confirmed:true});
    return {allowed:!!data.validation?.allowed,status:data.validation?.status||'FAILED',reason:data.executionSummary||data.error||`Request failed (${res.status})`};
  }
  function askConfirmation(token:string,label:string):Promise<boolean>{
    if(confirmationResolver.current)return Promise.resolve(false);
    setPending({token,label});return new Promise(resolve=>{confirmationResolver.current=resolve;});
  }
  function resolveConfirmation(yes:boolean){const resolve=confirmationResolver.current;confirmationResolver.current=null;setPending(null);resolve?.(yes);}
  async function executePc(params:{actionId:string;useInvalidToken?:boolean;useReplayNonce?:boolean;confirmationToken?:string;confirmedByUser?:boolean;payload?:Record<string,unknown>}):Promise<Result>{
    try{
      await syncSettings();
      if(params.confirmationToken)return await confirmToken(params.confirmationToken);
      const payload=params.payload ?? (params.actionId==='SUSPEND_SLEEP_TIMER'?{suspend:true}:undefined);
      const {data}=await post('/api/windows-service/execute',{actionId:params.actionId,payload,...(params.useInvalidToken?{authToken:'invalid-probe'}:{}),...(params.useReplayNonce?{nonce:'static_replay_nonce_probe_001'}:{})});
      if(data.validation?.status==='CONFIRMATION_REQUIRED'&&data.validation.newConfirmationToken){
        const token=data.validation.newConfirmationToken;
        const yes=await askConfirmation(token,`${params.actionId}${payload?' '+JSON.stringify(payload):''}`);
        if(yes)return await confirmToken(token);
        await post('/api/actions/cancel',{token});return {allowed:false,status:'CANCELLED',reason:'Cancelled. No action taken.'};
      }
      return {allowed:!!data.validation?.allowed,status:data.validation?.status||'FAILED',reason:data.executionSummary||data.error||'Action rejected.'};
    }catch(e){setNetworkError(String(e));return {allowed:false,status:'FAILED',reason:'Connection failed; execution is not confirmed.'};}
  }
  async function executeRoutine(routine:VeloraRoutine):Promise<RoutineExecutionReport>{
    const start=performance.now();const stepResults:StepExecutionResult[]=[];let stopped=false;
    for(const step of routine.steps){
      const at=performance.now();let status:StepExecutionResult['status']='SKIPPED';let message=stopped?'Not run after a failed or cancelled step.':'Disabled step.';
      if(step.enabled&&!stopped){
        if(step.target==='WINDOWS_11_PC'){
          const r=await executePc({actionId:step.commandKey,payload:step.payload});status=r.allowed?'SUCCESS':r.status==='CANCELLED'?'SKIPPED':'DENIED';message=r.reason;if(!r.allowed)stopped=true;
        }else{
          const payload=step.payload??(step.commandKey==='SET_DND_MODE'?{enabled:true}:undefined);
          try{const {res,data}=await post('/api/android/execute',{actionId:step.commandKey,payload});status=res.ok?'SUCCESS':'FAILED';message=data.summary||data.error||'Unsupported phone action.';if(!res.ok)stopped=true;}catch{status='FAILED';message='Connection failed.';stopped=true;}
        }
      }
      stepResults.push({stepId:step.id,target:step.target,commandKey:step.commandKey,actionLabel:step.actionLabel,status,measuredDurationMs:Math.round(performance.now()-at),message});
    }
    const successes=stepResults.filter(s=>s.status==='SUCCESS').length;
    const complete=stepResults.every((s,i)=>s.status==='SUCCESS'||!routine.steps[i].enabled);
    const status=complete&&successes?'COMPLETED':successes?'PARTIAL_SUCCESS':'FAILED';
    const report:RoutineExecutionReport={routineId:routine.id,routineName:routine.name,status,stepResults,totalMeasuredMs:Math.round(performance.now()-start),summaryMessage:`Simulation: ${routine.name} — ${status.toLowerCase().replaceAll('_',' ')}. ${successes} of ${routine.steps.filter(s=>s.enabled).length} enabled steps succeeded.`};
    setRoutines(prev=>prev.map(r=>r.id===routine.id?{...r,lastRunAt:`${status} ${new Date().toLocaleTimeString()}`}:r));
    addTurn(routine.voiceTrigger,report.summaryMessage,parseVeloraIntent(routine.voiceTrigger,preferences.wakeWord,routines));
    return report;
  }
  function addTurn(utterance:string,spokenResponse:string,intent:ReturnType<typeof parseVeloraIntent>,receipts:any[]=[]){setConversation(prev=>[{id:crypto.randomUUID(),timestamp:new Date().toLocaleTimeString(),userUtterance:utterance,spokenResponse,intent,reasoningSteps:[],toolExecutionReceipts:receipts},...prev].slice(0,50));}
  async function send(utterance:string){
    if(busy)return;setBusy(true);setNetworkError(null);
    try{
      await syncSettings();
      const history=conversation.slice(0,8).reverse().flatMap(t=>[{role:'user',content:t.userUtterance.slice(0,4000)},{role:'assistant',content:t.spokenResponse.slice(0,4000)}]);
      const {res,data}=await post('/api/velora/command',{utterance,preferences,availableRoutines:routines,history});
      if(!res.ok)throw new Error(data.error||'Command failed.');
      if(data.intent?.targetDomain==='ROUTINE_EXECUTION'){
        const routine=routines.find(r=>r.id===data.intent.suggestedRoutineId);
        if(routine){await executeRoutine(routine);return;}
        data.spokenResponse='That routine is not available. No action taken.';
      }
      if(data.providerStatus)setProvider(data.providerStatus);
      addTurn(utterance,data.spokenResponse,data.intent,data.toolExecutionReceipts);
    }catch(e){setNetworkError(e instanceof Error?e.message:String(e));}finally{setBusy(false);}
  }
  async function confirmReceipt(actionId:string,token:string){
    const result=await executePc({actionId,confirmationToken:token});
    setConversation(prev=>prev.map(t=>({...t,toolExecutionReceipts:t.toolExecutionReceipts?.map(r=>r.confirmationToken===token?{...r,status:result.status,summary:result.reason,confirmationToken:undefined}:r)})));
    addTurn(`Confirm ${actionId}`,result.reason,parseVeloraIntent('confirmation'));
  }
  async function pairing(action:'ROTATE_TOKEN'|'TOGGLE_PAIRING'|'UNLOCK_WORKSTATION'){try{const {res,data}=await post('/api/windows-service/pairing',{action});if(!res.ok)throw new Error(data.error);}catch(e){setNetworkError(String(e));}}
  return <div className="min-h-screen bg-[#0B0F17] text-slate-100">
    <header className="studio-header"><a href="#" onClick={e=>{e.preventDefault();setActiveTab('command');}} className="studio-brand"><span>VELORA</span><small>YOUR CONVERSATION SPACE</small></a><nav aria-label="Main navigation">{([{id:'command',label:'Conversation'},{id:'windows',label:'PC sandbox'},{id:'routines',label:'Routines'},{id:'architecture',label:'Blueprints'}] as const).map(tab=><button key={tab.id} aria-current={activeTab===tab.id?'page':undefined} onClick={()=>setActiveTab(tab.id)}>{tab.label}</button>)}</nav><span className="local-badge">LOCAL PROTOTYPE</span></header>
    <main className="max-w-[1360px] mx-auto px-4 sm:px-6 py-6">
      {networkError&&<div role="alert" className="mb-4 p-4 rounded-xl bg-red-950 text-red-100">{networkError}<button className="ml-4 underline" onClick={()=>setNetworkError(null)}>Dismiss</button></div>}
      {activeTab==='command'&&<><AvatarConversation conversation={conversation} busy={busy} provider={provider} speechRate={preferences.speechRate} onSend={send} onConfirm={confirmReceipt}/><details className="mt-8"><summary className="text-slate-400 cursor-pointer mb-4">Open simulation diagnostics</summary><CommandCenterView workstation={workstation} s25State={s25State} setS25State={setS25State} preferences={preferences} conversation={conversation} onSendVoiceCommand={send} isProcessingCommand={busy} sessionPhase={busy?'TOOL_DISPATCHING':'DSP_STANDBY'} onNavigateTab={setActiveTab} onConfirmPendingAction={confirmReceipt}/></details></>}
      {activeTab==='windows'&&<WindowsServiceView workstation={workstation} policies={policies} auditLog={auditLog} onExecutePcAction={executePc} onPairingAction={pairing} onTogglePolicy={async(actionId,updates)=>{const {res,data}=await post('/api/windows-service/policy',{actionId,...updates});if(!res.ok)setNetworkError(data.error);}}/>}
      {activeTab==='routines'&&<RoutinesAndVisionView routines={routines} setRoutines={setRoutines} isWindowsPaired={workstation.isPaired} onExecuteRoutine={executeRoutine} preferences={preferences} setPreferences={setPreferences} onExecuteRecommendedPcAction={async actionId=>{const result=await executePc({actionId});if(!result.allowed)throw new Error(result.reason);}}/>}
      {activeTab==='architecture'&&<KotlinArchitectureView/>}
    </main><footer className="studio-footer">Avatar & voice preview · Phone and PC actions are simulations · Native Android app still to be built</footer>
    {activeTab!=='command'&&<button className="avatar-bubble" aria-label="Open Velora conversation" onClick={()=>setActiveTab('command')}><img src="/avatar/mouth-0.jpg" alt=""/><span>Let’s talk</span></button>}
    {pending&&<div className="confirmation-backdrop"><section role="dialog" aria-modal="true" aria-labelledby="confirm-heading" className="confirmation-card"><h2 id="confirm-heading">Confirm this simulated action?</h2><p>{pending.label}</p><p>This approval expires in 60 seconds and can be used once.</p><div><button autoFocus onClick={()=>resolveConfirmation(false)}>Cancel</button><button onClick={()=>resolveConfirmation(true)}>Confirm action</button></div></section></div>}
  </div>;
}
