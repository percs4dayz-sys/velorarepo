import type {
  PcActionPolicy,
  ParsedVeloraIntent,
  StepExecutionResult,
} from '../utils/veloraEngine';

export interface WindowsWorkstationState {
  hostname: string;
  osVersion: string;
  serviceVersion: string;
  pairedDeviceName: string;
  pairedDeviceModel: string;
  isPaired: boolean;
  tokenFingerprint: string;
  activeToken?: string;
  isSimulated?: boolean;
  locked: boolean;
  audioMuted: boolean;
  volumeLevel: number;
  sleepTimerSuspended: boolean;
  devEnvRunning: boolean;
  cpuLoadPercent: number;
  gpuTempCelsius: number;
  ramUsedGb: number;
  ramTotalGb: number;
  activeForegroundWindow: string;
  uptimeHours: number;
  lastHeartbeatIso: string;
}

export interface AuditLogEntry {
  id: string;
  timestampIso: string;
  source: string;
  actionId: string;
  allowed: boolean;
  status: string;
  auditCode: string;
  detail: string;
  latencyMs: number;
}

export interface VeloraPreferences {
  wakeWord: string;
  voicePersona: 'Alloy-Tactical' | 'Echo-Executive' | 'Nova-Warm';
  speechRate: number;
  verbosity: 'CONCISE' | 'DETAILED';
  allowLockScreenPcActions: boolean;
  cameraAutoOcr: boolean;
  requireBiometricForLock: boolean;
}

export interface S25UltraDeviceState {
  batteryPercent: number;
  npuTempCelsius: number;
  screenState: 'SCREEN_OFF' | 'LOCK_SCREEN' | 'UNLOCKED';
  assistantRoleGranted: boolean;
  dspHotwordArmed: boolean;
  dndEnabled: boolean;
  torchEnabled: boolean;
  activeTimerSeconds: number | null;
}

export interface ToolReceipt {
  target: string;
  actionId: string;
  status: string;
  summary: string;
  confirmationToken?: string;
}

export interface ConversationTurn {
  id: string;
  timestamp: string;
  userUtterance: string;
  spokenResponse: string;
  intent: ParsedVeloraIntent;
  reasoningSteps: string[];
  toolExecutionReceipts?: ToolReceipt[];
  // Legacy singular receipt compatibility
  toolExecutionReceipt?: ToolReceipt | null;
}

export interface WindowsServiceSnapshot {
  workstation: WindowsWorkstationState;
  policies: PcActionPolicy[];
  auditLog: AuditLogEntry[];
}

export interface RoutineRunHistory {
  routineId: string;
  timestamp: string;
  status: 'COMPLETED' | 'PARTIAL_SUCCESS' | 'FAILED';
  summary: string;
  stepResults: StepExecutionResult[];
}
