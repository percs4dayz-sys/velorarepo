import crypto from 'node:crypto';
import { validateWindowsServiceCommand, type PcActionPolicy, type PcActionId } from './utils/veloraEngine';
import { validPayload } from './utils/payloads';

export function createSimulation() {
  const workstation = { hostname: 'Demo workstation', osVersion: 'Windows simulation', serviceVersion: 'Local prototype', pairedDeviceName: 'Demo S25 Ultra', pairedDeviceModel: 'Android simulation', isPaired: true, tokenFingerprint: 'local session', isSimulated: true, locked: false, audioMuted: false, volumeLevel: 64, sleepTimerSuspended: false, devEnvRunning: false, cpuLoadPercent: 18, gpuTempCelsius: 52, ramUsedGb: 24.8, ramTotalGb: 64, activeForegroundWindow: 'Simulated desktop', uptimeHours: 0, lastHeartbeatIso: new Date().toISOString() };
  const phone = { batteryPercent: 88, npuTempCelsius: 34, screenState: 'UNLOCKED' as 'UNLOCKED'|'LOCK_SCREEN'|'SCREEN_OFF', assistantRoleGranted: false, dspHotwordArmed: false, dndEnabled: false, torchEnabled: false, activeTimerSeconds: null as number|null };
  let allowLockScreenPcActions = false;
  const definitions: [PcActionId,string,PcActionPolicy['category'],boolean][] = [
    ['GET_STATUS','Read demo status','TELEMETRY',false], ['LOCK_WORKSTATION','Lock demo workstation','SESSION_CONTROL',true],
    ['MUTE_AUDIO','Mute demo PC','MEDIA',false], ['UNMUTE_AUDIO','Unmute demo PC','MEDIA',false], ['SET_VOLUME','Set demo PC volume','MEDIA',false],
    ['LAUNCH_DEVELOPMENT_ENV','Launch demo workspace','WORKFLOW',false], ['SUSPEND_SLEEP_TIMER','Set demo keep-awake','SESSION_CONTROL',false],
    ['CLEAR_TEMP_CACHE','Clear demo build cache','WORKFLOW',true], ['RAW_POWERSHELL_EXEC','Arbitrary shell (blocked)','RESTRICTED',true],
  ];
  let policies: PcActionPolicy[] = definitions.map(([id,label,category,requiresConfirmation]) => ({ id,label,category,requiresConfirmation,approved:category!=='RESTRICTED',endpoint:'/api/windows-service/execute',description:'Simulation only. No operating-system commands are executed.' }));
  const auditLog: any[] = [];
  const nonces = new Map<string,number>();
  const confirmations = new Map<string,{actionId:string;payload?:Record<string,unknown>;expiresAt:number;sessionId:string}>();
  function sweep() { const now=Date.now(); for(const [n,t] of nonces) if(t<=now) nonces.delete(n); for(const [n,c] of confirmations) if(c.expiresAt<=now) confirmations.delete(n); }
  function audit(actionId:string, status:string, detail:string, latencyMs:number) {
    auditLog.unshift({id:crypto.randomUUID(),timestampIso:new Date().toISOString(),source:'Local simulation console',actionId,allowed:status==='APPROVED',status,auditCode:status,detail,latencyMs});
    auditLog.splice(50);
  }
  function snapshot() { return {workstation:{...workstation},s25State:{...phone},policies:policies.map(p=>({...p})),auditLog:[...auditLog]}; }
  function request(sessionId:string, timestampMs:unknown, nonce:unknown) {
    sweep();
    if(typeof timestampMs!=='number' || !Number.isSafeInteger(timestampMs) || Math.abs(Date.now()-timestampMs)>30_000) return 'Invalid or expired request timestamp.';
    if(typeof nonce!=='string' || !/^[a-zA-Z0-9_-]{8,100}$/.test(nonce)) return 'A unique nonce is required.';
    const scoped=sessionId+':'+nonce;
    if(nonces.has(scoped)) return 'Duplicate request rejected.';
    if(nonces.size>=4096) return 'Request limit reached. Please wait.';
    nonces.set(scoped,Date.now()+60_000);
    return null;
  }
  function execute(sessionId:string, actionId:string, payload?:Record<string,unknown>, confirmationToken?:string) {
    sweep();
    const start=performance.now();
    if(!validPayload(actionId,payload)) return {allowed:false,status:'INVALID_PAYLOAD',reason:'Missing or invalid action arguments.',executionSummary:'No action taken.'};
    const validation=validateWindowsServiceCommand({actionId,authToken:sessionId,expectedToken:sessionId,isDevicePaired:workstation.isPaired,timestampMs:Date.now(),nowMs:Date.now(),nonce:crypto.randomUUID(),seenNonces:new Set(),policies,payload,confirmationToken,validConfirmationTokens:confirmations,s25ScreenState:phone.screenState,allowLockScreenPcActions});
    let reason=validation.reason;
    let newConfirmationToken:string|undefined;
    if(validation.status==='CONFIRMATION_REQUIRED' && confirmations.size<256) {
      newConfirmationToken=crypto.randomUUID();
      confirmations.set(newConfirmationToken,{actionId,payload:payload?structuredClone(payload):undefined,sessionId,expiresAt:Date.now()+60_000});
    }
    if(validation.allowed) {
      switch(actionId) {
        case 'LOCK_WORKSTATION': workstation.locked=true; workstation.activeForegroundWindow='Simulated lock screen'; break;
        case 'MUTE_AUDIO': workstation.audioMuted=true; break;
        case 'UNMUTE_AUDIO': workstation.audioMuted=false; break;
        case 'SET_VOLUME': workstation.volumeLevel=payload!.volume as number; workstation.audioMuted=payload!.volume===0; break;
        case 'SUSPEND_SLEEP_TIMER': workstation.sleepTimerSuspended=payload!.suspend as boolean; break;
        case 'LAUNCH_DEVELOPMENT_ENV': workstation.devEnvRunning=true; break;
        case 'CLEAR_TEMP_CACHE': break; // Do not fabricate memory recovery from disk cleanup.
      }
      workstation.lastHeartbeatIso=new Date().toISOString();
      const messages:Record<string,string>={GET_STATUS:`Demo PC: CPU ${workstation.cpuLoadPercent}%, GPU ${workstation.gpuTempCelsius}°C, volume ${workstation.volumeLevel}%.`,LOCK_WORKSTATION:'Demo workstation locked.',MUTE_AUDIO:'Demo PC audio muted.',UNMUTE_AUDIO:'Demo PC audio unmuted.',SET_VOLUME:`Demo PC volume set to ${workstation.volumeLevel} percent.`,SUSPEND_SLEEP_TIMER:workstation.sleepTimerSuspended?'Demo PC will stay awake.':'Demo PC sleep settings restored.',LAUNCH_DEVELOPMENT_ENV:'Demo development workspace opened.',CLEAR_TEMP_CACHE:'Demo cache-cleanup step completed. No files were deleted.'};
      reason=messages[actionId];
    }
    audit(actionId,validation.status,reason,Math.round(performance.now()-start));
    return {...validation,reason,executionSummary:reason,newConfirmationToken};
  }
  function android(actionId:string,payload?:Record<string,unknown>) {
    if(!['SET_TIMER','SET_DND_MODE','TOGGLE_TORCH','GET_PHONE_TELEMETRY'].includes(actionId) || !validPayload(actionId,payload)) return {status:'FAILED',summary:'Unsupported phone action or invalid arguments.'};
    if(actionId==='SET_TIMER') phone.activeTimerSeconds=Number(payload!.durationSeconds);
    if(actionId==='SET_DND_MODE') phone.dndEnabled=Boolean(payload!.enabled);
    if(actionId==='TOGGLE_TORCH') phone.torchEnabled=Boolean(payload!.enabled);
    const messages:Record<string,string>={SET_TIMER:`Demo timer set to ${phone.activeTimerSeconds} seconds.`,SET_DND_MODE:`Demo phone: Do Not Disturb is ${phone.dndEnabled?'on':'off'}.`,TOGGLE_TORCH:`Demo flashlight is ${phone.torchEnabled?'on':'off'}.`,GET_PHONE_TELEMETRY:`Demo phone battery: ${phone.batteryPercent} percent. This is a sample reading.`};
    return {status:'SIMULATED_SUCCESS',summary:messages[actionId]};
  }
  function policy(actionId:string,approved:unknown,requiresConfirmation:unknown) {
    const p=policies.find(p=>p.id===actionId);
    if(!p || p.category==='RESTRICTED') return false;
    if(approved!==undefined && typeof approved!=='boolean' || requiresConfirmation!==undefined && typeof requiresConfirmation!=='boolean') return false;
    if(approved!==undefined) p.approved=approved as boolean;
    if(requiresConfirmation!==undefined) p.requiresConfirmation=requiresConfirmation as boolean;
    confirmations.clear();
    return true;
  }
  function pairing(action:string) {
    if(action==='TOGGLE_PAIRING') workstation.isPaired=!workstation.isPaired;
    else if(action==='UNLOCK_WORKSTATION') {workstation.locked=false;workstation.activeForegroundWindow='Simulated desktop';}
    else if(action!=='ROTATE_TOKEN') return false;
    confirmations.clear();
    audit(action,'APPROVED','Simulation updated; pending confirmations revoked.',0);
    return true;
  }
  function settings(screen:unknown,allow:unknown) {
    if(screen!==undefined && !['UNLOCKED','LOCK_SCREEN','SCREEN_OFF'].includes(String(screen))) return false;
    if(allow!==undefined && typeof allow!=='boolean') return false;
    if(screen!==undefined) phone.screenState=screen as typeof phone.screenState;
    if(allow!==undefined) allowLockScreenPcActions=allow as boolean;
    return true;
  }
  function pending(sessionId:string,token:string) { sweep(); const c=confirmations.get(token); return c?.sessionId===sessionId ? c : undefined; }
  function cancel(sessionId:string,token:string) { if(pending(sessionId,token)) confirmations.delete(token); }
  return {snapshot,request,execute,android,policy,pairing,settings,pending,cancel};
}
