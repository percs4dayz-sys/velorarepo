export function canonical(value: unknown): string {
  if (value == null) return '{}';
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (typeof value === 'object') return `{${Object.keys(value).sort().map(k => `${JSON.stringify(k)}:${canonical((value as Record<string, unknown>)[k])}`).join(',')}}`;
  return JSON.stringify(value);
}

export function validPayload(action: string, payload: unknown): boolean {
  if (payload !== undefined && (payload === null || typeof payload !== 'object' || Array.isArray(payload))) return false;
  const p = (payload || {}) as Record<string, unknown>;
  const keys = Object.keys(p);
  const one = (key: string) => keys.length === 1 && keys[0] === key;
  switch (action) {
    case 'SET_VOLUME': return one('volume') && Number.isInteger(p.volume) && Number(p.volume) >= 0 && Number(p.volume) <= 100;
    case 'SUSPEND_SLEEP_TIMER': return one('suspend') && typeof p.suspend === 'boolean';
    case 'SET_TIMER': return one('durationSeconds') && Number.isInteger(p.durationSeconds) && Number(p.durationSeconds) > 0 && Number(p.durationSeconds) <= 86400;
    case 'SET_DND_MODE': case 'TOGGLE_TORCH': return one('enabled') && typeof p.enabled === 'boolean';
    default: return keys.length === 0;
  }
}
