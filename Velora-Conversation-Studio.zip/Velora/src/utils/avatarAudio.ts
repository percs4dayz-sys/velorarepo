export function mouthFrame(rms:number,gain=1):number {
  const energy=Number.isFinite(rms)?Math.max(0,rms)*gain:0;
  if(energy<0.012)return 0;
  if(energy<0.045)return 1;
  if(energy<0.11)return 2;
  return 3;
}
export function rms(samples:Float32Array):number {
  if(!samples.length)return 0;
  return Math.sqrt(samples.reduce((sum,x)=>sum+x*x,0)/samples.length);
}
