import type { VeloraRoutine, ParsedVeloraIntent, SubActionIntent } from './veloraEngine';

export function parseCommand(utterance: string, wakeWord = 'Velora', routines: VeloraRoutine[] = []): ParsedVeloraIntent {
  const raw = typeof utterance === 'string' ? utterance.trim() : '';
  const word = typeof wakeWord === 'string' && wakeWord.trim() ? wakeWord.trim() : 'Velora';
  const escaped = word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const prefix = new RegExp(`^(?:hey\\s+)?${escaped}(?=[,\\s]|$)[,\\s]*`, 'i');
  const query = raw.replace(prefix, '').trim();
  const q = query.toLowerCase().replace(/[.!?]+$/, '').replace(/^please\s+/, '');
  const base = { wakeWordDetected: prefix.test(raw), normalizedQuery: query, confidence: 0 };
  const clarify = (message: string): ParsedVeloraIntent => ({ ...base, targetDomain: 'AMBIGUOUS', clarificationMessage: message });
  const unsupported = (message: string): ParsedVeloraIntent => ({ ...base, targetDomain: 'UNSUPPORTED', clarificationMessage: message });
  const android = (action: string, payload?: Record<string, unknown>): ParsedVeloraIntent => ({ ...base, targetDomain: 'ANDROID_DEVICE', suggestedAndroidAction: action, actionPayload: payload });
  const pc = (action: any, payload?: Record<string, unknown>): ParsedVeloraIntent => ({ ...base, targetDomain: 'WINDOWS_PC', suggestedPcAction: action, actionPayload: payload });
  if (!q) return clarify('Please enter a command.');
  if (/^(explain|how|what|why|can you explain|tell me|is |does |would |could )/.test(q)) return { ...base, targetDomain: 'GENERAL_ASSISTANT' };
  // The feature name is not a negation. Never execute a negated instruction.
  const negationText = q.replace(/do not disturb/g, 'dnd');
  if (/\b(do not|don't|dont|never|avoid|cancel)\b/.test(negationText)) return { ...base, targetDomain: 'AMBIGUOUS', isNegated: true, clarificationMessage: 'No action taken.' };
  if (/\b(unlock|powershell|cmd\.exe|regedit|format|delete all)\b/.test(q)) return unsupported('That action is not supported. Unlock the PC directly using its PIN or Windows Hello.');
  if (/\balarm\b/.test(q)) return unsupported('Clock alarms are not implemented. You can set a countdown timer with a duration.');
  for (const r of routines) {
    if (typeof r?.voiceTrigger !== 'string' || typeof r?.name !== 'string') continue;
    if ([r.voiceTrigger.replace(prefix, '').trim().toLowerCase(), r.name.toLowerCase()].includes(q)) return { ...base, targetDomain: 'ROUTINE_EXECUTION', suggestedRoutineId: r.id };
  }
  const builtins: Record<string,string> = { 'start deep work': 'routine-deep-work', 'start deep work mode': 'routine-deep-work', 'morning briefing': 'routine-morning-briefing', 'lockdown protocol': 'routine-shutdown', 'initiate lockdown protocol': 'routine-shutdown' };
  if (builtins[q]) return { ...base, targetDomain: 'ROUTINE_EXECUTION', suggestedRoutineId: builtins[q] };
  // Do not split a duration such as "1 hour and 30 minutes".
  const splitQuery = q.replace(/(\d+\s*(?:hours?|hrs?|minutes?|mins?))\s+and\s+(?=\d+\s*(?:minutes?|mins?|seconds?|secs?))/g, '$1 ');
  const parts = splitQuery.split(/\s+(?:and then|then|and)\s+|,\s*/).filter(Boolean);
  if (parts.length > 1) {
    const parsed = parts.map(part => parseCommand(part, word, routines));
    if (parsed.some(p => !p.suggestedPcAction && !p.suggestedAndroidAction)) return clarify('I could not validate every step. Please enter each command separately; no steps were executed.');
    const orderedPlan: SubActionIntent[] = parsed.map(p => ({ targetDomain: p.targetDomain as 'WINDOWS_PC'|'ANDROID_DEVICE', actionId: p.suggestedPcAction || p.suggestedAndroidAction!, payload: p.actionPayload, label: p.normalizedQuery }));
    return { ...base, targetDomain: 'GENERAL_ASSISTANT', orderedPlan };
  }
  const phone = /\b(phone|android|s25)\b/.test(q);
  const pcContext = /\b(pc|computer|workstation|desktop|windows|gpu|cpu)\b/.test(q);
  if (phone && /\b(volume|mute|unmute|lock|sleep)\b/.test(q)) return unsupported('That phone action is not implemented. No PC action was substituted.');
  if (/\b(timer|countdown)\b/.test(q)) {
    if (!/^(set|start)\b/.test(q)) return clarify('To start a timer, specify a duration, for example “set a 10 minute timer”.');
    const matches = [...q.matchAll(/(\d+)\s*(hours?|hrs?|minutes?|mins?|seconds?|secs?)\b/g)];
    const durationSeconds = matches.reduce((sum,m) => sum + Number(m[1]) * (/^h/.test(m[2]) ? 3600 : /^m/.test(m[2]) ? 60 : 1), 0);
    if (!durationSeconds || durationSeconds > 86400) return clarify('Choose a timer duration between 1 second and 24 hours.');
    return android('SET_TIMER', { durationSeconds });
  }
  if (/\b(do not disturb|dnd|flashlight|torch)\b/.test(q)) {
    const off = /^(disable|turn off|switch off)\b/.test(q);
    const on = /^(enable|turn on|switch on)\b/.test(q);
    if (!off && !on) return clarify('Please say whether to turn this feature on or off.');
    return android(/do not disturb|\bdnd\b/.test(q) ? 'SET_DND_MODE' : 'TOGGLE_TORCH', { enabled: on });
  }
  if (phone && /^(check|show|get)\b/.test(q) && /battery|status/.test(q)) return android('GET_PHONE_TELEMETRY');
  if (pcContext) {
    if (/^lock\b/.test(q)) return pc('LOCK_WORKSTATION');
    if (/^unmute\b/.test(q)) return pc('UNMUTE_AUDIO');
    if (/^mute\b/.test(q)) return pc('MUTE_AUDIO');
    if (/^(set|adjust|change)\b/.test(q) && /\bvolume\b/.test(q)) {
      const m = q.match(/volume\s+(?:(?:to|at)\s+)?(\d{1,3})(?:\s*(?:%|percent))?$/);
      if (!m || Number(m[1]) > 100) return clarify('Specify a PC volume from 0 to 100 percent.');
      return pc('SET_VOLUME', { volume: Number(m[1]) });
    }
    if (/^(keep|prevent|suspend)\b/.test(q) && /awake|sleep/.test(q)) return pc('SUSPEND_SLEEP_TIMER', { suspend: true });
    if (/^(allow|restore|enable)\b/.test(q) && /sleep/.test(q)) return pc('SUSPEND_SLEEP_TIMER', { suspend: false });
    if (/^(launch|start|open)\b/.test(q) && /studio|development|workspace|ide/.test(q)) return pc('LAUNCH_DEVELOPMENT_ENV');
    if (/^(purge|clear|clean)\b/.test(q) && /cache|temp/.test(q)) return pc('CLEAR_TEMP_CACHE');
    if (/^(check|show|get|report)\b/.test(q) && /status|temperature|telemetry|gpu|cpu|ram/.test(q)) return pc('GET_STATUS');
    return clarify('I could not validate that PC command. No action taken.');
  }
  if (/^(set|mute|unmute|lock|keep|allow|turn|enable|disable|start|run|clear|purge)\b/.test(q)) return clarify('Please specify a supported action and its target device.');
  if (/camera|viewfinder|inspect/.test(q)) return { ...base, targetDomain: 'CAMERA_VISION' };
  return { ...base, targetDomain: 'GENERAL_ASSISTANT' };
}
