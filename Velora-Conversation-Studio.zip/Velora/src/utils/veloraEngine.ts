import { canonical } from './payloads';
export type Android16Route =
  | 'STANDARD_MIC_PERMISSION'
  | 'FOREGROUND_SERVICE_MIC'
  | 'VOICE_INTERACTION_SERVICE_DSP';

export type ScreenState = 'SCREEN_OFF' | 'LOCK_SCREEN' | 'UNLOCKED';
export type AppProcessState = 'CACHED_BACKGROUND' | 'FOREGROUND_SERVICE' | 'TOP_ACTIVITY';

export interface Android16PolicyResult {
  canListenForWakeWord: boolean;
  canStartMicSession: boolean;
  survivesSamsungDoze: boolean;
  verdict:
    | 'SUPPORTED_ROLE_SERVICE_WITH_RESERVATIONS'
    | 'BLOCKED_BY_ANDROID_16'
    | 'UNRELIABLE_OEM_KILL';
  technicalReason: string;
  hardwareRealityNotice: string;
  requiredComponents: string[];
}

/**
 * Evaluates Android 16 (API 36) & Samsung One UI 8 microphone and foreground-service
 * startup rules on the Galaxy S25 Ultra with realistic hardware feasibility notes.
 */
export function evaluateAndroid16MicPolicy(params: {
  route: Android16Route;
  screenState: ScreenState;
  processState: AppProcessState;
  isDefaultDigitalAssistant: boolean;
}): Android16PolicyResult {
  const { route, screenState, processState, isDefaultDigitalAssistant } = params;

  if (route === 'STANDARD_MIC_PERMISSION') {
    const isTop = processState === 'TOP_ACTIVITY' && screenState === 'UNLOCKED';
    return {
      canListenForWakeWord: isTop,
      canStartMicSession: isTop,
      survivesSamsungDoze: false,
      verdict: isTop ? 'UNRELIABLE_OEM_KILL' : 'BLOCKED_BY_ANDROID_16',
      technicalReason: isTop
        ? 'This model assumes foreground microphone use. Actual eligibility depends on permissions, app state and platform rules; no device check is performed.'
        : 'Background microphone use requires a supported execution route and applicable permissions; this simplified model does not determine runtime eligibility.',
      hardwareRealityNotice:
        'Standard mic permission cannot provide an always-listening screen-off assistant.',
      requiredComponents: ['android.permission.RECORD_AUDIO'],
    };
  }

  if (route === 'FOREGROUND_SERVICE_MIC') {
    const startedFromVisible = processState === 'TOP_ACTIVITY';
    const screenOff = screenState === 'SCREEN_OFF';
    if (!startedFromVisible) {
      return {
        canListenForWakeWord: false,
        canStartMicSession: false,
        survivesSamsungDoze: false,
        verdict: 'BLOCKED_BY_ANDROID_16',
        technicalReason:
          'Android 14–16 throws ForegroundServiceStartNotAllowedException when starting a microphone FGS from background/boot without an active window.',
        hardwareRealityNotice:
          'No device testing has been performed. This workbench cannot determine runtime eligibility.',
        requiredComponents: [
          'android.permission.FOREGROUND_SERVICE_MICROPHONE',
          'android.permission.RECORD_AUDIO',
        ],
      };
    }
    return {
      canListenForWakeWord: !screenOff,
      canStartMicSession: !screenOff,
      survivesSamsungDoze: false,
      verdict: 'UNRELIABLE_OEM_KILL',
      technicalReason:
        'Microphone foreground-service eligibility depends on permissions, launch context and documented exemptions. Screen-off behavior and power use require on-device testing.',
      hardwareRealityNotice:
        'Battery use and lifecycle behavior require measurement on the target phone.',
      requiredComponents: [
        'android.permission.FOREGROUND_SERVICE_MICROPHONE',
        'Persistent Notification',
      ],
    };
  }

  // VOICE_INTERACTION_SERVICE_DSP
  if (!isDefaultDigitalAssistant) {
    return {
      canListenForWakeWord: false,
      canStartMicSession: false,
      survivesSamsungDoze: false,
      verdict: 'BLOCKED_BY_ANDROID_16',
      technicalReason:
        'VoiceInteractionService requires the user to select Velora as the Default Digital Assistant app (RoleManager.ROLE_ASSISTANT) in Android Settings.',
      hardwareRealityNotice:
        'Without ROLE_ASSISTANT, the Android system server will not bind VoiceInteractionService or allow showSession().',
      requiredComponents: [
        'android.service.voice.VoiceInteractionService',
        'RoleManager.ROLE_ASSISTANT granted',
      ],
    };
  }

  return {
    canListenForWakeWord: false,
    canStartMicSession: true,
    survivesSamsungDoze: false,
    verdict: 'SUPPORTED_ROLE_SERVICE_WITH_RESERVATIONS',
    technicalReason:
      'VoiceInteractionService is the officially supported Android route. Assistant binding, invocation and microphone access must be implemented and verified on-device.',
    hardwareRealityNotice:
      'UNVERIFIED: The default-assistant role does not establish access to system hotword APIs or a supported enrolled sound model. Validate the stock Galaxy S25 Ultra before promising custom wake words. Start with push-to-talk.',
    requiredComponents: [
      'VoiceInteractionService',
      'VoiceInteractionSessionService',
      'RoleManager.ROLE_ASSISTANT',
      'Hardware SoundTrigger HAL or Assistant Gesture Fallback',
    ],
  };
}

export type PcActionId =
  | 'GET_STATUS'
  | 'LOCK_WORKSTATION'
  | 'MUTE_AUDIO'
  | 'UNMUTE_AUDIO'
  | 'SET_VOLUME'
  | 'LAUNCH_DEVELOPMENT_ENV'
  | 'CLEAR_TEMP_CACHE'
  | 'SUSPEND_SLEEP_TIMER'
  | 'CAPTURE_DISPLAY_SUMMARY'
  | 'RAW_POWERSHELL_EXEC';

export interface PcActionPolicy {
  id: PcActionId;
  label: string;
  category: 'TELEMETRY' | 'SESSION_CONTROL' | 'MEDIA' | 'WORKFLOW' | 'RESTRICTED';
  approved: boolean;
  requiresConfirmation: boolean;
  endpoint: string;
  description: string;
}

export interface WindowsCommandValidationInput {
  actionId: string;
  authToken: string;
  expectedToken: string;
  isDevicePaired: boolean;
  timestampMs: unknown;
  nowMs: number;
  nonce?: string;
  seenNonces?: Set<string>;
  replayWindowMs?: number;
  confirmedByUser?: boolean;
  confirmationToken?: string;
  validConfirmationTokens?: Map<string, { actionId: string; payload?: unknown; expiresAt: number; sessionId?: string }>;
  payload?: Record<string, unknown>;
  policies: PcActionPolicy[];
  s25ScreenState?: ScreenState;
  allowLockScreenPcActions?: boolean;
}

export interface WindowsCommandValidationResult {
  allowed: boolean;
  status:
    | 'APPROVED'
    | 'UNPAIRED_DEVICE'
    | 'UNAUTHORIZED_TOKEN'
    | 'INVALID_TIMESTAMP'
    | 'REPLAY_DETECTED'
    | 'FORBIDDEN_ACTION'
    | 'CONFIRMATION_REQUIRED'
    | 'LOCKED_DEVICE_RESTRICTED';
  reason: string;
  auditCode: string;
  newConfirmationToken?: string;
}

/**
 * Validates whether an incoming request to the Velora Windows 11 Service
 * passes device pairing, Bearer/HMAC token verification, timestamp check,
 * true nonce-based anti-replay protection, lock-screen safety rules, and
 * explicit single-use confirmation token validation.
 */
export function validateWindowsServiceCommand(
  input: WindowsCommandValidationInput
): WindowsCommandValidationResult {
  const replayWindow = input.replayWindowMs ?? 30_000;

  // 1. Strict timestamp validation
  if (
    typeof input.timestampMs !== 'number' ||
    isNaN(input.timestampMs) ||
    !isFinite(input.timestampMs)
  ) {
    return {
      allowed: false,
      status: 'INVALID_TIMESTAMP',
      reason: 'Rejected: Missing or malformed timestamp. Requests must include valid timestampMs.',
      auditCode: 'ERR_WIN_TIMESTAMP_400',
    };
  }

  // 2. Pairing check
  if (!input.isDevicePaired) {
    return {
      allowed: false,
      status: 'UNPAIRED_DEVICE',
      reason: 'Samsung Galaxy S25 Ultra is not currently paired with the Windows 11 service.',
      auditCode: 'ERR_WIN_UNPAIRED',
    };
  }

  // 3. Token check
  if (!input.authToken || input.authToken.trim() !== input.expectedToken.trim()) {
    return {
      allowed: false,
      status: 'UNAUTHORIZED_TOKEN',
      reason: 'Invalid or missing authentication token for Velora Windows companion service.',
      auditCode: 'ERR_WIN_AUTH_401',
    };
  }

  // 4. Timestamp drift check
  const drift = Math.abs(input.nowMs - input.timestampMs);
  if (drift > replayWindow) {
    return {
      allowed: false,
      status: 'REPLAY_DETECTED',
      reason: `Request timestamp drift (${drift}ms) exceeds ${replayWindow}ms anti-replay window.`,
      auditCode: 'ERR_WIN_REPLAY_403',
    };
  }

  if (!input.nonce || !/^[a-zA-Z0-9:_-]{8,160}$/.test(input.nonce)) return {
    allowed: false, status: 'REPLAY_DETECTED', reason: 'A unique request nonce is required.', auditCode: 'ERR_NONCE_REQUIRED'
  };
  // 5. Nonce anti-replay validation
  if (input.nonce && input.seenNonces) {
    if (input.seenNonces.has(input.nonce)) {
      return {
        allowed: false,
        status: 'REPLAY_DETECTED',
        reason: `Duplicate request nonce "${input.nonce}" detected. Request rejected to prevent replay attacks.`,
        auditCode: 'ERR_WIN_REPLAY_NONCE_403',
      };
    }
  }

  // 6. Lockscreen restriction policy
  if (
    (input.s25ScreenState === 'SCREEN_OFF' || input.s25ScreenState === 'LOCK_SCREEN') &&
    input.allowLockScreenPcActions === false &&
    input.actionId !== 'GET_STATUS'
  ) {
    return {
      allowed: false,
      status: 'LOCKED_DEVICE_RESTRICTED',
      reason:
        'Windows PC control is blocked while your phone is locked. Unlock your Galaxy S25 Ultra or enable lock-screen execution in preferences.',
      auditCode: 'ERR_WIN_LOCKSCREEN_RESTRICTED',
    };
  }

  // 7. Allowlist policy check
  const policy = input.policies.find((p) => p.id === input.actionId);
  if (!policy || !policy.approved || policy.category === 'RESTRICTED') {
    return {
      allowed: false,
      status: 'FORBIDDEN_ACTION',
      reason: `Action "${input.actionId}" is blocked by the Windows companion service allowlist policy.`,
      auditCode: 'ERR_WIN_POLICY_DENIED',
    };
  }

  // 8. Confirmation gate enforcement
  if (policy.requiresConfirmation) {
    let confirmationValid = false;

    // Check explicit single-use confirmation token
    if (input.confirmationToken && input.validConfirmationTokens) {
      const stored = input.validConfirmationTokens.get(input.confirmationToken);
      if (stored && stored.actionId === input.actionId && stored.expiresAt > input.nowMs && canonical(stored.payload) === canonical(input.payload) && (!stored.sessionId || stored.sessionId === input.authToken)) {
        confirmationValid = true;
        // Consume single-use token immediately
        input.validConfirmationTokens.delete(input.confirmationToken);
      }
    }

    if (!confirmationValid) {
      return {
        allowed: false,
        status: 'CONFIRMATION_REQUIRED',
        reason: `Action "${policy.label}" requires explicit user confirmation before execution.`,
        auditCode: 'WARN_WIN_CONFIRM_GATE',
      };
    }
  }

  return {
    allowed: true,
    status: 'APPROVED',
    reason: `Action "${policy.label}" verified and approved for simulation (${policy.endpoint}).`,
    auditCode: 'OK_WIN_EXEC_200',
  };
}

export interface SubActionIntent {
  targetDomain: 'WINDOWS_PC' | 'ANDROID_DEVICE';
  actionId: PcActionId | string;
  payload?: Record<string, unknown>;
  requiresConfirmation?: boolean;
  label: string;
}

export interface ParsedVeloraIntent {
  wakeWordDetected: boolean;
  normalizedQuery: string;
  targetDomain:
    | 'WINDOWS_PC'
    | 'ANDROID_DEVICE'
    | 'CAMERA_VISION'
    | 'ROUTINE_EXECUTION'
    | 'PREFERENCES'
    | 'AMBIGUOUS'
    | 'UNSUPPORTED'
    | 'GENERAL_ASSISTANT';
  suggestedPcAction?: PcActionId;
  suggestedAndroidAction?: string;
  suggestedRoutineId?: string;
  actionPayload?: Record<string, unknown>;
  orderedPlan?: SubActionIntent[];
  isNegated?: boolean;
  clarificationMessage?: string;
  confidence: number;
}

function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Extracts a numeric volume value from spoken phrases (e.g. "volume 80", "set volume to 65%").
 */
export function extractVolumeLevel(text: string): number | null {
  const match = text.match(/(?:volume|audio level)(?:\s+(?:to|at))?\s+(\d{1,3})\s*%?/i);
  if (match) {
    const val = parseInt(match[1], 10);
    if (!isNaN(val)) return Math.max(0, Math.min(100, val));
  }
  const simpleMatch = text.match(/set\s+(?:to\s+)?(\d{1,3})\s*%(?:\s+volume)?/i);
  if (simpleMatch) {
    const val = parseInt(simpleMatch[1], 10);
    if (!isNaN(val)) return Math.max(0, Math.min(100, val));
  }
  return null;
}

/**
 * Extracts duration in seconds from timer/alarm phrases (e.g. "10 minute timer", "45 second timer").
 */
export function extractTimerDurationSeconds(text: string): number | null {
  const hourMatch = text.match(/(\d+)\s*(?:hour|hr|hours)/i);
  const minMatch = text.match(/(\d+)\s*(?:minute|min|minutes|mins)/i);
  const secMatch = text.match(/(\d+)\s*(?:second|sec|seconds|secs)/i);

  let totalSec = 0;
  let found = false;

  if (hourMatch) {
    totalSec += parseInt(hourMatch[1], 10) * 3600;
    found = true;
  }
  if (minMatch) {
    totalSec += parseInt(minMatch[1], 10) * 60;
    found = true;
  }
  if (secMatch) {
    totalSec += parseInt(secMatch[1], 10);
    found = true;
  }

  return found && totalSec > 0 ? totalSec : null;
}

/**
 * Deterministic, safe intent parser for Velora spoken and typed utterances.
 * Replaces fragile substring matching with negation checks, unlock protection,
 * parameter extraction, custom routine resolution, and compound command plans.
 */
export { parseCommand as parseVeloraIntent } from './commandParser';

export interface RoutineStep {
  id: string;
  target: 'S25_ULTRA' | 'WINDOWS_11_PC';
  actionLabel: string;
  commandKey: string;
  enabled: boolean;
  estimatedMs: number;
  payload?: Record<string, unknown>;
}

export interface VeloraRoutine {
  id: string;
  name: string;
  voiceTrigger: string;
  description: string;
  steps: RoutineStep[];
  lastRunAt?: string;
}

export interface StepExecutionResult {
  stepId: string;
  target: 'S25_ULTRA' | 'WINDOWS_11_PC';
  commandKey: string;
  actionLabel: string;
  status: 'SUCCESS' | 'DENIED' | 'SKIPPED' | 'FAILED' | 'CONFIRMATION_REQUIRED';
  measuredDurationMs: number;
  message: string;
}

export interface RoutineExecutionReport {
  routineId: string;
  routineName: string;
  status: 'COMPLETED' | 'PARTIAL_SUCCESS' | 'FAILED';
  stepResults: StepExecutionResult[];
  totalMeasuredMs: number;
  summaryMessage: string;
}

export function buildRoutineExecutionPlan(
  routine: VeloraRoutine,
  isWindowsPaired: boolean
): {
  executableSteps: RoutineStep[];
  skippedSteps: RoutineStep[];
  totalEstimatedMs: number;
  ready: boolean;
  blockingReason?: string;
} {
  const enabledSteps = (routine.steps || []).filter((s) => s.enabled);
  if (enabledSteps.length === 0) {
    return {
      executableSteps: [],
      skippedSteps: routine.steps || [],
      totalEstimatedMs: 0,
      ready: false,
      blockingReason: 'Routine has no enabled steps.',
    };
  }

  const executableSteps: RoutineStep[] = [];
  const skippedSteps: RoutineStep[] = [];

  for (const step of routine.steps) {
    if (!step.enabled) {
      skippedSteps.push(step);
      continue;
    }
    if (step.target === 'WINDOWS_11_PC' && !isWindowsPaired) {
      skippedSteps.push(step);
      continue;
    }
    executableSteps.push(step);
  }

  const totalEstimatedMs = executableSteps.reduce((acc, s) => acc + s.estimatedMs, 0);

  return {
    executableSteps,
    skippedSteps,
    totalEstimatedMs,
    ready: executableSteps.length > 0,
    blockingReason:
      executableSteps.length === 0
        ? 'All enabled steps require a paired Windows 11 PC.'
        : undefined,
  };
}
