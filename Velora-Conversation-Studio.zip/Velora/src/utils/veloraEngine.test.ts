import test from 'node:test';
import assert from 'node:assert/strict';
import {parseVeloraIntent,validateWindowsServiceCommand,buildRoutineExecutionPlan,type WindowsCommandValidationInput} from './veloraEngine';
import {mouthFrame,rms} from './avatarAudio';

test('negations, questions and unlock never execute a lock',()=>{
  for(const q of ['do not lock my PC',"don't lock my PC",'unlock my PC','explain how to lock my PC']) assert.equal(parseVeloraIntent(q).suggestedPcAction,undefined,q);
});
test('Do Not Disturb is a feature name, with explicit on/off state',()=>{
  assert.deepEqual(parseVeloraIntent('enable Do Not Disturb').actionPayload,{enabled:true});
  assert.deepEqual(parseVeloraIntent('turn off do not disturb').actionPayload,{enabled:false});
  assert.equal(parseVeloraIntent('do not enable Do Not Disturb').isNegated,true);
});
test('preserves durations and validates timer and volume arguments',()=>{
  assert.deepEqual(parseVeloraIntent('set a 1 hour and 30 minute timer').actionPayload,{durationSeconds:5400});
  assert.deepEqual(parseVeloraIntent('set my PC volume to 80 percent').actionPayload,{volume:80});
  for(const q of ['set a timer','set my PC volume','set my PC volume to 150%']) assert.equal(parseVeloraIntent(q).targetDomain,'AMBIGUOUS',q);
  assert.equal(parseVeloraIntent('set an alarm for 7 am').targetDomain,'UNSUPPORTED');
  assert.equal(parseVeloraIntent('set my phone volume to 20 percent').suggestedPcAction,undefined);
});
test('compound plans preserve each action; unknown steps block the whole plan',()=>{
  const plan=parseVeloraIntent('mute my PC and set a 10 minute timer').orderedPlan!;
  assert.deepEqual(plan.map(p=>p.actionId),['MUTE_AUDIO','SET_TIMER']);
  assert.deepEqual(plan[1].payload,{durationSeconds:600});
  const bad=parseVeloraIntent('mute my PC and order a pizza');assert.equal(bad.targetDomain,'AMBIGUOUS');assert.equal(bad.suggestedPcAction,undefined);
});
test('wake words escape regex and custom triggers are exact',()=>{
  assert.equal(parseVeloraIntent('Velora (v1.0), check my PC status','Velora (v1.0)').wakeWordDetected,true);
  const r={id:'custom',name:'Night',voiceTrigger:'Velora, run night',description:'',steps:[]};
  assert.equal(parseVeloraIntent('Velora, run night','Velora',[r]).suggestedRoutineId,'custom');
  assert.equal(parseVeloraIntent('what does run night do','Velora',[r]).suggestedRoutineId,undefined);
  assert.equal(parseVeloraIntent('lockdown protocol').suggestedRoutineId,'routine-shutdown');
});
test('keep-awake and torch use explicit state',()=>{
  assert.deepEqual(parseVeloraIntent('keep my PC awake').actionPayload,{suspend:true});
  assert.deepEqual(parseVeloraIntent('allow my PC sleep').actionPayload,{suspend:false});
  assert.deepEqual(parseVeloraIntent('turn off flashlight').actionPayload,{enabled:false});
});
function request():WindowsCommandValidationInput{return {actionId:'SET_VOLUME',authToken:'session-one',expectedToken:'session-one',isDevicePaired:true,timestampMs:1000,nowMs:1001,nonce:'nonce-12345678',seenNonces:new Set(),payload:{volume:20},policies:[{id:'SET_VOLUME',label:'Volume',category:'MEDIA',approved:true,requiresConfirmation:true,endpoint:'/execute',description:''}]};}
test('confirmation is bound to payload, session, expiry and single use',()=>{
  const r=request();const tokens=new Map([['approval',{actionId:'SET_VOLUME',payload:{volume:20},sessionId:'session-one',expiresAt:2000}]]);
  const withToken={...r,confirmationToken:'approval',validConfirmationTokens:tokens};
  assert.equal(validateWindowsServiceCommand({...withToken,payload:{volume:100}}).allowed,false);
  assert.equal(validateWindowsServiceCommand({...withToken,authToken:'session-two',expectedToken:'session-two'}).allowed,false);
  assert.equal(validateWindowsServiceCommand({...withToken,nowMs:2001}).allowed,false);
  assert.equal(validateWindowsServiceCommand(withToken).allowed,true);
  assert.equal(validateWindowsServiceCommand(withToken).allowed,false);
});
test('boolean approval alone, missing nonce and repeated nonce fail closed',()=>{
  const r=request();assert.equal(validateWindowsServiceCommand({...r,confirmedByUser:true}).allowed,false);
  assert.equal(validateWindowsServiceCommand({...r,nonce:undefined}).allowed,false);
  assert.equal(validateWindowsServiceCommand({...r,seenNonces:new Set([r.nonce!])}).status,'REPLAY_DETECTED');
});
test('routine plan skips disabled and unavailable device steps',()=>{
  const r={id:'r',name:'r',voiceTrigger:'r',description:'',steps:[{id:'a',target:'S25_ULTRA' as const,actionLabel:'DND',commandKey:'SET_DND_MODE',enabled:true,estimatedMs:1},{id:'b',target:'WINDOWS_11_PC' as const,actionLabel:'PC',commandKey:'GET_STATUS',enabled:true,estimatedMs:2}]};
  assert.equal(buildRoutineExecutionPlan(r,false).executableSteps.length,1);
});
test('audio silence closes mouth and energy selects bounded frames',()=>{
  assert.equal(rms(new Float32Array([0,0])),0);assert.equal(mouthFrame(0),0);assert.equal(mouthFrame(NaN),0);
  assert.equal(mouthFrame(.02),1);assert.equal(mouthFrame(.07),2);assert.equal(mouthFrame(.2),3);
});
