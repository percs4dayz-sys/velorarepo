import type { VeloraRoutine } from '../utils/veloraEngine';

export interface BlueprintPhase {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  implementationStatus:
    | 'PROTOTYPE_SIMULATION'
    | 'UNRESOLVED_PLATFORM_LIMITATION'
    | 'INCOMPLETE_ARCHITECTURAL_BLUEPRINT'
    | 'PLANNED_NATIVE_FEATURE';
  statusLabel: string;
  summary: string;
  keyDeliverables: string[];
  platformRealityNotes: string;
}

export interface SourceFileArtifact {
  id: string;
  phaseNumber: string;
  filename: string;
  path: string;
  language: 'kotlin' | 'xml' | 'csharp' | 'json';
  targetPlatform: 'Android 16 (S25 Ultra)' | 'Windows 11 Service';
  description: string;
  statusNotice: string;
  missingImplementations: string[];
  code: string;
}

export const VELORA_PHASES: BlueprintPhase[] = [
  {
    id: 'phase-01',
    number: '01',
    title: 'Project Architecture & Android 16 VoiceInteractionService',
    subtitle: 'Overcoming background mic & foreground-service restrictions on Galaxy S25 Ultra',
    implementationStatus: 'INCOMPLETE_ARCHITECTURAL_BLUEPRINT',
    statusLabel: 'Incomplete Blueprint (Native Spec)',
    summary:
      'Replaces fragile background microphone services with Android’s system-privileged VoiceInteractionService and RoleManager.ROLE_ASSISTANT binding with lifecycle and Doze behavior still to be tested on the actual device.',
    keyDeliverables: [
      'Bind VoiceInteractionService & VoiceInteractionSessionService in AndroidManifest.xml',
      'Request RoleManager.ROLE_ASSISTANT for default digital assistant privileges',
      'Configure voice_interaction_service.xml with supportsAssist & supportsLocalInteraction',
    ],
    platformRealityNotes:
      'Requires user to manually grant Default Digital Assistant in Android 16 Settings. Full native Gradle project structure, targetSdk 36, and compiled APK required for real device installation.',
  },
  {
    id: 'phase-02',
    number: '02',
    title: 'Always-On Hotword DSP & Low-Latency Audio Pipeline',
    subtitle: 'Hardware SoundTrigger wake-word detection for "Velora" with screen off',
    implementationStatus: 'UNRESOLVED_PLATFORM_LIMITATION',
    statusLabel: 'Unresolved Platform Limitation',
    summary:
      'Explores AlwaysOnHotwordDetector backed by the Snapdragon 8 Elite low-power audio DSP island. Intended to open AudioRecord inside VoiceInteractionSession.onShow() after keyphrase verification.',
    keyDeliverables: [
      'AlwaysOnHotwordDetector callback lifecycle (onDetected, onAvailabilityChanged)',
      'Measure standby battery use on the actual device',
      'Push-to-talk (PTT) / Side-button assistant gesture practical MVP fallback',
    ],
    platformRealityNotes:
      'UNVERIFIED DEVICE FEASIBILITY: The default-assistant role does not establish access to system hotword APIs or an enrolled sound model. Validate the stock phone before promising custom wake words. Begin with push-to-talk.',
  },
  {
    id: 'phase-03',
    number: '03',
    title: 'OpenAI Intelligence & Structured Tool Router',
    subtitle: 'Low-latency voice understanding, function calling, and natural speech synthesis',
    implementationStatus: 'PROTOTYPE_SIMULATION',
    statusLabel: 'Simulated Prototype Active',
    summary:
      'Uses deterministic local parsing for simulated actions and optional OpenAI text chat. Realtime voice and model tool calling are not implemented.',
    keyDeliverables: [
      'Server-side OpenAI integration with configurable OPENAI_MODEL and safe demo mode',
      'Deterministic intent parsing with negation protection, parameter extraction, and compound plans',
      'Safe keyphrase parsing without unescaped regex vulnerabilities',
    ],
    platformRealityNotes:
      'Active in this Express prototype. In the native Android app, calls will be routed through a secure backend proxy or native OpenAI WebSocket client.',
  },
  {
    id: 'phase-04',
    number: '04',
    title: 'Native Android System Action Executor',
    subtitle: 'Direct Kotlin execution of S25 Ultra system APIs without opening third-party UI',
    implementationStatus: 'INCOMPLETE_ARCHITECTURAL_BLUEPRINT',
    statusLabel: 'Incomplete Blueprint',
    summary:
      'Executes timers, alarms, NotificationManager Do Not Disturb filters, CameraManager torch control, and deep-link intents directly from the assistant session.',
    keyDeliverables: [
      'AlarmClock & Timer silent dispatchers',
      'NotificationManager interruption filter & ringer control',
      'CameraManager Torch & hardware state controller',
    ],
    platformRealityNotes:
      'Requires runtime permission grants (ACCESS_NOTIFICATION_POLICY for DND, SET_ALARM for timers) and native Android Context executors.',
  },
  {
    id: 'phase-05',
    number: '05',
    title: 'Authenticated Windows 11 Companion Service',
    subtitle: 'Planned Windows companion for approved PC actions and status reports',
    implementationStatus: 'PROTOTYPE_SIMULATION',
    statusLabel: 'Simulated Prototype Active',
    summary:
      'Local browser sessions protect this loopback simulation, with anti-replay nonces, payload-bound confirmations, and an action allowlist. Remote companion authentication remains to be built.',
    keyDeliverables: [
      'Single-use confirmation tokens for sensitive actions (Lock, Cache Purge)',
      'Nonce-based replay prevention and strict timestamp validation',
      'Safe telemetry reporting with secret credential redaction',
    ],
    platformRealityNotes:
      'WINDOWS SESSION 0 ARCHITECTURAL REQUIREMENT: A native Windows Service runs in Session 0 (non-interactive). Calling desktop functions like user32.dll LockWorkStation() or launching desktop GUI apps (Android Studio) requires an Interactive User Session Agent running in Session 1+ communicating with the service via local IPC/named pipes.',
  },
  {
    id: 'phase-06',
    number: '06',
    title: 'Velora 1.0: Preferences, Vision Assist, Routines & Pairing',
    subtitle: 'Prototype assistant experience with persistent storage, diagnostic analysis & multi-device workflows',
    implementationStatus: 'PROTOTYPE_SIMULATION',
    statusLabel: 'Simulated Prototype Active',
    summary:
      'Prototype implementation of persistent preferences (simulating Jetpack DataStore), synthetic diagnostic assistance, multi-device routine execution with per-step receipts, and device pairing.',
    keyDeliverables: [
      'Browser prototype storage simulating Android Jetpack DataStore preferences',
      'Synthetic visual test pattern analysis (explicitly labeled, no fake OCR claims)',
      'Multi-device routine engine returning measured step durations and failure handling',
      'Simulated pairing controls and pending-approval revocation',
    ],
    platformRealityNotes:
      'Preferences in this web prototype persist via browser storage. Native Android implementation requires Jetpack DataStore + Android Keystore encryption.',
  },
];

export const SOURCE_FILE_ARTIFACTS: SourceFileArtifact[] = [
  {
    id: 'manifest-xml',
    phaseNumber: '01',
    filename: 'AndroidManifest.xml',
    path: 'android-app/app/src/main/AndroidManifest.xml',
    language: 'xml',
    targetPlatform: 'Android 16 (S25 Ultra)',
    description:
      'Illustrative AndroidManifest.xml declaring VoiceInteractionService and assistant contracts.',
    statusNotice:
      'Incomplete Reference Blueprint: Requires a complete Android Gradle project, targetSdk 36, and compiled resources.',
    missingImplementations: [
      'Full build.gradle.kts and settings.gradle.kts',
      'Theme.Velora resource definitions',
      'R.xml.voice_interaction_service compiled reference',
      'VeloraApp application class implementation',
    ],
    code: `<?xml version="1.0" encoding="utf-8"?>
<!-- INCOMPLETE ARCHITECTURAL BLUEPRINT - FOR REFERENCE ONLY -->
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.velora.assistant">

    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACCESS_NOTIFICATION_POLICY" />
    <uses-permission android:name="com.android.alarm.permission.SET_ALARM" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />

    <application
        android:name=".VeloraApp"
        android:label="Velora (Prototype Blueprint)"
        android:supportsRtl="true"
        android:theme="@style/Theme.Velora">

        <!-- System-Bound VoiceInteractionService -->
        <service
            android:name=".voice.VeloraVoiceInteractionService"
            android:label="Velora Voice Engine"
            android:permission="android.permission.BIND_VOICE_INTERACTION"
            android:exported="true">
            <meta-data
                android:name="android.voice_interaction"
                android:resource="@xml/voice_interaction_service" />
            <intent-filter>
                <action android:name="android.service.voice.VoiceInteractionService" />
            </intent-filter>
        </service>

        <service
            android:name=".voice.VeloraSessionService"
            android:permission="android.permission.BIND_VOICE_INTERACTION"
            android:exported="false" />

        <service
            android:name=".voice.VeloraRecognitionService"
            android:label="Velora Speech Recognizer"
            android:exported="true">
            <intent-filter>
                <action android:name="android.speech.RecognitionService" />
                <category android:name="android.intent.category.DEFAULT" />
            </intent-filter>
        </service>

        <activity
            android:name=".ui.MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <action android:name="android.intent.action.ASSIST" />
                <category android:name="android.intent.category.LAUNCHER" />
                <category android:name="android.intent.category.DEFAULT" />
            </intent-filter>
        </activity>
    </application>
</manifest>`,
  },
  {
    id: 'vis-xml',
    phaseNumber: '01',
    filename: 'voice_interaction_service.xml',
    path: 'android-app/app/src/main/res/xml/voice_interaction_service.xml',
    language: 'xml',
    targetPlatform: 'Android 16 (S25 Ultra)',
    description:
      'Illustrative XML linking VoiceInteractionService to SessionService and Settings.',
    statusNotice:
      'Incomplete Reference Blueprint: Must be placed in res/xml/ and referenced by the manifest.',
    missingImplementations: [
      'Compiled XML binary in Android resource table',
      'Matching package name and class references',
    ],
    code: `<?xml version="1.0" encoding="utf-8"?>
<!-- INCOMPLETE ARCHITECTURAL BLUEPRINT - FOR REFERENCE ONLY -->
<voice-interaction-service
    xmlns:android="http://schemas.android.com/apk/res/android"
    android:sessionService="com.velora.assistant.voice.VeloraSessionService"
    android:recognitionService="com.velora.assistant.voice.VeloraRecognitionService"
    android:settingsActivity="com.velora.assistant.ui.MainActivity"
    android:supportsAssist="true"
    android:supportsLaunchVoiceAssistFromKeyguard="true"
    android:supportsLocalInteraction="true" />`,
  },
  {
    id: 'vis-kotlin',
    phaseNumber: '02',
    filename: 'VeloraVoiceInteractionService.kt',
    path: 'android-app/app/src/main/java/com/velora/assistant/voice/VeloraVoiceInteractionService.kt',
    language: 'kotlin',
    targetPlatform: 'Android 16 (S25 Ultra)',
    description:
      'Illustrative VoiceInteractionService demonstrating AlwaysOnHotwordDetector and session triggers.',
    statusNotice:
      'Unresolved Platform Limitation: Custom always-on DSP availability has not been verified on the target phone. Practical MVP uses Assistant gesture or Push-to-Talk.',
    missingImplementations: [
      'Verify API access, supported sound model and enrollment on the actual phone',
      'Push-to-talk Quick Settings Tile service implementation',
      'Side-key assistant gesture handling fallback',
    ],
    code: `package com.velora.assistant.voice

// INCOMPLETE ARCHITECTURAL BLUEPRINT - FOR REFERENCE ONLY
// NOTE: Custom "Velora" DSP enrollment on stock retail S25 Ultra is restricted by Samsung/Qualcomm HAL.
// Recommended practical MVP: Use RoleManager.ROLE_ASSISTANT side-key gesture or Push-to-Talk.

import android.os.Bundle
import android.service.voice.AlwaysOnHotwordDetector
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.util.Log
import java.util.Locale

class VeloraVoiceInteractionService : VoiceInteractionService() {

    private var hotwordDetector: AlwaysOnHotwordDetector? = null

    override fun onReady() {
        super.onReady()
        Log.i(TAG, "Velora VoiceInteractionService bound by Android 16 system server")
        initializeHotwordOrGestureFallback()
    }

    private fun initializeHotwordOrGestureFallback() {
        try {
            hotwordDetector = createAlwaysOnHotwordDetector(
                KEYPHRASE_VELORA,
                Locale.US,
                object : AlwaysOnHotwordDetector.Callback() {
                    override fun onAvailabilityChanged(status: Int) {
                        Log.d(TAG, "Hotword availability status: $status")
                        // On stock retail firmware, status will typically return
                        // STATE_KEYPHRASE_UNSUPPORTED for arbitrary custom phrases.
                    }

                    override fun onDetected(eventPayload: AlwaysOnHotwordDetector.EventPayload) {
                        triggerPrivilegedSession("DSP_HOTWORD")
                    }

                    override fun onError() {
                        Log.w(TAG, "Hotword detection error; falling back to assistant gesture.")
                    }

                    override fun onRecognitionPaused() {}
                    override fun onRecognitionResumed() {}
                }
            )
        } catch (e: Exception) {
            Log.e(TAG, "DSP Hotword initialization failed (expected on stock retail firmware): \${e.message}")
        }
    }

    fun triggerPrivilegedSession(triggerSource: String) {
        val args = Bundle().apply {
            putString("trigger_source", triggerSource)
            putLong("detected_at_ms", System.currentTimeMillis())
        }
        showSession(
            args,
            VoiceInteractionSession.SHOW_WITH_ASSIST or
                VoiceInteractionSession.SHOW_SOURCE_ASSIST_GESTURE
        )
    }

    companion object {
        private const val TAG = "VeloraVIS"
        private const val KEYPHRASE_VELORA = "Velora"
    }
}`,
  },
  {
    id: 'session-kotlin',
    phaseNumber: '03',
    filename: 'VeloraVoiceSession.kt',
    path: 'android-app/app/src/main/java/com/velora/assistant/voice/VeloraVoiceSession.kt',
    language: 'kotlin',
    targetPlatform: 'Android 16 (S25 Ultra)',
    description:
      'Illustrative VoiceInteractionSession showing active turn UI and tool router pattern.',
    statusNotice:
      'Incomplete Blueprint: Relies on unbuilt helper classes (OpenAiToolBridge, WindowsServiceClient, AndroidSystemExecutor).',
    missingImplementations: [
      'OpenAiToolBridge network client and token manager',
      'WindowsServiceClient mTLS / HTTP client with replay nonces',
      'AndroidSystemExecutor with runtime permission checks',
      'R.layout.overlay_velora_session Compose / XML view',
    ],
    code: `package com.velora.assistant.voice

// INCOMPLETE ARCHITECTURAL BLUEPRINT - FOR REFERENCE ONLY
// Stub imports represent planned native modules to be implemented in native development.

import android.content.Context
import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.view.View
import kotlinx.coroutines.*

class VeloraVoiceSession(context: Context) : VoiceInteractionSession(context) {

    private val sessionScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onCreateContentView(): View {
        // In native project: inflate Compose View or XML overlay layout
        return View(context)
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val trigger = args?.getString("trigger_source") ?: "GESTURE"
        // Active turn: Capture user speech, dispatch tool intents, and synthesize audio
    }

    override fun onHide() {
        sessionScope.coroutineContext.cancelChildren()
        super.onHide()
    }
}`,
  },
  {
    id: 'datastore-prefs-kotlin',
    phaseNumber: '06',
    filename: 'VeloraPreferencesRepository.kt',
    path: 'android-app/app/src/main/java/com/velora/assistant/data/VeloraPreferencesRepository.kt',
    language: 'kotlin',
    targetPlatform: 'Android 16 (S25 Ultra)',
    description:
      'Illustrative Jetpack DataStore preferences repository for native Android.',
    statusNotice:
      'Incomplete Blueprint: Requires androidx.datastore:datastore-preferences dependency and Android Keystore encryption wrapper.',
    missingImplementations: [
      'Android Keystore MasterKey encryption for sensitive tokens',
      'DataStore dependency in build.gradle.kts',
      'Dependency injection setup (Hilt / Koin)',
    ],
    code: `package com.velora.assistant.data

// INCOMPLETE ARCHITECTURAL BLUEPRINT - FOR REFERENCE ONLY
// Demonstrates target Jetpack DataStore preferences architecture for Android 16.

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "velora_1_0_prefs")

data class VeloraUserPreferences(
    val wakeWord: String = "Velora",
    val voicePersona: String = "Alloy-Tactical",
    val speechRate: Float = 1.05f,
    val verbosity: String = "CONCISE",
    val allowLockScreenPcActions: Boolean = false,
    val cameraAutoOcr: Boolean = true,
    val pairedPcEndpoint: String = "https://127.0.0.1:8443"
)

class VeloraPreferencesRepository(private val context: Context) {
    // Jetpack DataStore implementation pattern
}`,
  },
  {
    id: 'win-service-csharp',
    phaseNumber: '05',
    filename: 'WindowsCompanionService.cs',
    path: 'windows-service/Velora.WinService/WindowsCompanionService.cs',
    language: 'csharp',
    targetPlatform: 'Windows 11 Service',
    description:
      'Illustrative Windows Service daemon (.NET 8) with essential Session 0 architecture notes.',
    statusNotice:
      'Incomplete Blueprint: Windows Services run in Session 0 (non-interactive). Interactive actions (LockWorkStation, GUI app launch) require a companion User Session Agent.',
    missingImplementations: [
      'Interactive User Session Agent (runs in Session 1+ on user desktop)',
      'Named pipe / gRPC local IPC between Session 0 service and User Session Agent',
      'Windows Service installer and Certificate store integration',
    ],
    code: `// INCOMPLETE ARCHITECTURAL BLUEPRINT - FOR REFERENCE ONLY
// CRITICAL ARCHITECTURAL REQUIREMENT:
// A Windows Background Service runs in Session 0 (non-interactive).
// Invoking user32.dll LockWorkStation() or launching desktop GUI apps (e.g. Android Studio)
// directly from Session 0 does not affect the interactive user desktop.
// Production architecture requires:
// 1. Velora.WinService (Session 0 network daemon / security gate)
// 2. Velora.UserAgent (Session 1+ interactive desktop agent communicating via local Named Pipes)

namespace Velora.WinService;

public sealed class WindowsCompanionService
{
    // Planned .NET 8 background service architecture
}`,
  },
];

export const INITIAL_ROUTINES: VeloraRoutine[] = [
  {
    id: 'routine-deep-work',
    name: 'Deep Work Sprint',
    voiceTrigger: 'Velora, start Deep Work',
    description:
      'Simulates setting S25 Ultra Priority DND, launching Windows 11 IDE workspace, and asserting keep-awake.',
    lastRunAt: 'Never run in this session',
    steps: [
      {
        id: 'dw-1',
        target: 'S25_ULTRA',
        actionLabel: 'Set NotificationManager to Priority Do Not Disturb',
        commandKey: 'SET_DND_MODE',
        enabled: true,
        estimatedMs: 95,
      },
      {
        id: 'dw-2',
        target: 'WINDOWS_11_PC',
        actionLabel: 'Launch Android Studio & Wireless ADB Bridge',
        commandKey: 'LAUNCH_DEVELOPMENT_ENV',
        enabled: true,
        estimatedMs: 310,
      },
      {
        id: 'dw-3',
        target: 'WINDOWS_11_PC',
        actionLabel: 'Assert ES_SYSTEM_REQUIRED (Keep Awake)',
        commandKey: 'SUSPEND_SLEEP_TIMER',
        enabled: true,
        estimatedMs: 110,
      },
    ],
  },
  {
    id: 'routine-morning-briefing',
    name: 'Workstation Morning Sync',
    voiceTrigger: 'Velora, morning briefing',
    description:
      'Simulates querying Windows 11 status telemetry, checking build cache, and unmuting PC audio.',
    lastRunAt: 'Never run in this session',
    steps: [
      {
        id: 'mb-1',
        target: 'WINDOWS_11_PC',
        actionLabel: 'Collect Workstation Telemetry Report',
        commandKey: 'GET_STATUS',
        enabled: true,
        estimatedMs: 140,
      },
      {
        id: 'mb-2',
        target: 'WINDOWS_11_PC',
        actionLabel: 'Purge Stale Build Caches (Requires Confirmation)',
        commandKey: 'CLEAR_TEMP_CACHE',
        enabled: true,
        estimatedMs: 280,
      },
      {
        id: 'mb-3',
        target: 'WINDOWS_11_PC',
        actionLabel: 'Unmute Master Audio Endpoint',
        commandKey: 'UNMUTE_AUDIO',
        enabled: true,
        estimatedMs: 90,
      },
    ],
  },
  {
    id: 'routine-shutdown',
    name: 'Away & Lockdown Protocol',
    voiceTrigger: 'Velora, lockdown protocol',
    description:
      'Simulates muting Windows 11 audio and requesting workstation session lock (requires confirmation).',
    lastRunAt: 'Never run in this session',
    steps: [
      {
        id: 'sd-1',
        target: 'WINDOWS_11_PC',
        actionLabel: 'Mute Windows 11 Master Audio',
        commandKey: 'MUTE_AUDIO',
        enabled: true,
        estimatedMs: 85,
      },
      {
        id: 'sd-2',
        target: 'WINDOWS_11_PC',
        actionLabel: 'Lock Windows 11 Desktop Session (Requires Confirmation)',
        commandKey: 'LOCK_WORKSTATION',
        enabled: true,
        estimatedMs: 130,
      },
    ],
  },
];
