let session: Promise<string> | undefined;
async function csrf(): Promise<string> {
  if (!session) session = fetch('/api/session', { credentials: 'same-origin', headers: { 'X-Velora-Client': 'studio' } })
    .then(async r => { if (!r.ok) throw new Error('Local session unavailable.'); return (await r.json()).csrf; })
    .catch(e => { session = undefined; throw e; });
  return session;
}
export async function apiFetch(url: string, init: RequestInit = {}): Promise<Response> {
  const token = await csrf();
  const headers = new Headers(init.headers);
  headers.set('X-Velora-CSRF', token);
  let body = init.body;
  if (typeof body === 'string' && init.method === 'POST') {
    const parsed = JSON.parse(body);
    body = JSON.stringify({ ...parsed, timestampMs: Date.now(), nonce: parsed.nonce || crypto.randomUUID() });
  }
  const response = await fetch(url, { ...init, body, headers, signal: init.signal || AbortSignal.timeout(25000), credentials: 'same-origin' });
  if (response.status === 401) session = undefined;
  return response;
}
