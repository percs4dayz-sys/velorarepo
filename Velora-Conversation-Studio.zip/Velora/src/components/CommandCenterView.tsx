import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  Send,
  Volume2,
  ShieldCheck,
  Smartphone,
  Monitor,
  Terminal,
  Camera,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import type {
  WindowsWorkstationState,
  VeloraPreferences,
  S25UltraDeviceState,
  ConversationTurn,
  ToolReceipt,
} from '../types/velora';

interface CommandCenterViewProps {
  workstation: WindowsWorkstationState;
  s25State: S25UltraDeviceState;
  setS25State: React.Dispatch<React.SetStateAction<S25UltraDeviceState>>;
  preferences: VeloraPreferences;
  conversation: ConversationTurn[];
  onSendVoiceCommand: (utterance: string) => Promise<void>;
  isProcessingCommand: boolean;
  sessionPhase:
    | 'DSP_STANDBY'
    | 'HOTWORD_TRIGGERED'
    | 'SESSION_LISTENING'
    | 'TOOL_DISPATCHING'
    | 'SPEAKING_RESPONSE';
  onNavigateTab: (tab: 'command' | 'windows' | 'routines' | 'architecture') => void;
  onConfirmPendingAction?: (actionId: string, confirmationToken: string) => Promise<void>;
  activeErrorBanner?: string | null;
}

const PRESET_VOICE_COMMANDS = [
  'Velora, check my Windows 11 GPU temperature and system status',
  'Velora, lock my Windows workstation right now',
  'Velora, start Deep Work mode across my phone and PC',
  'Velora, enable Priority Do Not Disturb and set a 25 minute timer',
  'Velora, mute my desktop audio and keep my PC awake',
  'Velora, purge temporary Gradle build caches on my PC',
];

export const CommandCenterView: React.FC<CommandCenterViewProps> = ({
  workstation,
  s25State,
  setS25State,
  preferences,
  conversation,
  onSendVoiceCommand,
  isProcessingCommand,
  sessionPhase,
  onNavigateTab,
  onConfirmPendingAction,
  activeErrorBanner,
}) => {
  const [inputUtterance, setInputUtterance] = useState('');
  const [validationError, setValidationError] = useState<string | null>(null);
  const [isSimulatedMicActive, setIsSimulatedMicActive] = useState(false);
  const [confirmingToken, setConfirmingToken] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Draw deterministic simulated DSP waveform on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0, 0, width, height);

    const barCount = 36;
    const barWidth = 4;
    const gap = (width - barCount * barWidth) / (barCount - 1);
    const active =
      isSimulatedMicActive || isProcessingCommand || sessionPhase !== 'DSP_STANDBY';

    for (let i = 0; i < barCount; i++) {
      const centerDist = Math.abs(i - barCount / 2) / (barCount / 2);
      const baseWave = Math.sin(i * 0.45) * 0.5 + 0.5;
      const amplitude = active
        ? Math.max(0.18, (1 - centerDist * 0.75) * (0.4 + baseWave * 0.6))
        : 0.12 + baseWave * 0.08;

      const barHeight = Math.round(amplitude * (height - 8));
      const x = i * (barWidth + gap);
      const y = Math.round((height - barHeight) / 2);

      ctx.fillStyle = active ? '#38BDF8' : '#334155';
      ctx.beginPath();
      ctx.roundRect(x, y, barWidth, barHeight, 2);
      ctx.fill();
    }
  }, [isSimulatedMicActive, isProcessingCommand, sessionPhase, conversation.length]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = inputUtterance.trim();
    if (!trimmed) {
      setValidationError('Enter a spoken command or select a preset wake-word utterance.');
      return;
    }
    setValidationError(null);
    setInputUtterance('');
    await onSendVoiceCommand(trimmed);
  };

  const handleTriggerWakeWordMic = async () => {
    setValidationError(null);
    setIsSimulatedMicActive(true);
    const sampleCommand =
      inputUtterance.trim() ||
      `${preferences.wakeWord}, check my Windows 11 GPU temperature and system status`;
    setTimeout(async () => {
      setIsSimulatedMicActive(false);
      setInputUtterance('');
      await onSendVoiceCommand(sampleCommand);
    }, 350);
  };

  const handleConfirmReceipt = async (actionId: string, token: string) => {
    if (!onConfirmPendingAction) return;
    setConfirmingToken(token);
    try {
      await onConfirmPendingAction(actionId, token);
    } finally {
      setConfirmingToken(null);
    }
  };

  return (
    <div className="space-y-8">
      {activeErrorBanner && (
        <div
          role="alert"
          className="p-3.5 rounded-lg bg-rose-950/60 border border-rose-800 text-xs font-mono text-rose-200 flex items-center justify-between gap-3"
        >
          <span>{activeErrorBanner}</span>
        </div>
      )}

      {/* Top Hero Split: S25 Ultra VoiceInteractionSession Console + Hardware Bridge */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left 7 Cols: Active VoiceInteractionSession & Command Bar */}
        <section
          aria-labelledby="voice-session-heading"
          className="lg:col-span-7 bg-[#111726] border border-slate-800 rounded-xl p-6 flex flex-col justify-between"
        >
          <div>
            <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-800/80">
              <div className="text-xs text-slate-400 font-mono">
                <span className="text-amber-400 font-semibold">[PROTOTYPE SIMULATION]</span>
                <span className="mx-2" aria-hidden="true">·</span>
                <span>Android 16 (API 36) Spec</span>
                <span className="mx-2" aria-hidden="true">·</span>
                <span>Wake Word: &ldquo;{preferences.wakeWord}&rdquo;</span>
              </div>
              <div className="text-xs font-mono text-sky-400 tabular-nums">
                Simulated State: {sessionPhase}
              </div>
            </div>

            <div className="mt-5">
              <h1
                id="voice-session-heading"
                className="text-2xl sm:text-3xl font-bold tracking-tight text-white font-display"
                style={{ textWrap: 'balance' }}
              >
                Velora Architecture &amp; Command Studio
              </h1>
              <p className="mt-2 text-sm text-slate-300 leading-relaxed max-w-2xl">
                Interactive full-stack prototype modeling the Android 16{' '}
                <code className="text-sky-300 font-mono text-xs">VoiceInteractionService</code> lifecycle
                on Samsung Galaxy S25 Ultra, with a simulated Windows 11 companion
                daemon for allowlisted PC actions and status telemetry.
              </p>
            </div>

            {/* Waveform & Session Lifecycle Strip */}
            <div className="mt-6 py-4 px-4 bg-[#0B0F17] border border-slate-800/90 rounded-lg">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
                <span>
                  Planned voice pipeline · no microphone capture
                </span>
                <span className="font-mono text-slate-300 tabular-nums">
                  Text command simulation · device voice on Conversation
                </span>
              </div>
              <canvas
                ref={canvasRef}
                width={520}
                height={44}
                data-testid="dsp-waveform-canvas"
                className="w-full h-11 block"
              />
              <div className="mt-3 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 font-mono">
                <span>
                  Flow: 1. Keyphrase Detected &rarr; 2. showSession() &rarr; 3. OpenAI Router &rarr; 4. Execution
                </span>
                <span className="text-emerald-400">
                  {s25State.assistantRoleGranted
                    ? 'ROLE_ASSISTANT: SIMULATED GRANTED'
                    : 'ROLE_ASSISTANT: REQUIRED'}
                </span>
              </div>
            </div>

            {/* Voice / Text Command Input Form */}
            <form onSubmit={handleSubmit} className="mt-6 space-y-3" noValidate>
              <label
                htmlFor="velora-voice-input"
                className="block text-xs font-medium text-slate-300"
              >
                Say &ldquo;{preferences.wakeWord}&rdquo; or enter a command (supports negation, volume, timers, and compound tasks):
              </label>
              <div className="flex flex-col sm:flex-row gap-2.5">
                <input
                  id="velora-voice-input"
                  type="text"
                  value={inputUtterance}
                  onChange={(e) => {
                    setInputUtterance(e.target.value);
                    if (validationError) setValidationError(null);
                  }}
                  placeholder={`"${preferences.wakeWord}, lock my Windows workstation and set a 15 minute timer..."`}
                  className="flex-1 bg-[#0B0F17] border border-slate-700 rounded-lg px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-400"
                />
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={handleTriggerWakeWordMic}
                    disabled={isProcessingCommand}
                    aria-label="Simulate Wake Word Microphone Capture"
                    className="px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-medium rounded-lg border border-slate-700 transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
                  >
                    <Mic className="w-4 h-4 text-sky-400" />
                    <span>Simulate &ldquo;{preferences.wakeWord}&rdquo;</span>
                  </button>
                  <button
                    type="submit"
                    disabled={isProcessingCommand}
                    className="px-4 py-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-semibold text-xs rounded-lg transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isProcessingCommand ? 'Dispatching...' : 'Send Command'}</span>
                  </button>
                </div>
              </div>
              {validationError && (
                <p role="alert" className="text-xs text-rose-400 font-medium">
                  {validationError}
                </p>
              )}
            </form>
          </div>

          {/* Preset Quick Utterances */}
          <div className="mt-6 pt-5 border-t border-slate-800/80">
            <div className="text-xs text-slate-400 mb-2.5">
              Verified Voice Utterances (Test structured parsing and execution):
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {PRESET_VOICE_COMMANDS.map((cmd) => (
                <button
                  key={cmd}
                  type="button"
                  disabled={isProcessingCommand}
                  onClick={() => {
                    setValidationError(null);
                    onSendVoiceCommand(cmd);
                  }}
                  className="text-left px-3 py-2 rounded-lg bg-[#0B0F17] hover:bg-slate-800/80 border border-slate-800 text-xs text-slate-300 hover:text-white transition-colors truncate cursor-pointer"
                  title={cmd}
                >
                  &ldquo;{cmd}&rdquo;
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Right 5 Cols: Hardware Bridge Simulation */}
        <section
          aria-labelledby="hardware-bridge-heading"
          className="lg:col-span-5 bg-[#111726] border border-slate-800 rounded-xl p-6 flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-800/80">
              <h2
                id="hardware-bridge-heading"
                className="text-base font-semibold text-white font-display"
              >
                Simulated Hardware State
              </h2>
              <span className="text-xs font-mono text-slate-400 tabular-nums">
                Loopback Authorization
              </span>
            </div>

            {/* Device 1: Samsung Galaxy S25 Ultra */}
            <div className="mt-4 pb-5 border-b border-slate-800/80">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Smartphone className="w-4 h-4 text-sky-400 shrink-0" />
                  <span className="text-sm font-semibold text-white">
                    Samsung Galaxy S25 Ultra (Simulated)
                  </span>
                </div>
                <span className="text-xs font-mono text-emerald-400 tabular-nums">
                  Battery {s25State.batteryPercent}% · {s25State.npuTempCelsius}°C
                </span>
              </div>

              <div className="mt-2 text-xs text-slate-400">
                <span>SM-S938U</span>
                <span className="mx-1.5" aria-hidden="true">·</span>
                <span>Android 16 One UI 8 Model</span>
                <span className="mx-1.5" aria-hidden="true">·</span>
                <span>Screen: {s25State.screenState}</span>
              </div>

              {/* Interactive S25 Ultra State Controls */}
              <div className="mt-4 grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() =>
                    setS25State((prev) => ({
                      ...prev,
                      screenState:
                        prev.screenState === 'SCREEN_OFF' ? 'UNLOCKED' : 'SCREEN_OFF',
                    }))
                  }
                  className="px-3 py-2 rounded-lg bg-[#0B0F17] border border-slate-800 hover:border-slate-700 text-xs font-medium text-slate-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Screen: {s25State.screenState === 'SCREEN_OFF' ? 'Off (Doze)' : 'Unlocked'}
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setS25State((prev) => ({ ...prev, dndEnabled: !prev.dndEnabled }))
                  }
                  className="px-3 py-2 rounded-lg bg-[#0B0F17] border border-slate-800 hover:border-slate-700 text-xs font-medium text-slate-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  DND: {s25State.dndEnabled ? 'Priority On' : 'Off'}
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setS25State((prev) => ({ ...prev, torchEnabled: !prev.torchEnabled }))
                  }
                  className="px-3 py-2 rounded-lg bg-[#0B0F17] border border-slate-800 hover:border-slate-700 text-xs font-medium text-slate-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Torch: {s25State.torchEnabled ? 'Active' : 'Off'}
                </button>
              </div>
            </div>

            {/* Device 2: Windows 11 Companion Workstation */}
            <div className="mt-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Monitor className="w-4 h-4 text-sky-400 shrink-0" />
                  <span className="text-sm font-semibold text-white">
                    {workstation.hostname} (Simulated)
                  </span>
                </div>
                <span
                  className={`text-xs font-mono tabular-nums ${
                    workstation.isPaired ? 'text-emerald-400' : 'text-amber-400'
                  }`}
                >
                  {workstation.isPaired ? 'Paired (Simulated)' : 'Unpaired'}
                </span>
              </div>

              <div className="mt-1.5 text-xs text-slate-400">
                <span>{workstation.osVersion}</span>
                <span className="mx-1.5" aria-hidden="true">·</span>
                <span>{workstation.locked ? 'Session Locked' : 'Session Unlocked'}</span>
              </div>

              {/* Telemetry Grid */}
              <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3 py-3 px-3.5 bg-[#0B0F17] border border-slate-800 rounded-lg font-mono">
                <div>
                  <div className="text-[11px] text-slate-400">CPU Load</div>
                  <div className="text-sm font-semibold text-white tabular-nums">
                    {workstation.cpuLoadPercent}%
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">GPU Temp</div>
                  <div className="text-sm font-semibold text-white tabular-nums">
                    {workstation.gpuTempCelsius}°C
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">Memory</div>
                  <div className="text-sm font-semibold text-white tabular-nums">
                    {workstation.ramUsedGb} GB
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">Audio</div>
                  <div className="text-sm font-semibold text-white tabular-nums">
                    {workstation.audioMuted ? 'Muted' : `${workstation.volumeLevel}%`}
                  </div>
                </div>
              </div>

              <div className="mt-3 text-xs text-slate-400 truncate">
                <span className="text-slate-500">Foreground: </span>
                <span className="font-mono text-slate-300">
                  {workstation.activeForegroundWindow}
                </span>
              </div>
            </div>
          </div>

          {/* Action Shortcut Strip */}
          <div className="mt-6 pt-4 border-t border-slate-800/80 grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => onNavigateTab('windows')}
              className="px-2.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span>PC Allowlist</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigateTab('routines')}
              className="px-2.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Camera className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span>Vision &amp; Routines</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigateTab('architecture')}
              className="px-2.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white transition-colors flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Terminal className="w-3.5 h-3.5 text-sky-400 shrink-0" />
              <span>Kotlin Source</span>
            </button>
          </div>
        </section>
      </div>

      {/* Full-Width 4-Column Architectural Status Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#111726] border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Wake-Word Feasibility</div>
          <div className="mt-1 text-base font-semibold text-white font-display">
            Unresolved DSP HAL
          </div>
          <div className="mt-1 text-xs text-slate-400 font-mono tabular-nums">
            Stock OEM Signing Required · MVP: Gesture
          </div>
        </div>
        <div className="bg-[#111726] border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Windows Companion Model</div>
          <div className="mt-1 text-base font-semibold text-white font-display">
            Session 0 + User Agent
          </div>
          <div className="mt-1 text-xs text-slate-400 font-mono tabular-nums">
            Single-Use Nonce + Allowlist Gate
          </div>
        </div>
        <div className="bg-[#111726] border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Intelligence Provider</div>
          <div className="mt-1 text-base font-semibold text-white font-display">
            OpenAI (Server-Side)
          </div>
          <div className="mt-1 text-xs text-slate-400 font-mono tabular-nums">
            GPT-4o-mini · Safe Demo Fallback
          </div>
        </div>
        <div className="bg-[#111726] border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400">Prototype Environment</div>
          <div className="mt-1 text-base font-semibold text-white font-display tabular-nums">
            Loopback Testbench
          </div>
          <div className="mt-1 text-xs text-slate-400 font-mono tabular-nums">
            React SPA + Node Express Daemon
          </div>
        </div>
      </div>

      {/* Voice Session Transcript & Execution Receipt Log */}
      <section
        aria-labelledby="session-log-heading"
        className="bg-[#111726] border border-slate-800 rounded-xl p-6"
      >
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h2
              id="session-log-heading"
              className="text-lg font-semibold text-white font-display"
            >
              VoiceInteractionSession Simulated Execution Transcript
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Structured log of spoken commands, parsed intent plans, simulated tool dispatches, and
              provider responses.
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400 tabular-nums">
            {conversation.length} {conversation.length === 1 ? 'Turn' : 'Turns'}
          </span>
        </div>

        <div className="mt-4 divide-y divide-slate-800/80">
          {conversation.map((turn) => {
            const receipts: ToolReceipt[] =
              turn.toolExecutionReceipts ||
              (turn.toolExecutionReceipt ? [turn.toolExecutionReceipt] : []);

            return (
              <article key={turn.id} className="py-5 first:pt-1 last:pb-1 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400 font-mono">
                  <div>
                    <span className="text-sky-400 font-medium">User Command</span>
                    <span className="mx-2" aria-hidden="true">·</span>
                    <span>Domain: {turn.intent.targetDomain}</span>
                    <span className="mx-2" aria-hidden="true">·</span>
                    <span className="tabular-nums">
                      Wake Word: {turn.intent.wakeWordDetected ? 'Verified' : 'Direct'}
                    </span>
                    {turn.intent.isNegated && (
                      <>
                        <span className="mx-2" aria-hidden="true">·</span>
                        <span className="text-amber-400 font-semibold">[NEGATED]</span>
                      </>
                    )}
                  </div>
                  <span className="tabular-nums">{turn.timestamp}</span>
                </div>

                <p className="text-sm font-medium text-white">
                  &ldquo;{turn.userUtterance}&rdquo;
                </p>

                {/* Structured Tool Receipts with Explicit Confirmation Button */}
                {receipts.length > 0 && (
                  <div className="space-y-2">
                    {receipts.map((rcpt, idx) => (
                      <div
                        key={`${turn.id}-rcpt-${idx}`}
                        className="py-2.5 px-3.5 rounded-lg bg-[#0B0F17] border border-slate-800 font-mono text-xs flex flex-wrap items-center justify-between gap-2"
                      >
                        <div className="text-slate-300">
                          <span
                            className={
                              rcpt.status === 'CONFIRMATION_REQUIRED'
                                ? 'text-amber-400 font-semibold'
                                : rcpt.status.includes('ERROR') || rcpt.status.includes('RESTRICTED')
                                ? 'text-rose-400 font-semibold'
                                : 'text-emerald-400 font-semibold'
                            }
                          >
                            [{rcpt.target}]
                          </span>{' '}
                          <span>{rcpt.actionId}</span>
                          <span className="mx-2 text-slate-600">&rarr;</span>
                          <span>{rcpt.summary}</span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span
                            className={`tabular-nums ${
                              rcpt.status === 'CONFIRMATION_REQUIRED'
                                ? 'text-amber-400'
                                : 'text-emerald-400'
                            }`}
                          >
                            {rcpt.status}
                          </span>

                          {rcpt.status === 'CONFIRMATION_REQUIRED' && rcpt.confirmationToken && (
                            <button
                              type="button"
                              disabled={confirmingToken === rcpt.confirmationToken}
                              onClick={() =>
                                handleConfirmReceipt(rcpt.actionId, rcpt.confirmationToken!)
                              }
                              className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded text-xs transition-colors cursor-pointer"
                            >
                              {confirmingToken === rcpt.confirmationToken
                                ? 'Confirming...'
                                : 'Confirm Action'}
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Spoken Assistant Reply */}
                <div className="flex items-start gap-3 pt-1">
                  <Volume2 className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                  <div className="space-y-1.5">
                    <p className="text-sm text-slate-200 leading-relaxed">
                      {turn.spokenResponse}
                    </p>
                    <div className="text-xs text-slate-500 font-mono">
                      {turn.reasoningSteps.join(' · ')}
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </section>
    </div>
  );
};
