import React, { useState } from 'react';
import {
  Check,
  Copy,
  AlertTriangle,
  Info,
} from 'lucide-react';
import {
  evaluateAndroid16MicPolicy,
  type Android16Route,
  type ScreenState,
  type AppProcessState,
} from '../utils/veloraEngine';
import {
  VELORA_PHASES,
  SOURCE_FILE_ARTIFACTS,
} from '../data/kotlinBlueprintData';

export const KotlinArchitectureView: React.FC = () => {
  const [selectedRoute, setSelectedRoute] = useState<Android16Route>(
    'VOICE_INTERACTION_SERVICE_DSP'
  );
  const [screenState, setScreenState] = useState<ScreenState>('SCREEN_OFF');
  const [processState, setProcessState] =
    useState<AppProcessState>('CACHED_BACKGROUND');
  const [isDefaultAssistant, setIsDefaultAssistant] = useState<boolean>(true);

  const [selectedFileId, setSelectedFileId] = useState<string>(
    SOURCE_FILE_ARTIFACTS[2].id
  );
  const [copiedFileId, setCopiedFileId] = useState<string | null>(null);

  const policyResult = evaluateAndroid16MicPolicy({
    route: selectedRoute,
    screenState,
    processState,
    isDefaultDigitalAssistant: isDefaultAssistant,
  });

  const activeFile =
    SOURCE_FILE_ARTIFACTS.find((f) => f.id === selectedFileId) ||
    SOURCE_FILE_ARTIFACTS[0];

  const handleCopyCode = async (fileId: string, code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedFileId(fileId);
      setTimeout(() => setCopiedFileId(null), 1800);
    } catch {
      setCopiedFileId(fileId);
    }
  };

  return (
    <div className="space-y-8">
      {/* Section 1: Android 16 Background Mic & FGS Restriction Analyzer */}
      <section
        aria-labelledby="android16-analyzer-heading"
        className="bg-[#111726] border border-slate-800 rounded-xl p-6"
      >
        <div className="pb-4 border-b border-slate-800">
          <div className="text-xs text-slate-400 font-mono">
            <span>Android 16 (API 36) Technical Feasibility Study</span>
            <span className="mx-2" aria-hidden="true">·</span>
            <span>Samsung Galaxy S25 Ultra (One UI 8.0)</span>
            <span className="mx-2" aria-hidden="true">·</span>
            <span>Background Microphone &amp; FGS Policy</span>
          </div>
          <h1
            id="android16-analyzer-heading"
            className="mt-2 text-2xl font-bold text-white font-display"
          >
            Android 16 Background Mic Restrictions &amp; VoiceInteractionService Analysis
          </h1>
          <p className="mt-1.5 text-sm text-slate-300 max-w-3xl leading-relaxed">
            Android 14–16 strictly blocks background apps from starting{' '}
            <code className="text-sky-300 font-mono text-xs">
              FOREGROUND_SERVICE_TYPE_MICROPHONE
            </code>{' '}
            or reading <code className="text-sky-300 font-mono text-xs">AudioRecord</code> without a visible window.
            Evaluate the architectural routes below across simulated S25 Ultra device states:
          </p>
        </div>

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Controls Column */}
          <div className="lg:col-span-6 space-y-4">
            <div>
              <span className="block text-xs font-medium text-slate-300 mb-2">
                1. Select Android Microphone &amp; Wake-Word Architecture Route
              </span>
              <div className="space-y-2">
                {(
                  [
                    {
                      id: 'VOICE_INTERACTION_SERVICE_DSP',
                      title: 'Supported Route: VoiceInteractionService + AlwaysOnHotwordDetector',
                      subtitle:
                        'System-bound ROLE_ASSISTANT service. (Subject to hardware DSP enrollment limitations)',
                    },
                    {
                      id: 'FOREGROUND_SERVICE_MIC',
                      title: 'Hack Route: Persistent ForegroundService (microphone)',
                      subtitle:
                        'Throws ForegroundServiceStartNotAllowedException from background in Android 14–16',
                    },
                    {
                      id: 'STANDARD_MIC_PERMISSION',
                      title: 'Naive Route: Ordinary RECORD_AUDIO in Activity / Worker',
                      subtitle:
                        'Silenced immediately by Android 16 privacy sandbox when backgrounded or screen-off',
                    },
                  ] as const
                ).map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setSelectedRoute(opt.id)}
                    className={`w-full text-left p-3.5 rounded-lg border transition-colors cursor-pointer ${
                      selectedRoute === opt.id
                        ? 'bg-sky-500/10 border-sky-400 text-white'
                        : 'bg-[#0B0F17] border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="text-xs font-semibold">{opt.title}</div>
                    <div className="text-xs text-slate-400 mt-0.5">{opt.subtitle}</div>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              <div>
                <label
                  htmlFor="sim-screen-state"
                  className="block text-xs font-medium text-slate-300 mb-1.5"
                >
                  2. S25 Ultra Screen State
                </label>
                <select
                  id="sim-screen-state"
                  value={screenState}
                  onChange={(e) => setScreenState(e.target.value as ScreenState)}
                  className="w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-400"
                >
                  <option value="SCREEN_OFF">Screen Off (Samsung Doze / Pocket)</option>
                  <option value="LOCK_SCREEN">Lock Screen (Keyguard Active)</option>
                  <option value="UNLOCKED">Unlocked &amp; Interactive</option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="sim-process-state"
                  className="block text-xs font-medium text-slate-300 mb-1.5"
                >
                  3. App Process State
                </label>
                <select
                  id="sim-process-state"
                  value={processState}
                  onChange={(e) => setProcessState(e.target.value as AppProcessState)}
                  className="w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-400"
                >
                  <option value="CACHED_BACKGROUND">No Visible Activity (Background)</option>
                  <option value="FOREGROUND_SERVICE">Running Foreground Service</option>
                  <option value="TOP_ACTIVITY">Visible Top Activity</option>
                </select>
              </div>
            </div>

            <label className="flex items-center justify-between gap-3 pt-2 text-xs text-slate-300 cursor-pointer">
              <span>User granted RoleManager.ROLE_ASSISTANT in Android Settings</span>
              <input
                type="checkbox"
                checked={isDefaultAssistant}
                onChange={(e) => setIsDefaultAssistant(e.target.checked)}
                className="w-4 h-4 accent-sky-400"
              />
            </label>
          </div>

          {/* Verdict Output Column */}
          <div className="lg:col-span-6 bg-[#0B0F17] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <span className="text-xs font-mono text-slate-400">
                  Android 16 OS Policy Verdict
                </span>
                <span
                  className={`text-xs font-mono font-semibold ${
                    policyResult.verdict === 'SUPPORTED_ROLE_SERVICE_WITH_RESERVATIONS'
                      ? 'text-emerald-400'
                      : policyResult.verdict === 'UNRELIABLE_OEM_KILL'
                      ? 'text-amber-400'
                      : 'text-rose-400'
                  }`}
                >
                  {policyResult.verdict}
                </span>
              </div>

              <div className="mt-4 grid grid-cols-3 divide-x divide-slate-800 border-y border-slate-800 py-3 font-mono text-xs">
                <div className="pr-3">
                  <div className="text-slate-400">Wake Word</div>
                  <div
                    className={`mt-1 font-semibold ${
                      policyResult.canListenForWakeWord ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {policyResult.canListenForWakeWord ? 'ACTIVE' : 'BLOCKED'}
                  </div>
                </div>
                <div className="px-3">
                  <div className="text-slate-400">Mic Session</div>
                  <div
                    className={`mt-1 font-semibold ${
                      policyResult.canStartMicSession ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {policyResult.canStartMicSession ? 'PRIVILEGED' : 'DENIED'}
                  </div>
                </div>
                <div className="pl-3">
                  <div className="text-slate-400">One UI 8 Doze</div>
                  <div
                    className={`mt-1 font-semibold ${
                      policyResult.survivesSamsungDoze ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {'NOT DEVICE-TESTED'}
                  </div>
                </div>
              </div>

              <div className="mt-4 text-xs text-slate-200 leading-relaxed">
                {policyResult.technicalReason}
              </div>

              {/* Hardware Reality / Platform Feasibility Warning */}
              <div className="mt-4 p-3 rounded-lg bg-amber-950/30 border border-amber-800/60 text-xs text-amber-200/90 leading-relaxed">
                <div className="font-semibold flex items-center gap-1.5 mb-1 text-amber-300">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                  <span>Hardware Feasibility Reality Check</span>
                </div>
                {policyResult.hardwareRealityNotice}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800">
              <div className="text-xs text-slate-400 mb-1.5">
                Required Manifest &amp; System Contracts:
              </div>
              <div className="text-xs font-mono text-sky-300">
                {policyResult.requiredComponents.join(' · ')}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Practical MVP Architecture Banner */}
      <section className="bg-[#111726] border border-slate-800 rounded-xl p-6">
        <h2 className="text-base font-semibold text-white font-display flex items-center gap-2">
          <Info className="w-4 h-4 text-sky-400" />
          <span>Recommended Practical Assistant MVP for Galaxy S25 Ultra</span>
        </h2>
        <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-300">
          <div className="p-3.5 rounded-lg bg-[#0B0F17] border border-slate-800">
            <div className="font-semibold text-white mb-1">1. Assistant Gesture Invocation</div>
            <p className="text-slate-400 leading-relaxed">
              Register as Default Digital Assistant via <code className="text-sky-300">RoleManager.ROLE_ASSISTANT</code>.
              Users invoke Velora instantly via long-press Power button, corner swipe, or S Pen button.
            </p>
          </div>
          <div className="p-3.5 rounded-lg bg-[#0B0F17] border border-slate-800">
            <div className="font-semibold text-white mb-1">2. Push-to-Talk Quick Settings Tile</div>
            <p className="text-slate-400 leading-relaxed">
              Provides an accessible 1-tap invocation directly from the notification shade or lockscreen
              without needing always-listening background audio.
            </p>
          </div>
          <div className="p-3.5 rounded-lg bg-[#0B0F17] border border-slate-800">
            <div className="font-semibold text-white mb-1">3. Active-Screen Wake Word</div>
            <p className="text-slate-400 leading-relaxed">
              While the screen is on or during an active session, run lightweight on-device models
              (e.g., Sherpa-ONNX or Porcupine) to detect &ldquo;Velora&rdquo; without OEM DSP enrollment.
            </p>
          </div>
        </div>
      </section>

      {/* Section 2: Incomplete Architectural Blueprints */}
      <section
        aria-labelledby="source-code-studio-heading"
        className="bg-[#111726] border border-slate-800 rounded-xl p-6"
      >
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h2
              id="source-code-studio-heading"
              className="text-lg font-semibold text-white font-display"
            >
              Native Kotlin &amp; Windows C# Reference Blueprints (Incomplete Snippets)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Illustrative architectural references showing target native patterns. These are incomplete code
              snippets for design planning, not compiled native artifacts.
            </p>
          </div>
          <button
            type="button"
            onClick={() => handleCopyCode(activeFile.id, activeFile.code)}
            className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
          >
            {copiedFileId === activeFile.id ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Copied Reference</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-sky-400" />
                <span>Copy Reference Code</span>
              </>
            )}
          </button>
        </div>

        {/* File Selector Tabs */}
        <div className="mt-4 flex flex-wrap gap-2">
          {SOURCE_FILE_ARTIFACTS.map((file) => (
            <button
              key={file.id}
              type="button"
              onClick={() => setSelectedFileId(file.id)}
              className={`px-3 py-2 rounded-lg text-xs font-mono transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer ${
                selectedFileId === file.id
                  ? 'bg-sky-500 text-slate-950 font-semibold'
                  : 'bg-[#0B0F17] text-slate-300 border border-slate-800 hover:border-slate-700'
              }`}
            >
              <span>{file.phaseNumber}.</span>
              <span>{file.filename}</span>
            </button>
          ))}
        </div>

        {/* Selected File Notice & Missing Implementations */}
        <div className="mt-4 p-4 rounded-xl bg-amber-950/20 border border-amber-800/50 space-y-2 text-xs">
          <div className="text-amber-300 font-semibold font-mono">
            STATUS: {activeFile.statusNotice}
          </div>
          <div className="text-slate-300">
            <span className="font-medium text-slate-200">Missing for real native compilation:</span>{' '}
            {activeFile.missingImplementations.join(', ')}.
          </div>
        </div>

        {/* Code Block */}
        <div className="mt-3 bg-[#0B0F17] border border-slate-800 rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
            <span className="text-slate-300">{activeFile.path}</span>
            <span className="text-slate-400">{activeFile.targetPlatform}</span>
          </div>
          <pre className="p-4 text-xs font-mono text-slate-200 overflow-x-auto leading-relaxed">
            <code>{activeFile.code}</code>
          </pre>
        </div>
      </section>

      {/* Section 3: Evidence-Based Roadmap Progression */}
      <section
        aria-labelledby="roadmap-progression-heading"
        className="bg-[#111726] border border-slate-800 rounded-xl p-6"
      >
        <div className="pb-4 border-b border-slate-800">
          <h2
            id="roadmap-progression-heading"
            className="text-lg font-semibold text-white font-display"
          >
            Velora Architecture Roadmap &amp; Evidence-Based Status
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Truthful breakdown distinguishing working prototype functionality, incomplete blueprints,
            and unresolved native platform questions.
          </p>
        </div>

        <div className="mt-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {VELORA_PHASES.map((phase) => (
            <div
              key={phase.id}
              className="bg-[#0B0F17] border border-slate-800 rounded-xl p-5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-sky-400 font-semibold">
                    Phase {phase.number}
                  </span>
                  <span
                    className={`font-semibold ${
                      phase.implementationStatus === 'PROTOTYPE_SIMULATION'
                        ? 'text-emerald-400'
                        : phase.implementationStatus === 'UNRESOLVED_PLATFORM_LIMITATION'
                        ? 'text-amber-400'
                        : 'text-slate-400'
                    }`}
                  >
                    {phase.statusLabel}
                  </span>
                </div>
                <h3 className="mt-2 text-base font-semibold text-white font-display">
                  {phase.number}. {phase.title}
                </h3>
                <p className="mt-1.5 text-xs text-slate-400 leading-relaxed">
                  {phase.summary}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 space-y-2 text-xs">
                <div className="text-slate-400 font-medium">Platform Reality Notes:</div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  {phase.platformRealityNotes}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
