import { apiFetch } from '../api';
import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Plus,
  Camera,
  RotateCcw,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
} from 'lucide-react';
import {
  buildRoutineExecutionPlan,
  type VeloraRoutine,
  type PcActionId,
  type RoutineExecutionReport,
} from '../utils/veloraEngine';
import type { VeloraPreferences } from '../types/velora';

interface RoutinesAndVisionViewProps {
  routines: VeloraRoutine[];
  setRoutines: React.Dispatch<React.SetStateAction<VeloraRoutine[]>>;
  isWindowsPaired: boolean;
  onExecuteRoutine: (routine: VeloraRoutine) => Promise<RoutineExecutionReport>;
  preferences: VeloraPreferences;
  setPreferences: React.Dispatch<React.SetStateAction<VeloraPreferences>>;
  onExecuteRecommendedPcAction: (actionId: PcActionId) => Promise<void>;
}

const CAMERA_DIAGNOSTIC_SCENES = [
  {
    id: 'win11-bsod-panel',
    label: 'Gradle Heap Stall',
    subtitle: 'Synthetic Test Frame · Metaspace OOM Pattern',
    prompt:
      'Velora, inspect this simulated screen pattern and identify the build issue.',
  },
  {
    id: 's25-usb-adb-bridge',
    label: 'Android 16 RoleManager',
    subtitle: 'Synthetic Test Frame · ROLE_ASSISTANT Screen Model',
    prompt:
      'Velora, verify how RoleManager.ROLE_ASSISTANT affects wake-word privileges.',
  },
  {
    id: 'workstation-thermals',
    label: 'RTX 5090 Thermals',
    subtitle: 'Synthetic Test Frame · Hardware Sensor Pattern',
    prompt: 'Velora, check if these simulated GPU thermals are within safe operating margins.',
  },
];

export const RoutinesAndVisionView: React.FC<RoutinesAndVisionViewProps> = ({
  routines,
  setRoutines,
  isWindowsPaired,
  onExecuteRoutine,
  preferences,
  setPreferences,
  onExecuteRecommendedPcAction,
}) => {
  const [runningRoutineId, setRunningRoutineId] = useState<string | null>(null);
  const [routineReport, setRoutineReport] = useState<RoutineExecutionReport | null>(null);

  // New Custom Routine Form State
  const [newRoutineName, setNewRoutineName] = useState('');
  const [newRoutineTrigger, setNewRoutineTrigger] = useState('');
  const [newRoutinePcAction, setNewRoutinePcAction] = useState<PcActionId>('LOCK_WORKSTATION');
  const [routineFormError, setRoutineFormError] = useState<string | null>(null);

  // Synthetic Vision Assistance State
  const [selectedSceneId, setSelectedSceneId] = useState<string>('win11-bsod-panel');
  const [visionPrompt, setVisionPrompt] = useState<string>(
    CAMERA_DIAGNOSTIC_SCENES[0].prompt
  );
  const [isAnalyzingFrame, setIsAnalyzingFrame] = useState(false);
  const [visionResult, setVisionResult] = useState<{
    detectedComponent: string;
    diagnosticSummary: string;
    suggestedActionLabel: string;
    suggestedPcActionId?: PcActionId;
    analysisType: string;
    isSyntheticTestPattern: boolean;
  } | null>(null);
  const [actionAppliedMsg, setActionAppliedMsg] = useState<string | null>(null);

  const viewfinderCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Draw deterministic simulated test pattern onto canvas
  useEffect(() => {
    const canvas = viewfinderCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.fillStyle = '#090D16';
    ctx.fillRect(0, 0, w, h);

    // Subtle test grid
    ctx.strokeStyle = '#1E293B';
    ctx.lineWidth = 1;
    for (let x = 40; x < w; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 40; y < h; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // Viewfinder brackets
    ctx.strokeStyle = '#38BDF8';
    ctx.lineWidth = 2;
    const m = 16;
    const len = 22;
    ctx.beginPath();
    ctx.moveTo(m, m + len);
    ctx.lineTo(m, m);
    ctx.lineTo(m + len, m);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(w - m - len, m);
    ctx.lineTo(w - m, m);
    ctx.lineTo(w - m, m + len);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(m, h - m - len);
    ctx.lineTo(m, h - m);
    ctx.lineTo(m + len, h - m);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(w - m - len, h - m);
    ctx.lineTo(w - m, h - m);
    ctx.lineTo(w - m, h - m - len);
    ctx.stroke();

    // Scene-specific visual test patterns
    ctx.font = '600 13px "JetBrains Mono", monospace';
    ctx.fillStyle = '#F59E0B';
    ctx.fillText('[SYNTHETIC TEST PATTERN · SIMULATED VIEWFINDER]', 32, 42);

    ctx.fillStyle = '#111827';
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1;
    ctx.fillRect(32, 58, w - 64, h - 96);
    ctx.strokeRect(32, 58, w - 64, h - 96);

    ctx.font = '600 14px "Plus Jakarta Sans", sans-serif';
    ctx.fillStyle = '#F8FAFC';

    if (selectedSceneId === 'win11-bsod-panel') {
      ctx.fillText('Simulated Monitor: Gradle Daemon Build Failure', 48, 88);
      ctx.font = '400 12px "JetBrains Mono", monospace';
      ctx.fillStyle = '#F87171';
      ctx.fillText('ERROR: java.lang.OutOfMemoryError: Metaspace (Worker #4)', 48, 114);
      ctx.fillStyle = '#94A3B8';
      ctx.fillText('Simulated Memory: 58.2 / 64.0 GB · Stale Lockfiles: 3', 48, 136);
      ctx.fillStyle = '#38BDF8';
      ctx.fillText('Simulated Diagnostic Rule: CLEAR_TEMP_CACHE recommended', 48, 162);
    } else if (selectedSceneId === 's25-usb-adb-bridge') {
      ctx.fillText('Simulated Settings: Android 16 Digital Assistant Role', 48, 88);
      ctx.font = '400 12px "JetBrains Mono", monospace';
      ctx.fillStyle = '#34D399';
      ctx.fillText('RoleManager.ROLE_ASSISTANT = com.velora.assistant (Assigned)', 48, 114);
      ctx.fillStyle = '#94A3B8';
      ctx.fillText('Note: Hardware DSP hotword on stock retail S25 Ultra is unresolved', 48, 136);
      ctx.fillStyle = '#38BDF8';
      ctx.fillText('Practical MVP: Long-press power button / Assistant gesture', 48, 162);
    } else {
      ctx.fillText('Simulated Sensor HUD: Workstation GPU/CPU Thermals', 48, 88);
      ctx.font = '400 12px "JetBrains Mono", monospace';
      ctx.fillStyle = '#34D399';
      ctx.fillText('RTX 5090 Core: 52.0°C · VRAM Junction: 60.0°C · Fan: 1150 RPM', 48, 114);
      ctx.fillStyle = '#94A3B8';
      ctx.fillText('Ryzen 9 9950X Package: 49.5°C · Load: 18% · Power: 285W', 48, 136);
      ctx.fillStyle = '#38BDF8';
      ctx.fillText('Status: Nominal operating envelope; keep awake permitted', 48, 162);
    }
  }, [selectedSceneId]);

  const handleRunRoutine = async (routine: VeloraRoutine) => {
    setRunningRoutineId(routine.id);
    setRoutineReport(null);
    try {
      const report = await onExecuteRoutine(routine);
      setRoutineReport(report);
    } finally {
      setRunningRoutineId(null);
    }
  };

  const handleToggleRoutineStep = (routineId: string, stepId: string) => {
    setRoutines((prev) => {
      const updated = prev.map((r) => {
        if (r.id !== routineId) return r;
        return {
          ...r,
          steps: r.steps.map((s) => (s.id === stepId ? { ...s, enabled: !s.enabled } : s)),
        };
      });
      try {
        localStorage.setItem('velora_1_0_routines', JSON.stringify(updated));
      } catch {
        // Ignore
      }
      return updated;
    });
  };

  const handleCreateCustomRoutine = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = newRoutineName.trim();
    const trimmedTrigger = newRoutineTrigger.trim();
    if (!trimmedName || !trimmedTrigger) {
      setRoutineFormError('Provide both a routine title and a typed command trigger phrase.');
      return;
    }
    setRoutineFormError(null);
    const created: VeloraRoutine = {
      id: `routine-custom-${Date.now()}`,
      name: trimmedName,
      voiceTrigger: trimmedTrigger,
      description: 'Custom prototype routine spanning S25 Ultra and Windows companion service.',
      lastRunAt: 'Never run',
      steps: [
        {
          id: `step-a-${Date.now()}`,
          target: 'S25_ULTRA',
          actionLabel: 'Set Priority Do Not Disturb on S25 Ultra',
          commandKey: 'SET_DND_MODE',
          enabled: true,
          estimatedMs: 90,
        },
        {
          id: `step-b-${Date.now()}`,
          target: 'WINDOWS_11_PC',
          actionLabel: `Execute ${newRoutinePcAction} on Windows 11 PC`,
          commandKey: newRoutinePcAction,
          enabled: true,
          estimatedMs: 160,
        },
      ],
    };

    setRoutines((prev) => {
      const updated = [created, ...prev];
      try {
        localStorage.setItem('velora_1_0_routines', JSON.stringify(updated));
      } catch {
        // Ignore
      }
      return updated;
    });

    setNewRoutineName('');
    setNewRoutineTrigger('');
  };

  const handleInspectCameraFrame = async () => {
    setIsAnalyzingFrame(true);
    setActionAppliedMsg(null);
    try {
      const res = await apiFetch('/api/velora/camera-assist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sceneId: selectedSceneId,
          prompt: visionPrompt,
        }),
      });
      const data = await res.json();
      setVisionResult(data);
    } catch {
      setActionAppliedMsg('Network error connecting to diagnostic analyzer.');
    } finally {
      setIsAnalyzingFrame(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Split: Synthetic Diagnostic Frames + Prototype Preferences */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Left 7 Cols: Synthetic Visual Frame Diagnostics */}
        <section
          aria-labelledby="camerax-assist-heading"
          className="lg:col-span-7 bg-[#111726] border border-slate-800 rounded-xl p-6 flex flex-col justify-between"
        >
          <div>
            <div className="text-xs text-slate-400 font-mono">
              <span className="text-amber-400 font-semibold">[PROTOTYPE SIMULATION]</span>
              <span className="mx-2" aria-hidden="true">·</span>
              <span>Synthetic Diagnostic Pattern</span>
              <span className="mx-2" aria-hidden="true">·</span>
              <span>Simulated Vision Model</span>
            </div>

            <h1
              id="camerax-assist-heading"
              className="mt-3 text-2xl font-bold text-white font-display"
            >
              Simulated Viewfinder Frame Diagnostics
            </h1>
            <p className="mt-1.5 text-sm text-slate-300">
              Evaluates how visual context (such as workstation error patterns or settings screens)
              can be analyzed by the assistant. In this web prototype, synthetic test frames are
              evaluated against fixed diagnostic rules. No images are sent to OpenAI.
            </p>

            {/* Scene Selector Buttons */}
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-2">
              {CAMERA_DIAGNOSTIC_SCENES.map((scene) => (
                <button
                  key={scene.id}
                  type="button"
                  onClick={() => {
                    setSelectedSceneId(scene.id);
                    setVisionPrompt(scene.prompt);
                    setActionAppliedMsg(null);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    selectedSceneId === scene.id
                      ? 'bg-sky-500 text-slate-950 font-semibold'
                      : 'bg-[#0B0F17] text-slate-300 border border-slate-800 hover:border-slate-700'
                  }`}
                >
                  {scene.label}
                </button>
              ))}
            </div>

            {/* Viewfinder Canvas */}
            <div className="mt-4">
              <canvas
                ref={viewfinderCanvasRef}
                width={560}
                height={200}
                data-testid="camerax-viewfinder-canvas"
                className="w-full h-48 rounded-lg border border-slate-800 block bg-[#090D16]"
              />
            </div>

            {/* Prompt & Analyze Trigger */}
            <div className="mt-4 flex flex-col sm:flex-row gap-2.5">
              <label htmlFor="camerax-prompt-input" className="sr-only">
                Diagnostic question
              </label>
              <input
                id="camerax-prompt-input"
                type="text"
                value={visionPrompt}
                onChange={(e) => setVisionPrompt(e.target.value)}
                className="flex-1 bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-400"
              />
              <button
                type="button"
                disabled={isAnalyzingFrame}
                onClick={handleInspectCameraFrame}
                className="px-4 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-950 font-semibold text-xs flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>{isAnalyzingFrame ? 'Evaluating...' : 'Evaluate Test Pattern'}</span>
              </button>
            </div>
          </div>

          {/* Vision Analysis Output Card */}
          {visionResult && (
            <div className="mt-5 pt-4 border-t border-slate-800 space-y-2.5 text-xs">
              <div className="flex items-center justify-between font-mono text-slate-400">
                <span className="text-amber-400 font-semibold">
                  {visionResult.detectedComponent}
                </span>
                <span className="text-slate-500">{visionResult.analysisType}</span>
              </div>
              <p className="text-slate-300 leading-relaxed">{visionResult.diagnosticSummary}</p>
              <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                <span className="text-sky-300 font-mono">
                  Suggested Action: {visionResult.suggestedActionLabel}
                </span>
                {visionResult.suggestedPcActionId && (
                  <button
                    type="button"
                    onClick={async () => {
                      try { await onExecuteRecommendedPcAction(visionResult.suggestedPcActionId!);
                      setActionAppliedMsg(
                        `Simulation completed: ${visionResult.suggestedPcActionId}.`
                      );
                      } catch (error) { setActionAppliedMsg(error instanceof Error ? error.message : "Action failed."); }
                    }}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    Execute {visionResult.suggestedPcActionId}
                  </button>
                )}
              </div>
              {actionAppliedMsg && (
                <div role="status" className="text-slate-300 font-mono">{actionAppliedMsg}</div>
              )}
            </div>
          )}
        </section>

        {/* Right 5 Cols: Prototype Preferences (Simulating Jetpack DataStore) */}
        <section
          aria-labelledby="datastore-prefs-heading"
          className="lg:col-span-5 bg-[#111726] border border-slate-800 rounded-xl p-6 flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h2
                id="datastore-prefs-heading"
                className="text-base font-semibold text-white font-display"
              >
                Prototype Assistant Preferences
              </h2>
              <span className="text-xs font-mono text-amber-400">Browser Prototype Store</span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Saved in this browser. Screen-lock rules apply to the sandbox; reply length applies to optional OpenAI chat.
            </p>

            <div className="mt-4 space-y-4 text-xs">
              <div>
                <label
                  htmlFor="pref-wake-word"
                  className="block font-medium text-slate-300 mb-1.5"
                >
                  Text command prefix (microphone not connected)
                </label>
                <input
                  id="pref-wake-word" maxLength={40}
                  type="text"
                  value={preferences.wakeWord}
                  onChange={(e) =>
                    setPreferences((prev) => ({
                      ...prev,
                      wakeWord: e.target.value || 'Velora',
                    }))
                  }
                  className="w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-sky-400"
                />
              </div>

<p className="text-slate-400">Choose her device voice in Conversation → Voice and appearance settings.</p>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label htmlFor="pref-speech-rate" className="font-medium text-slate-300">
                    Speech Cadence Rate
                  </label>
                  <span className="font-mono text-sky-400 tabular-nums">
                    {preferences.speechRate.toFixed(2)}x
                  </span>
                </div>
                <input
                  id="pref-speech-rate"
                  type="range"
                  min={0.85}
                  max={1.35}
                  step={0.05}
                  value={preferences.speechRate}
                  onChange={(e) =>
                    setPreferences((prev) => ({
                      ...prev,
                      speechRate: Number(e.target.value),
                    }))
                  }
                  className="w-full accent-sky-400"
                />
              </div>

              <div>
                <span className="block font-medium text-slate-300 mb-1.5">
                  Response Verbosity Mode
                </span>
                <div className="grid grid-cols-2 gap-2">
                  {(['CONCISE', 'DETAILED'] as const).map((mode) => (
                    <button
                      key={mode}
                      type="button"
                      onClick={() =>
                        setPreferences((prev) => ({ ...prev, verbosity: mode }))
                      }
                      className={`py-2 px-3 rounded-lg font-medium transition-colors cursor-pointer ${
                        preferences.verbosity === mode
                          ? 'bg-sky-500 text-slate-950 font-semibold'
                          : 'bg-[#0B0F17] text-slate-300 border border-slate-800'
                      }`}
                    >
                      {mode === 'CONCISE' ? 'Concise Mode' : 'Detailed Replies'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2 space-y-2.5 border-t border-slate-800/80">
                <label className="flex items-center justify-between gap-3 cursor-pointer">
                  <span className="text-slate-300">
                    Allow Windows PC actions while S25 Ultra screen is off/locked
                  </span>
                  <input
                    type="checkbox"
                    checked={preferences.allowLockScreenPcActions}
                    onChange={(e) =>
                      setPreferences((prev) => ({
                        ...prev,
                        allowLockScreenPcActions: e.target.checked,
                      }))
                    }
                    className="w-4 h-4 accent-sky-400"
                  />
                </label>

<p className="text-slate-400">Configure confirmation rules in PC sandbox. Biometrics are not implemented.</p>
              </div>
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>Stored in browser localStorage</span>
            <button
              type="button"
              onClick={() =>
                setPreferences({
                  wakeWord: 'Velora',
                  voicePersona: 'Alloy-Tactical',
                  speechRate: 1.05,
                  verbosity: 'CONCISE',
                  allowLockScreenPcActions: false,
                  cameraAutoOcr: false,
                  requireBiometricForLock: false,
                })
              }
              className="text-slate-300 hover:text-white flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Defaults</span>
            </button>
          </div>
        </section>
      </div>

      {/* Multi-Device Routines Section */}
      <section
        aria-labelledby="routines-engine-heading"
        className="bg-[#111726] border border-slate-800 rounded-xl p-6"
      >
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h2
              id="routines-engine-heading"
              className="text-lg font-semibold text-white font-display"
            >
              Multi-Device Assistant Routines (S25 Ultra + Windows 11)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Simulates multi-step workflows. Typed command triggers and button executions route
              through the exact same execution plan with measured per-step verification.
            </p>
          </div>
        </div>

        {/* Routine Execution Result Report Banner */}
        {routineReport && (
          <div
            role="status"
            className={`mt-4 p-4 rounded-xl border text-xs font-mono space-y-2.5 ${
              routineReport.status === 'COMPLETED'
                ? 'bg-emerald-950/40 border-emerald-700/60 text-emerald-200'
                : routineReport.status === 'PARTIAL_SUCCESS'
                ? 'bg-amber-950/40 border-amber-700/60 text-amber-200'
                : 'bg-rose-950/40 border-rose-700/60 text-rose-200'
            }`}
          >
            <div className="flex items-center justify-between font-semibold text-sm">
              <span>{routineReport.summaryMessage}</span>
              <span className="tabular-nums">
                Total Measured Time: {routineReport.totalMeasuredMs} ms
              </span>
            </div>

            <div className="space-y-1.5 pt-2 border-t border-slate-800/80">
              {routineReport.stepResults.map((st, idx) => (
                <div key={`${st.stepId}-${idx}`} className="flex items-center justify-between gap-2">
                  <span>
                    0{idx + 1}. [{st.target}] {st.actionLabel} &rarr; {st.message}
                  </span>
                  <span
                    className={
                      st.status === 'SUCCESS'
                        ? 'text-emerald-400 font-bold'
                        : st.status === 'SKIPPED'
                        ? 'text-slate-400'
                        : 'text-amber-400 font-bold'
                    }
                  >
                    {st.status} ({st.measuredDurationMs} ms)
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Routine Cards Grid */}
        <div className="mt-5 grid grid-cols-1 lg:grid-cols-3 gap-5">
          {routines.map((routine) => {
            const plan = buildRoutineExecutionPlan(routine, isWindowsPaired);
            return (
              <div
                key={routine.id}
                className="bg-[#0B0F17] border border-slate-800 rounded-xl p-5 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
                    <span>&ldquo;{routine.voiceTrigger}&rdquo;</span>
                    <span className="tabular-nums">~{plan.totalEstimatedMs} ms est.</span>
                  </div>

                  <h3 className="mt-2 text-base font-semibold text-white font-display">
                    {routine.name}
                  </h3>
                  <p className="mt-1 text-xs text-slate-400 leading-relaxed">
                    {routine.description}
                  </p>

                  <div className="mt-4 space-y-2 border-t border-slate-800/80 pt-3">
                    {routine.steps.map((step, idx) => (
                      <label
                        key={step.id}
                        className="flex items-start justify-between gap-2 text-xs cursor-pointer"
                      >
                        <div className="text-slate-300">
                          <span className="font-mono text-slate-500 mr-1.5">
                            0{idx + 1}.
                          </span>
                          <span className="font-mono text-sky-400 mr-1.5">
                            [{step.target === 'S25_ULTRA' ? 'S25' : 'WIN11'}]
                          </span>
                          <span className={step.enabled ? 'text-slate-200' : 'line-through text-slate-500'}>
                            {step.actionLabel}
                          </span>
                        </div>
                        <input
                          type="checkbox"
                          checked={step.enabled}
                          onChange={() => handleToggleRoutineStep(routine.id, step.id)}
                          className="mt-0.5 accent-sky-400 shrink-0"
                        />
                      </label>
                    ))}
                  </div>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-xs text-slate-400 font-mono">
                    {routine.lastRunAt || 'Ready'}
                  </span>
                  <button
                    type="button"
                    disabled={!plan.ready || runningRoutineId === routine.id}
                    onClick={() => handleRunRoutine(routine)}
                    className="px-3.5 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-950 font-semibold text-xs flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50"
                  >
                    <Play className="w-3.5 h-3.5" />
                    <span>
                      {runningRoutineId === routine.id ? 'Running...' : `Run ${routine.name}`}
                    </span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Create New Routine Form */}
        <form
          onSubmit={handleCreateCustomRoutine}
          className="mt-6 pt-5 border-t border-slate-800"
          noValidate
        >
          <div className="text-xs font-semibold text-slate-200 mb-3">
            Add Custom Multi-Device Routine (Persisted Locally)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div>
              <label htmlFor="new-routine-name" className="block text-xs text-slate-400 mb-1">
                Routine Title
              </label>
              <input
                id="new-routine-name"
                type="text"
                value={newRoutineName}
                onChange={(e) => {
                  setNewRoutineName(e.target.value);
                  if (routineFormError) setRoutineFormError(null);
                }}
                placeholder="e.g. Late Night Coding"
                className="w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-400"
              />
            </div>
            <div>
              <label htmlFor="new-routine-trigger" className="block text-xs text-slate-400 mb-1">
                Typed Command Trigger Phrase
              </label>
              <input
                id="new-routine-trigger"
                type="text"
                value={newRoutineTrigger}
                onChange={(e) => {
                  setNewRoutineTrigger(e.target.value);
                  if (routineFormError) setRoutineFormError(null);
                }}
                placeholder='e.g. "Velora, late night coding"'
                className="w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-400"
              />
            </div>
            <div>
              <label htmlFor="new-routine-pc-action" className="block text-xs text-slate-400 mb-1">
                Paired Windows Action
              </label>
              <select
                id="new-routine-pc-action"
                value={newRoutinePcAction}
                onChange={(e) => setNewRoutinePcAction(e.target.value as PcActionId)}
                className="w-full bg-[#0B0F17] border border-slate-700 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-400"
              >
                <option value="LAUNCH_DEVELOPMENT_ENV">Launch Development Workspace</option>
                <option value="LOCK_WORKSTATION">Lock Windows 11 Session</option>
                <option value="MUTE_AUDIO">Mute Master Audio</option>
                <option value="SUSPEND_SLEEP_TIMER">Suspend Idle Sleep Timer</option>
                <option value="CLEAR_TEMP_CACHE">Purge Gradle Temp Cache</option>
              </select>
            </div>
            <div className="flex items-end">
              <button
                type="submit"
                className="w-full px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-white flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5 text-sky-400" />
                <span>Save Routine</span>
              </button>
            </div>
          </div>
          {routineFormError && (
            <p role="alert" className="mt-2 text-xs text-rose-400">
              {routineFormError}
            </p>
          )}
        </form>
      </section>
    </div>
  );
};
