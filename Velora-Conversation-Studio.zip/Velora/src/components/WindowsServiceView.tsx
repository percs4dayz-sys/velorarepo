import React, { useState } from 'react';
import {
  KeyRound,
  Lock,
  Unlock,
  RefreshCw,
} from 'lucide-react';
import type { WindowsWorkstationState, AuditLogEntry } from '../types/velora';
import type { PcActionPolicy, PcActionId } from '../utils/veloraEngine';

interface WindowsServiceViewProps {
  workstation: WindowsWorkstationState;
  policies: PcActionPolicy[];
  auditLog: AuditLogEntry[];
  onExecutePcAction: (params: {
    actionId: string;
    useInvalidToken?: boolean;
    useReplayNonce?: boolean;
    confirmationToken?: string;
    confirmedByUser?: boolean;
    payload?: Record<string, unknown>;
  }) => Promise<{
    allowed: boolean;
    status: string;
    reason: string;
    confirmationToken?: string;
  } | void>;
  onTogglePolicy: (
    actionId: PcActionId,
    updates: { approved?: boolean; requiresConfirmation?: boolean }
  ) => Promise<void>;
  onPairingAction: (
    action: 'ROTATE_TOKEN' | 'TOGGLE_PAIRING' | 'UNLOCK_WORKSTATION'
  ) => Promise<void>;
}

export const WindowsServiceView: React.FC<WindowsServiceViewProps> = ({
  workstation,
  policies,
  auditLog,
  onExecutePcAction,
  onTogglePolicy,
  onPairingAction,
}) => {
  const [auditSearch, setAuditSearch] = useState('');
  const [auditFilter, setAuditFilter] = useState<'ALL' | 'APPROVED' | 'DENIED'>('ALL');
  const [volumeDraft, setVolumeDraft] = useState<number>(workstation.volumeLevel);
  const [lastDispatchBanner, setLastDispatchBanner] = useState<{
    allowed: boolean;
    message: string;
    code: string;
  } | null>(null);
  const [pendingConfirmation, setPendingConfirmation] = useState<{
    actionId: string;
    confirmationToken: string;
    reason: string;
  } | null>(null);
  const [isBusy, setIsBusy] = useState(false);

  const handleRunAction = async (params: {
    actionId: string;
    useInvalidToken?: boolean;
    useReplayNonce?: boolean;
    confirmationToken?: string;
    confirmedByUser?: boolean;
    payload?: Record<string, unknown>;
  }) => {
    setIsBusy(true);
    setPendingConfirmation(null);
    try {
      const res = await onExecutePcAction(params);
      if (res) {
        if (res.status === 'CONFIRMATION_REQUIRED' && res.confirmationToken) {
          setPendingConfirmation({
            actionId: params.actionId,
            confirmationToken: res.confirmationToken,
            reason: res.reason,
          });
          setLastDispatchBanner({
            allowed: false,
            message: res.reason,
            code: 'WARN_WIN_CONFIRM_GATE',
          });
        } else {
          setLastDispatchBanner({
            allowed: res.allowed,
            message: res.reason,
            code: res.allowed ? 'OK_WIN_EXEC_200' : res.status,
          });
        }
      }
    } finally {
      setIsBusy(false);
    }
  };

  const filteredAudit = auditLog.filter((entry) => {
    if (auditFilter === 'APPROVED' && !entry.allowed) return false;
    if (auditFilter === 'DENIED' && entry.allowed) return false;
    if (!auditSearch.trim()) return true;
    const q = auditSearch.toLowerCase();
    return (
      entry.actionId.toLowerCase().includes(q) ||
      entry.detail.toLowerCase().includes(q) ||
      entry.auditCode.toLowerCase().includes(q) ||
      entry.source.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-8">
      {/* Header & Device Pairing Handshake Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <section
          aria-labelledby="win-service-overview"
          className="lg:col-span-7 bg-[#111726] border border-slate-800 rounded-xl p-6 flex flex-col justify-between"
        >
          <div>
            <div className="text-xs text-slate-400 font-mono">
              <span className="text-amber-400 font-semibold">[PROTOTYPE SIMULATION]</span>
              <span className="mx-2" aria-hidden="true">·</span>
              <span>Loopback Daemon Model</span>
              <span className="mx-2" aria-hidden="true">·</span>
              <span>Zero-Trust Allowlist</span>
            </div>

            <h1
              id="win-service-overview"
              className="mt-3 text-2xl font-bold text-white font-display"
            >
              Simulated Windows Companion Service &amp; Allowlist
            </h1>
            <p className="mt-2 text-sm text-slate-300 leading-relaxed">
              Models a zero-trust Windows background service. In this test environment, actions are
              simulated on local loopback. In production, an Interactive User Session Agent (Session 1+)
              is required to execute desktop-level actions like <code className="text-sky-300 font-mono text-xs">LockWorkStation()</code> or launch GUI apps.
            </p>

            {/* Live Workstation Status Row */}
            <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-lg bg-[#0B0F17] border border-slate-800 font-mono">
              <div>
                <div className="text-xs text-slate-400">Session State</div>
                <div className="mt-1 text-sm font-semibold text-white">
                  {workstation.locked ? 'LOCKED' : 'ACTIVE'}
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-400">CPU / GPU</div>
                <div className="mt-1 text-sm font-semibold text-white tabular-nums">
                  {workstation.cpuLoadPercent}% · {workstation.gpuTempCelsius}°C
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-400">Memory Used</div>
                <div className="mt-1 text-sm font-semibold text-white tabular-nums">
                  {workstation.ramUsedGb} / {workstation.ramTotalGb} GB
                </div>
              </div>
              <div>
                <div className="text-xs text-slate-400">Sleep Timer</div>
                <div className="mt-1 text-sm font-semibold text-white">
                  {workstation.sleepTimerSuspended ? 'KEPT AWAKE' : 'STANDARD'}
                </div>
              </div>
            </div>

            <div className="mt-4 space-y-2 text-xs border-t border-slate-800/80 pt-3">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Active Foreground Window</span>
                <span className="font-mono text-slate-200 truncate max-w-xs">
                  {workstation.activeForegroundWindow}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Host OS &amp; Uptime</span>
                <span className="font-mono text-slate-300 tabular-nums">
                  {workstation.osVersion} · {workstation.uptimeHours}h
                </span>
              </div>
            </div>
          </div>

          {/* Volume & Session Quick Controls */}
          <div className="mt-6 pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <label
                htmlFor="win-volume-slider"
                className="text-xs font-medium text-slate-300 whitespace-nowrap"
              >
                Master Audio ({workstation.audioMuted ? 'Muted' : `${workstation.volumeLevel}%`}):
              </label>
              <input
                id="win-volume-slider"
                type="range"
                min={0}
                max={100}
                value={volumeDraft}
                onChange={(e) => setVolumeDraft(Number(e.target.value))}
                className="w-28 accent-sky-400"
              />
              <button
                type="button"
                disabled={isBusy}
                onClick={() =>
                  handleRunAction({
                    actionId: 'SET_VOLUME',
                    payload: { volume: volumeDraft },
                  })
                }
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                Apply Volume
              </button>
            </div>

            <div className="flex items-center gap-2">
              {workstation.locked ? (
                <button
                  type="button"
                  onClick={() => onPairingAction('UNLOCK_WORKSTATION')}
                  className="px-3.5 py-2 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-xs font-medium text-emerald-300 flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Unlock className="w-3.5 h-3.5" />
                  <span>Simulate Desktop PIN Unlock</span>
                </button>
              ) : (
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() =>
                    handleRunAction({
                      actionId: 'LOCK_WORKSTATION',
                    })
                  }
                  className="px-3.5 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-xs font-semibold text-slate-950 flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5" />
                  <span>Request Workstation Lock</span>
                </button>
              )}
            </div>
          </div>
        </section>

        {/* Right 5 Cols: Device Pairing & Non-Secret Status */}
        <section
          aria-labelledby="pairing-handshake-heading"
          className="lg:col-span-5 bg-[#111726] border border-slate-800 rounded-xl p-6 flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h2
                id="pairing-handshake-heading"
                className="text-base font-semibold text-white font-display"
              >
                S25 Ultra &harr; Windows 11 Pairing
              </h2>
              <span
                className={`text-xs font-mono ${
                  workstation.isPaired ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {workstation.isPaired ? 'HANDSHAKE_ACTIVE' : 'PAIRING_REVOKED'}
              </span>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div className="flex items-center justify-between py-2 border-b border-slate-800/70">
                <span className="text-slate-400">Paired Android Client</span>
                <span className="font-medium text-white">{workstation.pairedDeviceName}</span>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-slate-800/70">
                <span className="text-slate-400">Hardware Attestation</span>
                <span className="font-mono text-slate-300">{workstation.pairedDeviceModel}</span>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-slate-800/70">
                <span className="text-slate-400">Local console authentication</span>
                <code className="font-mono text-sky-300">
                  {workstation.tokenFingerprint || 'Redacted for Security'}
                </code>
              </div>
            </div>

            {/* Security Penetration Test Controls */}
            <div className="mt-5 p-3.5 rounded-lg bg-[#0B0F17] border border-slate-800">
              <div className="text-xs font-semibold text-slate-200">
                Zero-Trust Security Verification Tests
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Test how the Windows service enforces security boundaries:
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() =>
                    handleRunAction({
                      actionId: 'GET_STATUS',
                      useInvalidToken: true,
                    })
                  }
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-amber-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Test rejected body credential (403)
                </button>
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() =>
                    handleRunAction({
                      actionId: 'RAW_POWERSHELL_EXEC',
                    })
                  }
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-rose-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Test Unapproved Shell (403)
                </button>
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() =>
                    handleRunAction({
                      actionId: 'GET_STATUS',
                      useReplayNonce: true,
                    })
                  }
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-amber-300 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  Test Duplicate Nonce (403)
                </button>
              </div>
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-800 flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={() => onPairingAction('ROTATE_TOKEN')}
              className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5 text-sky-400" />
              <span>Revoke pending approvals</span>
            </button>
            <button
              type="button"
              onClick={() => onPairingAction('TOGGLE_PAIRING')}
              className="px-3.5 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
              <span>{workstation.isPaired ? 'Revoke Device Pairing' : 'Pair S25 Ultra'}</span>
            </button>
          </div>
        </section>
      </div>

      {/* Confirmation Dialog Box */}
      {pendingConfirmation && (
        <div
          role="dialog"
          aria-label="Action Confirmation Dialog"
          className="p-4 rounded-xl bg-amber-950/40 border border-amber-600/60 text-xs flex flex-wrap items-center justify-between gap-4"
        >
          <div>
            <div className="text-amber-200 font-semibold text-sm">
              Explicit User Confirmation Required
            </div>
            <p className="text-slate-300 mt-0.5">
              {pendingConfirmation.reason} (Single-use token generated with 60s expiration).
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setPendingConfirmation(null)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={isBusy}
              onClick={() =>
                handleRunAction({
                  actionId: pendingConfirmation.actionId,
                  confirmationToken: pendingConfirmation.confirmationToken,
                })
              }
              className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition-colors cursor-pointer"
            >
              Confirm and Execute {pendingConfirmation.actionId}
            </button>
          </div>
        </div>
      )}

      {lastDispatchBanner && (
        <div
          role="status"
          className={`px-4 py-3 rounded-lg border text-xs font-mono flex items-center justify-between gap-4 ${
            lastDispatchBanner.allowed
              ? 'bg-emerald-950/40 border-emerald-700/60 text-emerald-200'
              : 'bg-rose-950/40 border-rose-700/60 text-rose-200'
          }`}
        >
          <span>{lastDispatchBanner.message}</span>
          <span className="shrink-0 font-semibold">{lastDispatchBanner.code}</span>
        </div>
      )}

      {/* Allowlisted PC Actions Table */}
      <section
        aria-labelledby="allowlist-matrix-heading"
        className="bg-[#111726] border border-slate-800 rounded-xl p-6"
      >
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h2
              id="allowlist-matrix-heading"
              className="text-lg font-semibold text-white font-display"
            >
              Approved PC Action Allowlist Policy Matrix
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Toggle which actions Velora is permitted to run on your Windows 11 PC and test them
              directly against the live backend service.
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400 tabular-nums">
            {policies.filter((p) => p.approved).length} of {policies.length} Actions Enabled
          </span>
        </div>

        <div className="mt-4 overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-xs text-slate-400 font-mono">
                <th className="py-3 pr-4 font-medium">Action Identifier &amp; Description</th>
                <th className="py-3 px-4 font-medium">Service Endpoint</th>
                <th className="py-3 px-4 font-medium">Allowlist Policy</th>
                <th className="py-3 px-4 font-medium">Confirmation Gate</th>
                <th className="py-3 pl-4 text-right font-medium">Test Dispatch</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70 text-sm">
              {policies.map((policy) => (
                <tr key={policy.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3.5 pr-4">
                    <div className="font-medium text-white">{policy.label}</div>
                    <div className="text-xs text-slate-400 mt-0.5">
                      <span className="font-mono text-slate-300">{policy.id}</span>
                      <span className="mx-1.5" aria-hidden="true">·</span>
                      <span>{policy.description}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4 font-mono text-xs text-sky-300 whitespace-nowrap">
                    {policy.endpoint}
                  </td>
                  <td className="py-3.5 px-4">
                    {policy.category === 'RESTRICTED' ? (
                      <span className="text-xs font-mono text-rose-400">
                        PERMANENTLY BLOCKED
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() =>
                          onTogglePolicy(policy.id, { approved: !policy.approved })
                        }
                        aria-label={`Toggle approval for ${policy.label}`}
                        className={`px-3 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                          policy.approved
                            ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                            : 'bg-slate-800 text-slate-400 border border-slate-700'
                        }`}
                      >
                        {policy.approved ? 'Approved' : 'Disabled'}
                      </button>
                    )}
                  </td>
                  <td className="py-3.5 px-4">
                    {policy.category === 'RESTRICTED' ? (
                      <span className="text-xs font-mono text-slate-500">N/A</span>
                    ) : (
                      <button
                        type="button"
                        onClick={() =>
                          onTogglePolicy(policy.id, {
                            requiresConfirmation: !policy.requiresConfirmation,
                          })
                        }
                        aria-label={`Toggle confirmation requirement for ${policy.label}`}
                        className="px-3 py-1 rounded-md bg-[#0B0F17] border border-slate-800 hover:border-slate-700 text-xs text-slate-300 whitespace-nowrap shrink-0 cursor-pointer"
                      >
                        {policy.requiresConfirmation ? 'Required' : 'Immediate'}
                      </button>
                    )}
                  </td>
                  <td className="py-3.5 pl-4 text-right">
                    <button
                      type="button"
                      disabled={isBusy}
                      onClick={() =>
                        handleRunAction({
                          actionId: policy.id,
                          payload: policy.id === "SET_VOLUME" ? {volume: volumeDraft} : undefined,
                        })
                      }
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                    >
                      Run {policy.id}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Windows Service Audit Log */}
      <section
        aria-labelledby="win-audit-heading"
        className="bg-[#111726] border border-slate-800 rounded-xl p-6"
      >
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h2
              id="win-audit-heading"
              className="text-lg font-semibold text-white font-display"
            >
              Windows Service Security Audit Log (Redacted)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Event log of authenticated actions, nonce validation, and blocked intrusion attempts.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1 p-1 bg-[#0B0F17] border border-slate-800 rounded-lg">
              {(['ALL', 'APPROVED', 'DENIED'] as const).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => setAuditFilter(mode)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    auditFilter === mode
                      ? 'bg-slate-800 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {mode === 'ALL' ? 'All Events' : mode === 'APPROVED' ? 'Approved' : 'Blocked'}
                </button>
              ))}
            </div>

            <div className="relative">
              <label htmlFor="audit-search-input" className="sr-only">
                Search audit log
              </label>
              <input
                id="audit-search-input"
                type="text"
                value={auditSearch}
                onChange={(e) => setAuditSearch(e.target.value)}
                placeholder="Filter by action or code..."
                className="bg-[#0B0F17] border border-slate-800 rounded-lg pl-3 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-400"
              />
            </div>
          </div>
        </div>

        {filteredAudit.length === 0 ? (
          <div className="py-8 text-center text-sm text-slate-400">
            No audit events match your current filter criteria.
          </div>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left border-collapse font-mono text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2.5 pr-4 font-medium">Status</th>
                  <th className="py-2.5 px-4 font-medium">Action ID</th>
                  <th className="py-2.5 px-4 font-medium">Source Client</th>
                  <th className="py-2.5 px-4 font-medium">Execution Detail</th>
                  <th className="py-2.5 pl-4 text-right font-medium">Latency</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredAudit.map((entry) => (
                  <tr key={entry.id}>
                    <td className="py-3 pr-4 whitespace-nowrap">
                      <span
                        className={
                          entry.allowed ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'
                        }
                      >
                        {entry.auditCode}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-white whitespace-nowrap">{entry.actionId}</td>
                    <td className="py-3 px-4 text-slate-400 whitespace-nowrap">{entry.source}</td>
                    <td className="py-3 px-4 text-slate-300 font-sans">{entry.detail}</td>
                    <td className="py-3 pl-4 text-right text-slate-400 tabular-nums whitespace-nowrap">
                      {entry.latencyMs} ms
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};
