import React,{useEffect,useRef,useState} from 'react';
import {ArrowUp,Volume2,Square,Upload,Expand,Minimize2,SlidersHorizontal} from 'lucide-react';
import type {ConversationTurn} from '../types/velora';
import {mouthFrame,rms} from '../utils/avatarAudio';
import './avatar.css';

const expressions=[{id:'neutral',label:'Neutral',src:'mouth-0.jpg'},{id:'happy',label:'Sparkles',src:'happy.jpg'},{id:'surprised',label:'Surprised',src:'surprised.jpg'},{id:'embarrassed',label:'Blushing',src:'embarrassed.jpg'},{id:'angry',label:'Angry',src:'angry.jpg'}];
const previewText='Hi Steve. I’m here. This is the first preview of your Velora conversation face. You can choose my expression, change my voice, or interrupt me whenever you need to.';
function appearance(){try{return JSON.parse(localStorage.getItem('velora_avatar')||'{}');}catch{return {};}}
type Props={conversation:ConversationTurn[];busy:boolean;provider:string;speechRate:number;onSend:(text:string)=>Promise<void>;onConfirm:(actionId:string,token:string)=>Promise<void>};

export function AvatarConversation({conversation,busy,provider,speechRate,onSend,onConfirm}:Props){
  const [expression,setExpression]=useState(()=>expressions.some(e=>e.id===appearance().expression)?appearance().expression:'neutral');
  const [frame,setFrame]=useState(0);
  const [speaking,setSpeaking]=useState(false);
  const [audioMode,setAudioMode]=useState('');
  const [error,setError]=useState('');
  const [text,setText]=useState('');
  const [autoRead,setAutoRead]=useState(()=>appearance().autoRead===true);
  const [motion,setMotion]=useState(()=>!window.matchMedia('(prefers-reduced-motion: reduce)').matches&&appearance().motion!==false);
  const [settings,setSettings]=useState(false);
  const [large,setLarge]=useState(false);
  const [voices,setVoices]=useState<SpeechSynthesisVoice[]>([]);
  const [voiceName,setVoiceName]=useState<string>(()=>typeof appearance().voiceName==='string'?appearance().voiceName:'');
  const [gain,setGain]=useState(1.5);
  const [custom,setCustom]=useState<string|null>(null);
  const [confirming,setConfirming]=useState<string|null>(null);
  const context=useRef<AudioContext|null>(null);
  const source=useRef<AudioBufferSourceNode|null>(null);
  const animation=useRef(0);
  const generation=useRef(0);
  const customUrl=useRef<string|null>(null);
  const lastRead=useRef<string|null>(conversation[0]?.id||null);
  const motionRef=useRef(motion);motionRef.current=motion;
  const gainRef=useRef(gain);gainRef.current=gain;
  const latest=conversation[0];
  useEffect(()=>{try{localStorage.setItem('velora_avatar',JSON.stringify({expression,voiceName,autoRead,motion}));}catch{}},[expression,voiceName,autoRead,motion]);

  function stop(){generation.current++;cancelAnimationFrame(animation.current);window.speechSynthesis?.cancel();try{source.current?.stop();}catch{}source.current=null;setSpeaking(false);setFrame(0);setAudioMode('');}
  useEffect(()=>{
    const synth=window.speechSynthesis;
    if(!synth)return;
    const refresh=()=>{const list=synth.getVoices();setVoices(list);setVoiceName(prev=>prev||list.find(v=>/zira|jenny|samantha|female/i.test(v.name))?.name||list.find(v=>v.lang.startsWith('en'))?.name||list[0]?.name||'');};
    refresh();synth.addEventListener('voiceschanged',refresh);
    return()=>{synth.removeEventListener('voiceschanged',refresh);};
  },[]);
  useEffect(()=>{for(const file of [...expressions.map(e=>e.src),'mouth-1.jpg','mouth-2.jpg','mouth-3.jpg']){const img=new Image();img.src='/avatar/'+file;}return()=>{generation.current++;cancelAnimationFrame(animation.current);window.speechSynthesis?.cancel();try{source.current?.stop();}catch{}void context.current?.close();if(customUrl.current)URL.revokeObjectURL(customUrl.current);};},[]);
  useEffect(()=>{if(!motion)setFrame(0);},[motion]);
  useEffect(()=>{const visibility=()=>{if(document.hidden)stop();};document.addEventListener('visibilitychange',visibility);return()=>document.removeEventListener('visibilitychange',visibility);},[]);
  useEffect(()=>{if(!latest||lastRead.current===latest.id)return;lastRead.current=latest.id;if(autoRead)speak(latest.spokenResponse);},[latest?.id,autoRead]);

  function speak(words:string){
    stop();setError('');
    if(!window.speechSynthesis){setError('Device speech is unavailable here. Use the sample audio or open this page in Edge or Chrome.');return;}
    const turn=generation.current;
    const speech=new SpeechSynthesisUtterance(words.slice(0,4000));
    speech.voice=voices.find(v=>v.name===voiceName)||null;speech.rate=speechRate;
    let started=0;let boundaryAt=0;
    speech.onstart=()=>{if(generation.current!==turn)return;setSpeaking(true);setAudioMode('Device voice · estimated mouth timing');started=performance.now();tick();};
    speech.onboundary=()=>{boundaryAt=performance.now();};
    function tick(){if(generation.current!==turn)return;const t=performance.now()-started;const pulse=Math.max(0,Math.sin(t/72)*0.65+Math.sin(t/137)*0.35);setFrame(motionRef.current?mouthFrame(pulse*0.14+(performance.now()-boundaryAt<90?0.025:0)):0);animation.current=requestAnimationFrame(tick);}
    speech.onend=()=>{if(generation.current!==turn)return;cancelAnimationFrame(animation.current);setFrame(0);setSpeaking(false);setAudioMode('');};
    speech.onerror=e=>{if(generation.current!==turn)return;cancelAnimationFrame(animation.current);setFrame(0);setSpeaking(false);setError(`Device voice could not play (${e.error}). Try the sample audio.`);};
    window.speechSynthesis.speak(speech);
  }
  async function playAudio(file?:File){
    stop();setError('');const turn=generation.current;
    try{
      if(file&&file.size>25*1024*1024)throw new Error('Choose an audio file under 25 MB.');
      const ctx=context.current ||= new AudioContext();await ctx.resume();
      const bytes=file?await file.arrayBuffer():await fetch('/avatar/preview.wav').then(r=>{if(!r.ok)throw new Error('Sample audio unavailable.');return r.arrayBuffer();});
      const buffer=await ctx.decodeAudioData(bytes);
      if(turn!==generation.current)return;
      const player=ctx.createBufferSource();player.buffer=buffer;const analyser=ctx.createAnalyser();analyser.fftSize=1024;
      player.connect(analyser);analyser.connect(ctx.destination);source.current=player;
      const samples=new Float32Array(analyser.fftSize);setSpeaking(true);setAudioMode(file?'Your audio · sound-driven mouth movement':'Sample voice · sound-driven mouth movement');
      let last=0;
      function tick(now:number){if(turn!==generation.current)return;if(now-last>65){analyser.getFloatTimeDomainData(samples);setFrame(motionRef.current?mouthFrame(rms(samples),gainRef.current):0);last=now;}animation.current=requestAnimationFrame(tick);}
      player.onended=()=>{player.disconnect();analyser.disconnect();if(turn!==generation.current)return;cancelAnimationFrame(animation.current);setFrame(0);setSpeaking(false);setAudioMode('');source.current=null;};
      player.start();animation.current=requestAnimationFrame(tick);
    }catch(e){if(turn===generation.current){setError(e instanceof Error?e.message:'Audio playback failed.');setFrame(0);setSpeaking(false);}}
  }
  function choosePortrait(file?:File){if(!file)return;if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>10*1024*1024){setError('Choose a JPG, PNG or WebP under 10 MB.');return;}stop();if(customUrl.current)URL.revokeObjectURL(customUrl.current);customUrl.current=URL.createObjectURL(file);setCustom(customUrl.current);}
  const currentExpression=expressions.find(e=>e.id===expression)!;
  const avatarSrc=custom||'/avatar/'+(speaking&&motion?`mouth-${frame}.jpg`:currentExpression.src);
  async function submit(e:React.FormEvent){e.preventDefault();if(!text.trim()||busy)return;stop();const value=text.trim();setText('');await onSend(value);}

  return <section className={'avatar-space'+(large?' expanded':'')} aria-label="Avatar conversation">
    <div className="avatar-stage">
      <div className="stage-top"><span className="stage-eyebrow">RIGHT HERE WITH YOU</span><button aria-label={large?'Reduce face view':'Enlarge face view'} onClick={()=>setLarge(!large)}>{large?<Minimize2 size={18}/>:<Expand size={18}/>}</button></div>
      <div className={'portrait-orbit'+(speaking?' speaking':'')}>
        
        <div className={'portrait-window'+(custom?' custom':'')}><img src={avatarSrc} alt={custom?'Your selected portrait':`Velora character, ${speaking?'speaking':currentExpression.label.toLowerCase()}`} draggable={false}/></div>
        
      </div>
      <div className="avatar-name">Velora <span>YOUR COMPANION</span></div>
      <p className="avatar-status" role="status">{speaking?'Speaking with you':busy?'Working on your request':'Here when you’re ready'}</p>
      <div className="expression-picker" aria-label="Choose expression">{expressions.map(e=><button key={e.id} title={e.label} aria-label={`${e.label} expression`} aria-pressed={expression===e.id&&!custom} onClick={()=>{setCustom(null);setExpression(e.id);}}><img src={'/avatar/'+e.src} alt=""/><span>{e.label}</span></button>)}</div>
      <div className="voice-actions"><button className="primary-voice" onClick={()=>playAudio()}><Volume2 size={17}/>Try her voice</button><button onClick={stop} disabled={!speaking} aria-label="Stop speaking"><Square size={15}/>Stop</button><button onClick={()=>setSettings(!settings)} aria-expanded={settings} aria-label="Voice and appearance settings"><SlidersHorizontal size={18}/></button></div>
      <p className="audio-note">{audioMode||'Synthetic voice · Your original artwork'}</p>
      {error&&<p role="alert" className="avatar-error">{error}</p>}
      {settings&&<div className="avatar-settings">
        <label>Device voice<select value={voiceName} onChange={e=>setVoiceName(e.target.value)}>{!voices.length&&<option>No voices available</option>}{voices.map(v=><option key={v.voiceURI} value={v.name}>{v.name} · {v.lang}</option>)}</select></label>
        <button onClick={()=>speak(previewText)}>Preview selected device voice</button>
        <label className="check-option"><input type="checkbox" checked={autoRead} onChange={e=>setAutoRead(e.target.checked)}/>Read new replies aloud</label>
        <label className="check-option"><input type="checkbox" checked={motion} onChange={e=>setMotion(e.target.checked)}/>Animate mouth while speaking</label>
        <label>Audio sensitivity<input aria-label="Audio sensitivity" type="range" min="0.5" max="4" step="0.1" value={gain} onChange={e=>setGain(Number(e.target.value))}/></label>
        <label className="file-label"><Upload size={16}/>Try an audio file<input type="file" accept="audio/*" onChange={e=>{const file=e.target.files?.[0];if(file)void playAudio(file);e.target.value='';}}/></label>
        <label className="file-label"><Upload size={16}/>Choose a different portrait<input type="file" accept="image/jpeg,image/png,image/webp" onChange={e=>choosePortrait(e.target.files?.[0])}/></label>
        <small>Custom portraits stay still. Audio and portraits selected here stay in this browser. Emotes return after speech; they do not yet have individual talking frames.</small>
      </div>}
    </div>
    <div className="conversation-panel"><div className="conversation-heading"><div><span className="stage-eyebrow">CONVERSATION</span><h1>Let’s talk.</h1></div><span className={'provider-badge '+(provider==='ERROR'?'error':'')}>{provider==='OPENAI'?'OpenAI connected':provider==='ERROR'?'Provider error':'Local demo'}</span></div>
      <p className="conversation-intro">A face, a voice, and space to think out loud.</p>
      <div className="chat-scroll" aria-label="Conversation messages" aria-live="polite">
        {!conversation.length&&<div className="welcome-card"><span className="message-speaker">VELORA</span><p>Hi Steve. Your conversation face is ready.</p><p>Try the voice preview, pick an expression, or send me a message.</p><small>{provider==='OPENAI'?'Messages use your configured OpenAI connection.':'This preview uses local demo replies. OpenAI is optional and configured on the server.'}</small></div>}
        {[...conversation].reverse().map(turn=><div className="chat-turn" key={turn.id}><div className="user-message"><span className="message-speaker">YOU</span><p>{turn.userUtterance}</p></div><div className="assistant-message"><span className="message-speaker">VELORA</span><p>{turn.spokenResponse}</p><button className="read-reply" aria-label="Read this reply aloud" onClick={()=>speak(turn.spokenResponse)}><Volume2 size={14}/>Read aloud</button>{turn.toolExecutionReceipts?.filter(r=>r.status==='CONFIRMATION_REQUIRED'&&r.confirmationToken).map(r=><div className="pending-action" key={r.confirmationToken}><p>{r.summary}</p><button disabled={!!confirming} onClick={async()=>{setConfirming(r.confirmationToken!);try{await onConfirm(r.actionId,r.confirmationToken!);}finally{setConfirming(null);}}}>Confirm {r.actionId.replaceAll('_',' ').toLowerCase()}</button></div>)}</div></div>)}
        {busy&&<p className="thinking-message">Working on your request…</p>}
      </div>
      <form className="message-composer" onSubmit={submit}><textarea aria-label="Message Velora" placeholder="Say what’s on your mind…" value={text} onChange={e=>setText(e.target.value)} maxLength={4000} rows={2} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();void submit(e);}}}/><button type="submit" disabled={busy||!text.trim()} aria-label="Send message"><ArrowUp size={21}/></button></form>
      <div className="suggested-prompts">{['Check my PC status','Set a 10 minute timer','Enable Do Not Disturb'].map(q=><button key={q} disabled={busy} onClick={()=>{stop();void onSend(q);}}>{q}</button>)}</div>
      <p className="conversation-footnote">Device actions run in a sandbox. Microphone input and native Android controls are planned.</p>
    </div>
  </section>;
}
