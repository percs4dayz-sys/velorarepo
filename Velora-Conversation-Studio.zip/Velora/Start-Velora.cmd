@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" set "PATH=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin;%PATH%"
where node >nul 2>nul
if errorlevel 1 goto neednode
node -e "const v=process.versions.node.split('.').map(Number);process.exit(v[0]>22||(v[0]===22&&v[1]>=12)?0:1)"
if errorlevel 1 goto neednode
if not exist node_modules\tsx (
  call npm.cmd ci --ignore-scripts
  if errorlevel 1 goto failed
)
call npm.cmd run build
if errorlevel 1 goto failed
set "NODE_ENV=production"
echo Open the local address printed below in your browser. Keep this window open.
call npm.cmd start
if errorlevel 1 goto failed
exit /b 0
:neednode
echo Install Node.js 22.12 or newer from https://nodejs.org and try again.
pause
exit /b 1
:failed
echo Velora could not start. Read the error above, or share it for help.
pause
exit /b 1
