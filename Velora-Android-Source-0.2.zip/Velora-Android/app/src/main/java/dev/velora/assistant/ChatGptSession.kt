package dev.velora.assistant

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import java.net.ServerSocket
import java.net.SocketTimeoutException
import java.util.UUID
import java.util.concurrent.Executors

data class PlanAccount(val client: String,val label: String,val signedIn: Boolean,val permitted: Boolean)
data class PlanModel(val slug: String,val label: String)

/** Application lifetime lets the short-lived callback survive the external browser. */
class ChatGptSession private constructor(context: Context) {
    companion object {
        @Volatile private var instance: ChatGptSession?=null
        fun get(context: Context): ChatGptSession = instance ?: synchronized(this) {
            instance ?: ChatGptSession(context.applicationContext).also {instance=it}
        }
        const val USAGE="https://chatgpt.com/settings/usage"
    }
    private val vault=PlanVault(context)
    private val lock=Any()
    private val refreshLock=Any()
    private val executor=Executors.newSingleThreadExecutor()
    private val main=Handler(Looper.getMainLooper())
    private var state=runCatching {vault.read()}.getOrElse {JSONObject().put("storageWarning",true)}
    private var server: ServerSocket?=null
    private var attempt=0
    @Volatile var signingIn=false;private set
    @Volatile var notice="";private set
    @Volatile var listener:(()->Unit)?=null
    init {
        if(!state.has("host"))state.put("host","urn:uuid:${UUID.randomUUID()}")
        if(!state.has("accounts"))state.put("accounts",JSONArray())
        if(state.optBoolean("storageWarning"))notice="Saved ChatGPT credentials could not be read. Please sign in again."
        vault.write(state)
    }
    private fun records(): List<JSONObject> {val a=state.getJSONArray("accounts");return (0 until a.length()).map {a.getJSONObject(it)}}
    private fun record(client: String): JSONObject = records().firstOrNull {it.getString("client")==client} ?: error("Choose a ChatGPT account first.")
    private fun account(r: JSONObject)=PlanAccount(r.getString("client"),r.optString("email","ChatGPT account")+" · "+r.getString("client").takeLast(6),r.optString("access").isNotBlank()&&!r.optBoolean("signedOut"),r.optString("scope").split(' ').contains(PlanProtocol.PLAN_SCOPE))
    fun accounts(): List<PlanAccount> = synchronized(lock){records().map {account(it)}}
    fun active(): PlanAccount? = synchronized(lock){records().firstOrNull {it.getString("client")==state.optString("active")}?.let {account(it)}}
    fun select(client: String) {synchronized(lock){check(!signingIn);record(client);state.put("active",client);vault.write(state)};changed()}
    fun model(client: String): String = synchronized(lock){record(client).optString("model")}
    fun selectModel(client: String,slug: String) {synchronized(lock){record(client).put("model",slug);vault.write(state)};changed()}
    fun takeNotice(): String {val value=notice;notice="";return value}
    private fun changed(){main.post {listener?.invoke()}}
    fun needsWelcome(): Boolean = synchronized(lock){val a=active();a?.signedIn==true&&a.permitted&&!record(a.client).optBoolean("welcomed")}
    fun welcomeSeen(){synchronized(lock){active()?.let {record(it.client).put("welcomed",true);vault.write(state)}}}

    fun cancelLogin() {
        synchronized(lock){attempt++;server?.close();server=null;signingIn=false}
        notice="Sign-in cancelled. Your existing connection was kept.";changed()
    }
    fun begin(client: String?,forceConsent: Boolean=false): Uri {
        synchronized(lock) {
            check(!signingIn){"A sign-in is already in progress."}
            val old=client?.let {record(it)}
            val listener=ServerSocket(0,4,InetAddress.getByName("127.0.0.1")).apply {soTimeout=1000}
            server=listener
            val redirect="http://127.0.0.1:${listener.localPort}/auth/callback"
            val nonce=PlanProtocol.random();val csrf=PlanProtocol.random();val verifier=PlanProtocol.random()
            val query=linkedMapOf("client_id" to (client?:"dynamic_agent_client"),"ext_agent_host_id" to state.getString("host"),"response_type" to "code","redirect_uri" to redirect,"scope" to PlanProtocol.SCOPES,"resource" to PlanProtocol.RESOURCE,"state" to csrf,"nonce" to nonce,"code_challenge_method" to "S256","code_challenge" to PlanProtocol.challenge(verifier))
            if(client==null)query["agent_name_hint"]="Velora"
            else {
                old?.optString("id")?.takeIf {it.isNotBlank()}?.let {query["id_token_hint"]=it}
                old?.optString("email")?.takeIf {it.isNotBlank()}?.let {query["login_hint"]=it}
            }
            if(forceConsent)query["prompt"]="consent"
            val expectedSubject=old?.getString("subject")
            val current=++attempt;signingIn=true;notice="Finish signing in in your browser, then return to Velora."
            executor.execute {
                try {
                    val (code,issued)=receive(listener,csrf,client,current)
                    val tokens=PlanHttp.json("${PlanProtocol.ISSUER}/api/accounts/oauth/token",mapOf("grant_type" to "authorization_code","client_id" to issued,"code" to code,"code_verifier" to verifier,"redirect_uri" to redirect,"resource" to PlanProtocol.RESOURCE))
                    val claims=PlanProtocol.verifyId(tokens.getString("id_token"),PlanHttp.json("${PlanProtocol.ISSUER}/.well-known/jwks.json"),issued,nonce,expectedSubject)
                    require(tokens.optString("token_type").equals("Bearer",true) && tokens.optString("access_token").isNotBlank()){ "ChatGPT did not return usable credentials." }
                    synchronized(lock) {
                        if(current!=attempt)return@execute
                        val existing=records().firstOrNull {it.getString("client")==issued}
                        require(existing==null || existing.getString("subject")==claims.getString("sub")) {"Account identity did not match."}
                        val r=existing ?: JSONObject().put("client",issued).put("subject",claims.getString("sub")).also {state.getJSONArray("accounts").put(it)}
                        r.put("email",claims.optString("email","ChatGPT account"))
                        updateTokens(r,tokens,true)
                        state.put("active",issued);vault.write(state)
                    }
                    notice=if(active()?.permitted==true)"ChatGPT connected. Choose an available model in Settings." else "Signed in, but ChatGPT plan use was not enabled. Enable it in Settings."
                } catch(e:Exception) {
                    synchronized(lock){if(current==attempt)notice=if(e is IllegalArgumentException || e is IllegalStateException)e.message?:"Sign-in failed." else "Sign-in could not finish. Check your connection and try again."}
                } finally {
                    listener.close()
                    synchronized(lock){if(current==attempt){server=null;signingIn=false}}
                    changed()
                }
            }
            changed()
            return Uri.parse("${PlanProtocol.ISSUER}/api/accounts/authorize?${PlanProtocol.form(query)}")
        }
    }
    private fun receive(socket: ServerSocket,csrf: String,client: String?,current: Int): Pair<String,String> {
        val deadline=System.nanoTime()+300_000_000_000L
        while(System.nanoTime()<deadline) {
            synchronized(lock){if(current!=attempt)throw InterruptedException()}
            val incoming=try {socket.accept()}catch(_:SocketTimeoutException){continue}
            incoming.use {s->
                s.soTimeout=2000
                var result:Pair<String,String>?=null
                var rejected:Exception?=null
                try {
                    val input=s.getInputStream();val headers=StringBuilder()
                    while(headers.length<16384) {
                        val b=input.read();if(b<0)break;headers.append(b.toChar())
                        if(headers.endsWith("\r\n\r\n"))break
                    }
                    require(headers.endsWith("\r\n\r\n")) {"Incomplete callback request."}
                    val parts=headers.toString().substringBefore("\r\n").split(' ')
                    require(parts.size==3 && parts[0]=="GET" && parts[2].startsWith("HTTP/1."))
                    result=PlanProtocol.callback(parts[1],csrf,client)
                }catch(e:Exception){rejected=e}
                val valid=result!=null
                val body="<!doctype html><meta name=viewport content='width=device-width'><title>Velora</title><h1>Velora</h1><p>"+(if(valid)"Sign-in received. Return to Velora to finish connecting." else "This sign-in callback was not accepted. Return to Velora or try again.")+"</p>"
                val bytes=body.toByteArray(Charsets.UTF_8)
                runCatching {s.getOutputStream().write(("HTTP/1.1 ${if(valid)"200 OK" else "400 Bad Request"}\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${bytes.size}\r\nCache-Control: no-store\r\nContent-Security-Policy: default-src 'none'\r\nConnection: close\r\n\r\n").toByteArray()+bytes)}
                if(result!=null)return result
                // A correctly bound denial terminates the attempt; stray requests do not.
                if(rejected is IllegalStateException)throw rejected
            }
        }
        throw IllegalStateException("ChatGPT sign-in timed out. Tap Continue with ChatGPT to try again.")
    }
    private fun updateTokens(r: JSONObject,t: JSONObject,initial: Boolean) {
        require(t.optString("access_token").isNotBlank())
        if(initial)r.remove("signedOut")
        r.put("access",t.getString("access_token"))
        if(t.has("refresh_token"))r.put("refresh",t.getString("refresh_token")) else if(initial)r.remove("refresh")
        if(t.has("id_token"))r.put("id",t.getString("id_token"))
        if(t.has("scope"))r.put("scope",t.getString("scope")) else if(initial)r.put("scope","")
        r.put("expires",System.currentTimeMillis()+t.optLong("expires_in",0).coerceIn(0,86400)*1000)
    }
    /** All callers serialize refreshes; replacement refresh tokens are committed together. */
    fun access(client: String): String = synchronized(refreshLock) {
        val r=synchronized(lock){JSONObject(record(client).toString())}
        check(account(r).signedIn){ "Sign in to ChatGPT again." }
        check(account(r).permitted){ "ChatGPT plan use is not enabled. Enable it in Settings." }
        if(r.optLong("expires")<=System.currentTimeMillis()+60000) {
            check(r.optString("refresh").isNotBlank()){ "Your ChatGPT session expired. Sign in again." }
            val t=try {PlanHttp.json("${PlanProtocol.ISSUER}/api/accounts/oauth/token",mapOf("grant_type" to "refresh_token","client_id" to client,"refresh_token" to r.getString("refresh"),"resource" to PlanProtocol.RESOURCE))}
            catch(e:PlanFailure){if(e.code=="invalid_grant"||e.status==401){synchronized(lock){val saved=record(client);if(saved.optString("refresh")==r.optString("refresh")){clearTokens(saved);vault.write(state)}};changed()};throw e}
            require(t.optString("token_type","Bearer").equals("Bearer",true))
            if(t.has("id_token"))PlanProtocol.verifyId(t.getString("id_token"),PlanHttp.json("${PlanProtocol.ISSUER}/.well-known/jwks.json"),client,null,r.getString("subject"))
            synchronized(lock) {
                val saved=record(client)
                check(saved.optString("refresh")==r.optString("refresh") && saved.optString("access")==r.optString("access")){"The ChatGPT session changed. Please try again."}
                updateTokens(r,t,false)
                updateTokens(saved,t,false);vault.write(state)
            }
            check(account(r).permitted){ "ChatGPT plan permission is no longer available. Sign in again." }
        }
        r.getString("access")
    }
    fun models(client: String): List<PlanModel> {
        val json=PlanHttp.json("${PlanProtocol.RESOURCE}/models",token=access(client))
        val list=json.getJSONArray("models")
        return (0 until list.length()).map{list.getJSONObject(it)}.filter{it.optString("visibility")=="list"}.map{PlanModel(it.getString("slug"),it.getString("display_name"))}
    }
    private fun clearTokens(r:JSONObject){listOf("access","refresh","id","expires","scope").forEach{r.remove(it)}}
    fun signOut(client:String) {
        cancelLogin()
        synchronized(lock){record(client).put("signedOut",true);vault.write(state)}
        notice="Signing out…";changed()
        executor.execute {
            // Wait for an in-flight rotation before choosing the token to revoke.
            val refresh=synchronized(refreshLock){synchronized(lock){val r=record(client);val value=r.optString("refresh");clearTokens(r);vault.write(state);value}}
            var revoked=true
            if(refresh.isNotBlank()) {
                revoked=runCatching {
                    val endpoint=PlanHttp.json("${PlanProtocol.ISSUER}/.well-known/openid-configuration").getString("revocation_endpoint")
                    require(endpoint.startsWith("${PlanProtocol.ISSUER}/"))
                    val form=mapOf("token" to refresh,"token_type_hint" to "refresh_token","client_id" to client)
                    try {PlanHttp.json(endpoint,form)} catch(e:Exception) {
                        if(e is PlanFailure && e.status in 400..499)throw e
                        Thread.sleep(750)
                        PlanHttp.json(endpoint,form)
                    }
                }.isSuccess
            }
            notice=if(revoked)"Signed out of ChatGPT on this phone." else "Signed out on this phone. Remote sign-out could not be confirmed; disconnect Velora in ChatGPT Settings → Security and login."
            changed()
        }
    }
}
