package dev.velora.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class ChatClient {
    @Volatile private var connection: HttpURLConnection? = null
    @Volatile private var generation=0
    fun cancel() { generation++;connection?.disconnect() }
    fun planReply(access: ()->String, model: String, history: List<Pair<String,String>>, message: String, onText:(String)->Unit): String {
        val token=generation
        val bearer=access()
        if(token!=generation)throw InterruptedException()
        val c=PlanHttp.connection("${PlanProtocol.RESOURCE}/responses")
        connection=c
        try {
            if(token!=generation)throw InterruptedException()
            c.requestMethod="POST";c.doOutput=true
            c.setRequestProperty("Authorization","Bearer $bearer");c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Accept","text/event-stream")
            c.outputStream.use {it.write(PlanProtocol.request(model,history,message).toString().toByteArray(Charsets.UTF_8))}
            val code=c.responseCode
            if(code !in 200..299) {
                val body=c.errorStream?.bufferedReader()?.use {it.readText().take(65536)}.orEmpty()
                throw PlanFailure.from(code,body,c.getHeaderField("x-request-id").orEmpty())
            }
            return c.inputStream.bufferedReader().use {PlanProtocol.readStream(it,{token!=generation || Thread.currentThread().isInterrupted},onText)}
        } finally {c.disconnect();if(connection===c)connection=null}
    }
    fun reply(key: String, model: String, history: List<Pair<String,String>>, message: String): String {
        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", "You are Velora, Steve's conversational assistant. Be warm and concise. You have no tools in this chat. Never claim you performed a device action. Your character artwork is fictional."))
        history.takeLast(12).forEach { (role, text) -> messages.put(JSONObject().put("role", role).put("content", text.take(4000))) }
        messages.put(JSONObject().put("role", "user").put("content", message.take(4000)))
        val c = URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection
        connection = c
        try {
            c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 30000; c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer $key"); c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(JSONObject().put("model", model).put("messages", messages).toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) throw IllegalStateException(when (code) { 401 -> "OpenAI rejected the API key."; 429 -> "OpenAI quota or rate limit reached."; else -> "OpenAI request failed (HTTP $code)." })
            val body = c.inputStream.bufferedReader().use { it.readText() }
            return JSONObject(body).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").take(12000)
        } finally { c.disconnect(); if (connection === c) connection = null }
    }
}
