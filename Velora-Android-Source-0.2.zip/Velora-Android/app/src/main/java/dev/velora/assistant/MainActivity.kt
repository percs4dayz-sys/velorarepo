package dev.velora.assistant

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.net.Uri
import android.provider.AlarmClock
import android.speech.*
import android.text.InputFilter
import android.text.InputType
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val ink = Color.rgb(23,18,30)
    private val rose = Color.rgb(221,166,189)
    private val muted = Color.rgb(186,164,184)
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val chat = ChatClient()
    private val history = mutableListOf<Pair<String,String>>()
    private val prefs by lazy { getSharedPreferences("velora", MODE_PRIVATE) }
    private lateinit var portrait: PortraitView
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var composer: EditText
    private lateinit var talk: Button
    private lateinit var send: Button
    private lateinit var voice: VoiceController
    private lateinit var scroll: ScrollView
    private lateinit var connectionLabel: TextView
    private val plan by lazy { ChatGptSession.get(this) }
    private var usePlan=true
    private var connectionDialog: AlertDialog?=null
    private var lastAccount=""
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var busy = false
    @Volatile private var request = 0
    private var apiKey = "" // Deliberately memory-only; never packaged, saved or logged.
    private var model = "gpt-4o-mini"
    private var readAloud = true
    private var reducedMotion = false
    private var conversationText = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        model = prefs.getString("model", model) ?: model
        readAloud = prefs.getBoolean("readAloud", true)
        reducedMotion = prefs.getBoolean("reducedMotion", false)
        usePlan=prefs.getBoolean("usePlan",true)
        buildUi()
        voice = VoiceController(this, { message -> status.text = message }, { mouth -> portrait.mouth = mouth })
        updateConnection()
    }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun label(text: String, size: Float = 14f, color: Int = Color.WHITE) = TextView(this).apply { this.text = text; textSize = size; setTextColor(color); setPadding(0,dp(4),0,dp(4)) }
    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun panel(color: Int, radius: Float = 18f) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius.toInt()).toFloat() }
    private fun button(text: String, primary: Boolean = false, tagName: String = text, action: () -> Unit) = Button(this).apply {
        this.text = text; tag = tagName; isAllCaps = false; textSize = 13f; minHeight = dp(48); minimumWidth = 0
        setTextColor(if (primary) ink else Color.WHITE); backgroundTintList = ColorStateList.valueOf(if (primary) rose else Color.rgb(53,37,57))
        setOnClickListener { action() }
    }
    private fun buildUi() {
        val root = column().apply { setBackgroundColor(ink);isFocusableInTouchMode=true }
        root.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.ime())
                v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            } else {
                @Suppress("DEPRECATION")
                v.setPadding(insets.systemWindowInsetLeft, insets.systemWindowInsetTop, insets.systemWindowInsetRight, insets.systemWindowInsetBottom)
            }
            insets
        }
        setContentView(root)
        val header = row().apply { setPadding(dp(20),dp(6),dp(16),dp(4)) }
        header.addView(label("VELORA",22f,rose).apply { typeface = Typeface.create("sans-serif-medium",Typeface.NORMAL); letterSpacing=.08f }, LinearLayout.LayoutParams(0,dp(52),1f))
        header.addView(button("Settings", tagName="settings") { settings() })
        root.addView(header)
        scroll = ScrollView(this).apply { isFillViewport = true; tag="conversation-scroll" }
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        val body = column(); scroll.addView(body)
        portrait = PortraitView(this).apply { tag="portrait"; expression=prefs.getString("expression","neutral") ?: "neutral"; animateMouth=!reducedMotion }
        val height = (resources.displayMetrics.heightPixels * .43).toInt().coerceIn(dp(260),dp(440))
        body.addView(portrait,LinearLayout.LayoutParams(-1,height))
        val content = column().apply { setPadding(dp(20),0,dp(20),dp(20)) }; body.addView(content)
        content.addView(label("Right here with you",22f).apply { gravity=Gravity.CENTER; typeface=Typeface.create("sans-serif-medium",Typeface.NORMAL) })
        status=label("Starting her voice…",12f,muted).apply { gravity=Gravity.CENTER; tag="status"; accessibilityLiveRegion=View.ACCESSIBILITY_LIVE_REGION_POLITE };content.addView(status)
        val emotes = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled=false }
        val emoteRow=row()
        for ((name,title) in listOf("neutral" to "Neutral","happy" to "Sparkles","surprised" to "Surprised","embarrassed" to "Blushing","angry" to "Angry")) {
            emoteRow.addView(button(title,tagName="emote-$name") { selectExpression(name) })
        }
        emotes.addView(emoteRow);content.addView(emotes)
        val controls=row()
        talk=button("Talk",true,"talk") { if (listening) stopAll() else requestMicrophone() }
        controls.addView(talk,LinearLayout.LayoutParams(0,-2,1f))
        controls.addView(button("Stop",tagName="stop") { stopAll() },LinearLayout.LayoutParams(0,-2,1f))
        controls.addView(button("Sample voice",tagName="sample") { stopAll(); voice.sample() },LinearLayout.LayoutParams(0,-2,1.4f))
        content.addView(controls)
        content.addView(label("Synthetic voice · Native Android preview",10f,muted).apply { gravity=Gravity.CENTER })
        transcript=label("Hi Steve. I’m Velora. Try my voice, choose an expression, or tap Talk.\n\nOpenAI conversation is optional in Settings.",14f).apply { tag="transcript"; setPadding(dp(16),dp(12),dp(16),dp(12)); background=panel(Color.rgb(38,29,47)); setLineSpacing(dp(3).toFloat(),1f); setTextIsSelectable(true) }
        transcript.visibility=View.GONE
        val transcriptToggle=button("Show conversation",tagName="transcript-toggle") {}
        transcriptToggle.setOnClickListener {
            val show=transcript.visibility!=View.VISIBLE
            transcript.visibility=if(show)View.VISIBLE else View.GONE
            transcriptToggle.text=if(show)"Hide conversation" else "Show conversation"
        }
        content.addView(transcriptToggle)
        content.addView(transcript,LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(14);bottomMargin=dp(12) })
        connectionLabel=label("",11f,muted).apply {tag="connection-label"};content.addView(connectionLabel)
        content.addView(button("ChatGPT connection",tagName="chatgpt") {chatGptSettings()})
        composer=EditText(this).apply { hint="Message Velora…"; setHintTextColor(muted);setTextColor(Color.WHITE);textSize=14f; maxLines=4; inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES or InputType.TYPE_TEXT_FLAG_MULTI_LINE;filters=arrayOf(InputFilter.LengthFilter(4000));tag="composer";contentDescription="Message Velora" }
        content.addView(composer,LinearLayout.LayoutParams(-1,-2))
        send=button("Send message",true,"send") { val text=composer.text.toString().trim();if(text.isNotEmpty()){ composer.text.clear();composer.clearFocus();root.requestFocus();(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(composer.windowToken,0); submit(text) } }
        content.addView(send)
        content.addView(label("Timer requests can open your Clock app. PC control and always-on wake words are not connected.",11f,muted))
        root.requestFocus()
    }
    private fun selectExpression(name:String) { portrait.expression=name;prefs.edit().putString("expression",name).apply() }
    private fun append(who:String,text:String) {
        conversationText = (conversationText + (if(conversationText.isEmpty()) "" else "\n\n") + "$who\n$text").takeLast(18000)
        transcript.text=conversationText
    }
    private fun answer(text:String, speak:Boolean=true) { append("VELORA",text);if(speak&&readAloud)voice.speak(text) }
    private fun setBusy(value:Boolean) { busy=value;send.isEnabled=!value;talk.isEnabled=!value }
    private fun submit(text:String) {
        if(busy)return
        voice.stop(false);append("YOU",text)
        when(val command=LocalCommands.parse(text)) {
            LocalCommand.Stop -> {stopAll();answer("Stopped.",false)}
            is LocalCommand.Emote -> {selectExpression(command.name);answer("Here you go.",false)}
            is LocalCommand.Message -> answer(command.text)
            is LocalCommand.Timer -> AlertDialog.Builder(this).setTitle("Open a timer in Clock?").setMessage("Request a ${command.seconds}-second timer. Your Clock app will handle it; Velora cannot verify whether you start it there.").setNegativeButton("Cancel") {_,_->answer("Cancelled. No timer requested.",false)}.setPositiveButton("Open Clock") {_,_->
                try { startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH,command.seconds).putExtra(AlarmClock.EXTRA_MESSAGE,"Velora timer").putExtra(AlarmClock.EXTRA_SKIP_UI,false));answer("Timer request sent to Clock. Check it there.",false) }
                catch (_:ActivityNotFoundException){answer("No compatible Clock app is installed.")}
                catch (_:SecurityException){answer("The Clock app did not accept the request.")}
            }.show()
            LocalCommand.Chat -> {
                val account=if(usePlan)plan.active() else null
                if(usePlan && (account==null || !account.signedIn || !account.permitted)){answer("Open ChatGPT connection and choose Continue with ChatGPT to connect your plan. My voice and local commands work without it.");return}
                if(!usePlan && apiKey.isBlank()){answer("Connect your ChatGPT plan in Settings for conversation, or choose the separate API option and provide a key.");return}
                val chosen=if(usePlan)plan.model(account!!.client) else model
                if(chosen.isBlank()){answer("Choose an available model in ChatGPT connection first.");chatGptSettings();return}
                setBusy(true);status.text="Thinking…";val token=++request;val past=history.toList();val key=apiKey
                val beforeReply=conversationText
                worker.execute {
                    if(token!=request)return@execute
                    try {
                        var lastUpdate=0L
                        val reply=if(account!=null)chat.planReply({plan.access(account.client)},chosen,past,text){partial->
                            val now=SystemClock.elapsedRealtime()
                            if(now-lastUpdate>100){lastUpdate=now;main.post {if(token==request&&!isDestroyed){transcript.text=(beforeReply+"\n\nVELORA · replying…\n"+partial).takeLast(18000);status.text="Replying…"}}}
                        } else chat.reply(key,chosen,past,text)
                        main.post {if(token==request&&!isDestroyed){setBusy(false);history.add("user" to text);history.add("assistant" to reply);while(history.size>12)history.removeAt(0);status.text="Reply complete";answer(reply)}}
                    } catch(e:Exception){main.post {if(token==request&&!isDestroyed){setBusy(false);status.text="Connection needs attention";answer(if(e is IllegalStateException || e is IllegalArgumentException)e.message?:"OpenAI request failed." else "Could not reach OpenAI. Check your connection and settings.",false)}}}
                }
            }
        }
    }
    private fun stopAll() {
        request++;chat.cancel();setBusy(false);recognizer?.cancel();listening=false;talk.text="Talk";voice.stop()
        transcript.text=conversationText.ifBlank {"Your conversation will appear here."}
    }
    private fun requestMicrophone() {
        composer.clearFocus();(getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(composer.windowToken,0)
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),41);return}
        beginListening()
    }
    override fun onRequestPermissionsResult(code:Int, permissions:Array<out String>,results:IntArray) { super.onRequestPermissionsResult(code,permissions,results);if(code==41){if(results.firstOrNull()==PackageManager.PERMISSION_GRANTED)beginListening() else status.text="Microphone permission denied. You can still type."} }
    private fun beginListening() {
        stopAll()
        val offline=Build.VERSION.SDK_INT>=31&&SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
        if(!offline&&!SpeechRecognizer.isRecognitionAvailable(this)){status.text="No speech recognizer is installed. You can type instead.";return}
        if(!offline&&!prefs.getBoolean("recognizerNotice",false)) {
            AlertDialog.Builder(this).setTitle("Use your phone’s speech service?").setMessage("On-device recognition is unavailable. The installed speech service may send microphone audio online. Velora listens only after you tap Talk.").setNegativeButton("Use typing",null).setPositiveButton("Continue") {_,_->prefs.edit().putBoolean("recognizerNotice",true).apply();listen(false)}.show();return
        }
        listen(offline)
    }
    private fun listen(offline:Boolean) {
        recognizer?.destroy()
        val token=request
        try {
            recognizer=if(offline&&Build.VERSION.SDK_INT>=31)SpeechRecognizer.createOnDeviceSpeechRecognizer(this) else SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object:RecognitionListener {
                override fun onReadyForSpeech(params:Bundle?){if(token==request&&listening)status.text="Listening… tap Stop to cancel"}
                override fun onBeginningOfSpeech(){}
                override fun onRmsChanged(rmsdB:Float){}
                override fun onBufferReceived(buffer:ByteArray?){}
                override fun onEndOfSpeech(){if(token==request&&listening)status.text="Finishing transcription…"}
                override fun onError(error:Int){if(token!=request||!listening)return;listening=false;talk.text="Talk";status.text=when(error){SpeechRecognizer.ERROR_NO_MATCH,SpeechRecognizer.ERROR_SPEECH_TIMEOUT->"I didn’t catch that. Tap Talk to try again.";SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS->"Microphone permission is required.";else->"Speech input unavailable (code $error). You can type instead."}}
                override fun onResults(results:Bundle?){if(token!=request||!listening)return;listening=false;talk.text="Talk";val heard=results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull();if(!heard.isNullOrBlank())submit(heard) else status.text="No words recognized."}
                override fun onPartialResults(partialResults:Bundle?){}
                override fun onEvent(eventType:Int,params:Bundle?){}
            })
            listening=true;talk.text="Listening…";status.text="Opening microphone…"
            recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault().toLanguageTag()).putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1))
        }catch(_:Exception){listening=false;talk.text="Talk";status.text="Speech input could not start. You can type instead."}
    }
    private fun settings() {
        val content=column().apply {setPadding(dp(20),dp(6),dp(20),dp(10))}
        content.addView(label("VOICE",12f,rose))
        content.addView(button("Choose speech engine") {
            val engines=voice.engines()
            if(engines.isEmpty()){Toast.makeText(this,"No speech engines found.",Toast.LENGTH_LONG).show();return@button}
            AlertDialog.Builder(this).setTitle("Installed speech engines").setItems(engines.map{it.label}.toTypedArray()){_,which->voice.selectEngine(engines[which].name)}.show()
        })
        content.addView(button("Choose installed voice") {
            val voices=voice.voices()
            if(voices.isEmpty()){Toast.makeText(this,"Wait for the engine or install its voice data.",Toast.LENGTH_LONG).show();return@button}
            AlertDialog.Builder(this).setTitle("Available voices").setItems(voices.map{"${it.name} · ${it.locale.displayName}${if(it.isNetworkConnectionRequired) " · online" else ""}"}.toTypedArray()){_,which->voice.selectVoice(voices[which].name)}.show()
        })
        fun slider(title:String,min:Float,max:Float,current:Float,change:(Float)->Unit){
            val text=label("$title: ${String.format(Locale.US,"%.2f",current)}×",12f,muted);content.addView(text)
            content.addView(SeekBar(this).apply{this.max=100;progress=((current-min)/(max-min)*100).toInt();contentDescription=title;setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(bar:SeekBar?,p:Int,user:Boolean){if(user){val v=min+(max-min)*p/100;change(v);text.text="$title: ${String.format(Locale.US,"%.2f",v)}×"}};override fun onStartTrackingTouch(bar:SeekBar?){};override fun onStopTrackingTouch(bar:SeekBar?){} })})
        }
        slider("Speed",.6f,1.5f,voice.rate){voice.rate=it};slider("Pitch (engine-dependent)",.7f,1.3f,voice.pitch){voice.pitch=it}
        content.addView(button("Preview selected voice") {voice.speak("Hi Steve. I’m Velora. This is my selected Android voice.")})
        content.addView(Switch(this).apply{text="Read replies aloud";isChecked=readAloud;setOnCheckedChangeListener{_,v->readAloud=v;prefs.edit().putBoolean("readAloud",v).apply()}})
        content.addView(Switch(this).apply{text="Keep mouth still";isChecked=reducedMotion;setOnCheckedChangeListener{_,v->reducedMotion=v;portrait.animateMouth=!v;portrait.invalidate();prefs.edit().putBoolean("reducedMotion",v).apply()}})
        content.addView(label("Piper can be used through a compatible installed Android TTS engine, such as Sherpa-ONNX. No Piper model is bundled yet. Voice training happens separately on a computer.",12f,muted))
        content.addView(button("ChatGPT connection") {chatGptSettings()})
        content.addView(button("Separate API key option") {openAiSettings()})
        content.addView(label("Native preview 0.2 · PC pairing and always-on activation are still to be built.",11f,muted))
        AlertDialog.Builder(this).setTitle("Velora settings").setView(ScrollView(this).apply{addView(content)}).setPositiveButton("Done",null).show()
    }
    private fun openAiSettings() {
        val content=column().apply{setPadding(dp(20),0,dp(20),0)}
        content.addView(label("This optional mode bills API usage separately from ChatGPT. Saving switches to API mode. Your key stays in memory only. ChatGPT plan errors never switch here automatically.",12f,muted))
        val key=EditText(this).apply{hint=if(apiKey.isBlank())"OpenAI API key" else "Leave blank to keep current key";inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;importantForAutofill=View.IMPORTANT_FOR_AUTOFILL_NO;filters=arrayOf(InputFilter.LengthFilter(512))};content.addView(key)
        val modelInput=EditText(this).apply{hint="Compatible Chat Completions model";setText(model);inputType=InputType.TYPE_CLASS_TEXT;filters=arrayOf(InputFilter.LengthFilter(100))};content.addView(modelInput)
        AlertDialog.Builder(this).setTitle("OpenAI · optional").setView(content).setNegativeButton("Cancel",null).setNeutralButton("Disconnect"){_,_->stopAll();apiKey="";history.clear();status.text="OpenAI disconnected"}.setPositiveButton("Save for this session"){_,_->
            stopAll();history.clear();val value=key.text.toString().trim();if(value.isNotEmpty())apiKey=value
            usePlan=false;prefs.edit().putBoolean("usePlan",false).apply();updateConnection()
            model=modelInput.text.toString().trim().ifBlank{"gpt-4o-mini"};prefs.edit().putString("model",model).apply();status.text=if(apiKey.isNotBlank())"OpenAI configured · not yet tested" else "Local preview · no API key"
            key.text.clear()
        }.show()
    }
    private fun openLink(url:String) {
        try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))}catch(_:ActivityNotFoundException){status.text="Install a browser to open ChatGPT."}
    }
    private fun updateConnection() {
        val a=plan.active()
        val identity=if(usePlan)a?.client.orEmpty() else "api"
        if(lastAccount!=identity){history.clear();lastAccount=identity}
        connectionLabel.text=if(!usePlan)"Separate API billing · ${if(apiKey.isBlank())"no key" else model}"
            else if(a?.signedIn==true&&a.permitted)"Using ChatGPT plan · ${plan.model(a.client).ifBlank{"choose a model"}}"
            else "ChatGPT plan · not connected"
    }
    private fun planChanged() {
        if(isDestroyed || isFinishing)return
        updateConnection()
        val message=plan.takeNotice();if(message.isNotBlank())status.text=message
        if(plan.needsWelcome()) {
            plan.welcomeSeen()
            AlertDialog.Builder(this).setTitle("You’re using your ChatGPT plan").setMessage("Eligible requests use your included ChatGPT allowance. Manage app limits and any optional credit use in ChatGPT settings. Your existing ChatGPT conversations and memories are not imported.").setPositiveButton("Got it",null).show()
        }
        if(connectionDialog?.isShowing==true)chatGptSettings()
    }
    private fun startSignIn(client:String?,consent:Boolean=false) {
        stopAll();history.clear();usePlan=true;prefs.edit().putBoolean("usePlan",true).apply()
        try {val uri=plan.begin(client,consent);connectionDialog?.dismiss();startActivity(Intent(Intent.ACTION_VIEW,uri))}
        catch(e:Exception){plan.cancelLogin();status.text=if(e is IllegalStateException)e.message else "Could not open sign-in. Make sure a browser is installed."}
        updateConnection()
    }
    private fun chatGptSettings() {
        connectionDialog?.dismiss()
        val content=column().apply {setPadding(dp(20),0,dp(20),dp(10))}
        val active=plan.active()
        content.addView(label("Use your ChatGPT plan for conversation. Sign-in opens OpenAI in your browser. Availability and limits depend on your account; this preview has no automatic paid fallback.",12f,muted))
        content.addView(label(active?.label?:"No account connected",13f,rose))
        if(plan.signingIn) {
            content.addView(label("Sign-in in progress. Finish in your browser, then return here.",12f,muted))
            content.addView(button("Cancel sign-in") {plan.cancelLogin()})
        } else {
            content.addView(button("Continue with ChatGPT",true,"continue-chatgpt") {startSignIn(active?.client,active?.signedIn==true&&!active.permitted)})
            content.addView(button("Add another ChatGPT account") {startSignIn(null)})
            if(plan.accounts().isNotEmpty())content.addView(button("Choose saved account") {
                val accounts=plan.accounts()
                AlertDialog.Builder(this).setTitle("ChatGPT accounts").setItems(accounts.map {it.label+if(it.signedIn)"" else " · signed out"}.toTypedArray()){_,i->stopAll();history.clear();plan.select(accounts[i].client);usePlan=true;prefs.edit().putBoolean("usePlan",true).apply();updateConnection()}.show()
            })
            if(active?.signedIn==true) {
                content.addView(button("Use ChatGPT plan") {stopAll();usePlan=true;prefs.edit().putBoolean("usePlan",true).apply();updateConnection();chatGptSettings()})
                if(active.permitted)content.addView(button("Choose available model",tagName="plan-model") {
                    status.text="Loading your ChatGPT models…"
                    worker.execute {
                        try {val models=plan.models(active.client);main.post {
                            if(isDestroyed||isFinishing||plan.active()?.client!=active.client)return@post
                            if(models.isEmpty()){status.text="No models are available for this connection.";return@post}
                            AlertDialog.Builder(this).setTitle("Your available models").setItems(models.map{it.label}.toTypedArray()){_,which->stopAll();history.clear();plan.selectModel(active.client,models[which].slug);status.text="Ready with ${models[which].label}"}.show()
                        }}catch(e:Exception){main.post{if(!isDestroyed)status.text=if(e is IllegalStateException)e.message else "Could not load models. Try again."}}
                    }
                })
                content.addView(button("Sign out on this phone") {stopAll();history.clear();plan.signOut(active.client);connectionDialog?.dismiss()})
            }
        }
        content.addView(button("Manage usage") {openLink(ChatGptSession.USAGE)})
        content.addView(label("Sign-out clears this phone’s tokens. To remove Velora’s authorization, disconnect it in ChatGPT Settings → Security and login.",11f,muted))
        connectionDialog=AlertDialog.Builder(this).setTitle("ChatGPT connection").setView(ScrollView(this).apply{addView(content)}).setPositiveButton("Done",null).show()
    }
    override fun onResume(){super.onResume();if(::connectionLabel.isInitialized){plan.listener={planChanged()};planChanged()}}
    override fun onStop(){if(::voice.isInitialized)stopAll();super.onStop()}
    override fun onPause(){plan.listener=null;super.onPause()}
    override fun onDestroy(){connectionDialog?.dismiss();recognizer?.destroy();if(::voice.isInitialized)voice.close();chat.cancel();worker.shutdownNow();apiKey="";super.onDestroy()}
}
