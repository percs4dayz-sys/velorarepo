# Velora for Android — 0.2 native preview

This is an actual Kotlin Android application, with a compiled, debug-signed APK. It does not use a WebView or require the earlier browser studio to run. Intended first device: Steve's Galaxy S25 Ultra.

## Try it on the phone

Install `Velora-Android-0.2-debug.apk` over the previous build and open **Velora**. Tap **Sample voice** first: the portrait's mouth follows the audio playback and **Stop** returns it to rest. Choose an expression, or open **Settings** to select an installed speech engine, voice, speed and pitch. Pitch support depends on the selected engine.

Replies no longer scroll the screen down to the text. **Show conversation** opens the transcript when you want it; **Hide conversation** closes it. Both incoming streamed text and finished replies leave your scroll position alone.

## Connect your ChatGPT plan

1. Open **ChatGPT connection → Continue with ChatGPT**.
2. Sign in on the official OpenAI page in your phone's browser and review permission to use your ChatGPT plan.
3. When the browser says the sign-in was received, return to Velora. Keep the app running during sign-in; the attempt expires after five minutes.
4. Open **ChatGPT connection → Choose available model** and pick from the models returned for your account.
5. Tap **Talk** or type a message. **Using ChatGPT plan** identifies the selected route; **Manage usage** opens ChatGPT's usage settings.

This is an implementation of OpenAI's documented local-app sign-in flow. It has passed local protocol and emulator checks, but **successful sign-in, model discovery and a completed real reply on Steve's account have not yet been verified**. Eligibility, workspace policies, rollout and shared plan limits can still prevent access. No API credits are required to attempt this route, and failures never silently switch to API billing. Any optional ChatGPT credit spending is controlled in your ChatGPT settings.

Your existing ChatGPT chats and memories are not imported. Voice input and playback continue through Android; this connection sends text and recent local conversation context. Voice playback starts after the text reply completes.

**Talk** requests microphone permission only when pressed. Velora prefers Android's on-device recognizer when available. If only a service that may process audio online is available, the app explains that before starting. Typing remains available if speech recognition is unavailable.

For installation from the development PC, connect the phone with USB debugging enabled and approve the phone's debugging prompt. Use the exact device serial returned by `adb devices`:

```powershell
adb -s PHONE_SERIAL install -r Velora-Android-0.2-debug.apk
```

The debug APK is for testing. It has not been submitted to the Play Store and should not be described as a finished assistant.

## Implemented

- Native head-and-torso portrait with the user's original artwork, three distinct mouth poses, and four emotes.
- Audio playback with mouth animation measured from PCM16 WAVE audio and synchronized to the playback position. Other playable formats fall back to a still mouth.
- Included synthetic speech sample; installed Android TTS engine and voice selection; speed, engine-dependent pitch, optional reply reading and still-mouth mode.
- Push-to-talk through Android speech recognition, permission handling and a typing fallback.
- ChatGPT plan sign-in through the system browser: loopback callback restricted to 127.0.0.1, PKCE/state/nonce checks, signed identity verification, separate account registrations, account-specific models, protected token storage, serialized renewal and sign-out/revocation. Credentials use Android Keystore encryption in app-private, non-backed-up storage.
- Responses text streaming through the official public endpoint with complete history supplied by the app, no server-side conversation storage, explicit failures and request cancellation. Only completed replies enter model history and speech playback.
- The separate paid API key mode remains explicitly selectable in Settings. Its key is memory-only; no key is packaged or logged. Activity recreation clears this API key and local chat history, but preserves the protected ChatGPT connection.
- A strict local timer command such as `set a 45 second timer` requests confirmation, then opens the phone's Clock app. The app reports the handoff, not a verified timer start.
- Stop and leaving the app stop audio/microphone capture and cancel pending chat results. Device actions are never executed from model-generated text.

## Not implemented yet

Piper itself or a custom trained voice is **not bundled**. Compatible Piper models can be exposed through an installed Android TTS engine such as Sherpa-ONNX and selected in Settings, but that combination still needs a model-specific device test. Direct in-app model download/import and training controls are future work.

Also pending: background/system-wide floating overlay, custom portrait import, always-on wake words, default-assistant-role integration, native DND/flashlight/PC control, secure companion pairing, production backend credentials, conversation persistence, expression-specific talking frames and phoneme-accurate lip sync. The original JPG white background is retained; the native view adds framing and a lower fade.

## Verification on October 24, 2026

- APK compilation succeeded, targeting Android API 36 and compiling with platform 36.1.
- Thirteen unit tests passed: five local-command/audio tests and eight sign-in/stream protocol tests covering signature tampering, issuer/audience/nonce/expiry/subject checks, callback binding, PKCE, partial or failed streams, account-plan request fields and error response shapes.
- Six instrumentation tests passed on the existing API 37 emulator: portrait/emotes, sample mouth movement/Stop, timer negation, transcript scroll regression, encrypted credential round-trip and loopback callback rejection/cancellation. These tests use fabricated credentials and never sign into a real account.
- Android lint passed with no errors. Remaining warnings concern English strings, newer dependency versions/API targets and backup configuration. The target remains API 36 for this device-focused preview.
- No paid OpenAI request or real ChatGPT inference was made. The S25 was not connected during these checks. Account authorization, model discovery, real streaming replies, renewal/revocation, speech recognition, third-party TTS engines and Clock handoff still require live-device validation.

## Connection behavior

Use **Add another ChatGPT account** for a different account or workspace, and **Choose saved account** to switch. Old credentials are not replaced until a new sign-in is validated. Model context is cleared when switching accounts. Signing out clears the phone's selected-account tokens and attempts to revoke the renewable session. If the network prevents revocation, the app says so; remove Velora in ChatGPT Settings → Security and login to disconnect it remotely. Account/client labels and the stable device host ID are retained for later sign-in.

The sign-in listener lasts only for one attempt and does not bind to your Wi-Fi interface. The app never reads another app's login files, browser cookies or ChatGPT passwords. No secrets are stored in the source ZIP. Clear app data/uninstall removes local account storage; disconnect in ChatGPT to revoke authorization too.

Developer references checked October 24, 2026: [registration](https://developers.openai.com/siwc/token-sharing-open-source/sign-in), [sessions](https://developers.openai.com/siwc/token-sharing-open-source/profiles-and-sessions), [models and inference](https://developers.openai.com/siwc/token-sharing-open-source/models-and-inference), [limitations](https://developers.openai.com/siwc/token-sharing-open-source/preview-limitations).

## Build from source

Open this folder as an Android project, or run `Build-Android.cmd` on Windows with JDK 17+ and Android SDK platform 36.1/build-tools 36.0.0 installed. The Gradle wrapper is included; initial dependency resolution needs internet access. This project uses AGP 9.1.1 with its built-in Kotlin support and Gradle 9.3.1.

```powershell
.\gradlew.bat assembleDebug testDebugUnitTest lintDebug
```

The APK is produced at `app/build/outputs/apk/debug/app-debug.apk`. `connectedDebugAndroidTest` runs device instrumentation tests; select only a test emulator when invoking it. It installs test builds and may remove them afterward.

See `PIPER-VOICE-PLAN.md` for the voice customization path.
