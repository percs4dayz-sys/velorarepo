package dev.velora.assistant

import android.content.Context
import android.graphics.*
import android.view.View

class PortraitView(context: Context) : View(context) {
    private val files = listOf("mouth-0.jpg", "mouth-2.jpg", "mouth-3.jpg", "happy.jpg", "surprised.jpg", "embarrassed.jpg", "angry.jpg")
    private val images = files.map { file -> context.assets.open("avatar/$file").use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 2 })!! } }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val destination = RectF()
    private var fade: LinearGradient? = null
    var expression = "neutral"
        set(value) { field = value; invalidate() }
    var mouth: Int? = null
        set(value) { field = value; invalidate() }
    var animateMouth = true
    init { contentDescription = "Velora head and torso portrait"; importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES }
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w,h,oldw,oldh)
        fade = LinearGradient(0f,h*.74f,0f,h.toFloat(),Color.TRANSPARENT,Color.rgb(23,18,30),Shader.TileMode.CLAMP)
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas); canvas.drawColor(Color.WHITE)
        val index = if (mouth != null && animateMouth) mouth!!.coerceIn(0, 2) else when (expression) { "happy" -> 3; "surprised" -> 4; "embarrassed" -> 5; "angry" -> 6; else -> 0 }
        val image = images[index]
        val drawWidth = minOf(width.toFloat(), height * .93f)
        val left = (width - drawWidth) / 2
        paint.shader = null
        destination.set(left, 0f, left + drawWidth, drawWidth * image.height / image.width)
        canvas.drawBitmap(image, null, destination, paint)
        paint.shader = fade
        canvas.drawRect(0f, height * .74f, width.toFloat(), height.toFloat(), paint); paint.shader = null
    }
}
