package dev.velora.assistant

import android.content.Context
import android.media.*
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

class VoiceController(private val context: Context, private val status: (String) -> Unit, private val frame: (Int?) -> Unit) {
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs = context.getSharedPreferences("voice", Context.MODE_PRIVATE)
    private val audio = context.getSystemService(AudioManager::class.java)
    private var tts: TextToSpeech? = null
    private var ready = false
    private var generation = 0
    private var engineGeneration = 0
    private var activeFile: File? = null
    private var player: MediaPlayer? = null
    private var pending: Pair<String, File>? = null
    private var envelope: WaveEnvelope? = null
    private val attributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
    private val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).setAudioAttributes(attributes).setOnAudioFocusChangeListener { if (it < 0) stop() }.build()
    var rate: Float = prefs.getFloat("rate", 1f)
        set(value) { field = value.coerceIn(.6f, 1.5f); prefs.edit().putFloat("rate", field).apply() }
    var pitch: Float = prefs.getFloat("pitch", 1f)
        set(value) { field = value.coerceIn(.7f, 1.3f); prefs.edit().putFloat("pitch", field).apply() }
    var selectedEngine: String = prefs.getString("engine", "") ?: ""
        private set
    var selectedVoice: String = prefs.getString("voice", "") ?: ""
        private set
    var speaking = false
        private set
    private val tick = object : Runnable {
        override fun run() {
            val p = player ?: return
            try { frame(envelope?.frameAt(p.currentPosition) ?: 0); main.postDelayed(this, 50) } catch (_: IllegalStateException) { stop() }
        }
    }
    init { selectEngine(selectedEngine) }
    fun engines(): List<TextToSpeech.EngineInfo> = tts?.engines ?: emptyList()
    fun voices(): List<Voice> = if (ready) (tts?.voices ?: emptySet()).sortedWith(compareBy<Voice> { !it.locale.language.equals("en") }.thenBy { it.name }) else emptyList()
    fun selectVoice(name: String) { selectedVoice = name; prefs.edit().putString("voice", name).apply() }
    fun selectEngine(name: String) {
        stop(false); ready = false; tts?.shutdown(); selectedEngine = name
        prefs.edit().putString("engine", name).apply()
        val token = ++engineGeneration
        tts = TextToSpeech(context, { code -> main.post {
            if (token != engineGeneration) return@post
            ready = code == TextToSpeech.SUCCESS
            if (ready) { tts?.language = Locale.US; status("Here when you’re ready") } else status("Install a speech engine, or try the included sample")
        } }, name.ifBlank { null })
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post {
                val job = pending ?: return@post
                if (id != job.first) return@post
                pending = null; playFile(job.second, generation, true)
            } }
            @Deprecated("Legacy callback") override fun onError(id: String?) { onError(id, -1) }
            override fun onError(id: String?, code: Int) { main.post {
                if (pending?.first == id) { pending?.second?.delete(); pending = null; frame(null); status("Voice could not generate audio. Try another installed voice.") }
            } }
        })
    }
    fun speak(text: String) {
        stop(false)
        if (!ready) { status("Voice is not ready. Try the included sample or select an engine."); return }
        val engine = tts ?: return
        voices().find { it.name == selectedVoice }?.let { engine.voice = it }
        engine.setSpeechRate(rate); engine.setPitch(pitch)
        val id = "velora-$generation-${System.nanoTime()}"
        val file = File(context.cacheDir, "$id.wav"); pending = id to file
        status("Preparing her voice…")
        val result = engine.synthesizeToFile(text.take(TextToSpeech.getMaxSpeechInputLength()), Bundle(), file, id)
        if (result == TextToSpeech.ERROR) { pending = null; file.delete(); status("Selected voice cannot synthesize audio.") }
    }
    fun sample() {
        stop(false); val token = generation; status("Loading voice sample…")
        worker.execute {
            val file = File(context.cacheDir, "sample-$token.wav")
            try { context.assets.open("avatar/preview.wav").use { input -> file.outputStream().use { input.copyTo(it) } }; main.post { if (token == generation) playFile(file, token, true) else file.delete() } }
            catch (_: Exception) { main.post { if (token == generation) status("Sample could not play.") } }
        }
    }
    private fun playFile(file: File, token: Int, deleteAfter: Boolean) {
        worker.execute {
            val levels = try { WaveEnvelope.parse(file.readBytes()) } catch (_: Exception) { null }
            main.post {
                if (token != generation) { if (deleteAfter) file.delete(); return@post }
                if (audio.requestAudioFocus(focus) != AudioManager.AUDIOFOCUS_REQUEST_GRANTED) { file.delete(); status("Audio is busy. Try again shortly."); return@post }
                try {
                    val p = MediaPlayer(); player = p; envelope = levels; activeFile = if (deleteAfter) file else null
                    p.setAudioAttributes(attributes); p.setDataSource(file.absolutePath)
                    p.setOnPreparedListener {
                        if (token != generation) return@setOnPreparedListener
                        speaking = true; status(if (levels != null) "Speaking with you" else "Speaking · mouth timing unavailable")
                        p.start(); main.post(tick)
                    }
                    p.setOnCompletionListener { if (token == generation) stop(); if (deleteAfter) file.delete() }
                    p.setOnErrorListener { _, _, _ -> if (token == generation) { stop(false); status("Audio playback failed.") }; if (deleteAfter) file.delete(); true }
                    p.prepareAsync()
                } catch (_: Exception) { stop(false); file.delete(); status("Voice playback failed.") }
            }
        }
    }
    fun stop(notify: Boolean = true) {
        generation++; main.removeCallbacks(tick); pending?.second?.delete(); pending = null; tts?.stop()
        player?.release(); player = null; activeFile?.delete(); activeFile = null; envelope = null; speaking = false; frame(null); audio.abandonAudioFocusRequest(focus)
        if (notify) status("Here when you’re ready")
    }
    fun close() { engineGeneration++; stop(false); tts?.shutdown(); tts = null; worker.shutdownNow() }
}
