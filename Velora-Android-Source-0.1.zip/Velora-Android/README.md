# Velora for Android — 0.1 native preview

This is an actual Kotlin Android application, with a compiled, debug-signed APK. It does not use a WebView or require the earlier browser studio to run. Intended first device: Steve's Galaxy S25 Ultra.

## Try it on the phone

Install `Velora-Android-0.1-debug.apk` on the phone and open **Velora**. Tap **Sample voice** first: the portrait's mouth follows the audio playback and **Stop** returns it to rest. Choose an expression, or open **Settings** to select an installed speech engine, voice, speed and pitch. Pitch support depends on the selected engine.

**Talk** requests microphone permission only when pressed. Velora prefers Android's on-device recognizer when available. If only a service that may process audio online is available, the app explains that before starting. Typing remains available if speech recognition is unavailable.

For installation from the development PC, connect the phone with USB debugging enabled and approve the phone's debugging prompt. Use the exact device serial returned by `adb devices`:

```powershell
adb -s PHONE_SERIAL install -r Velora-Android-0.1-debug.apk
```

The debug APK is for testing. It has not been submitted to the Play Store and should not be described as a finished assistant.

## Implemented

- Native head-and-torso portrait with the user's original artwork, three distinct mouth poses, and four emotes.
- Audio playback with mouth animation measured from PCM16 WAVE audio and synchronized to the playback position. Other playable formats fall back to a still mouth.
- Included synthetic speech sample; installed Android TTS engine and voice selection; speed, engine-dependent pitch, optional reply reading and still-mouth mode.
- Push-to-talk through Android speech recognition, permission handling and a typing fallback.
- Optional personal OpenAI text chat over HTTPS, recent conversation context, explicit errors and request cancellation. The user supplies their own key, held only in Activity memory. No key is saved or built into the APK. Rotation/recreation clears the key and chat history.
- A strict local timer command such as `set a 45 second timer` requests confirmation, then opens the phone's Clock app. The app reports the handoff, not a verified timer start.
- Stop and leaving the app stop audio/microphone capture and cancel pending chat results. Device actions are never executed from model-generated text.

## Not implemented yet

Piper itself or a custom trained voice is **not bundled**. Compatible Piper models can be exposed through an installed Android TTS engine such as Sherpa-ONNX and selected in Settings, but that combination still needs a model-specific device test. Direct in-app model download/import and training controls are future work.

Also pending: background/system-wide floating overlay, custom portrait import, always-on wake words, default-assistant-role integration, native DND/flashlight/PC control, secure companion pairing, production backend credentials, conversation persistence, expression-specific talking frames and phoneme-accurate lip sync. The original JPG white background is retained; the native view adds framing and a lower fade.

## Verification on October 24, 2026

- APK compilation succeeded, targeting Android API 36 and compiling with platform 36.1.
- Five unit tests passed: timer duration/ranges, negation and compound rejection, emote/stop commands, audio-envelope timing and malformed audio rejection.
- Three instrumentation tests passed on the existing API 37 emulator: native portrait/emote switching, sample mouth movement/Stop reset, and typed negation without timer dispatch.
- Android lint passed with no errors. Remaining warnings concern English strings, newer dependency versions/API targets and backup configuration. The target remains API 36 for this device-focused preview.
- No paid OpenAI request was made. Speech recognition, third-party TTS engines, actual Clock handoff and S25-specific behavior still require physical-device tests.

## Build from source

Open this folder as an Android project, or run `Build-Android.cmd` on Windows with JDK 17+ and Android SDK platform 36.1/build-tools 36.0.0 installed. The Gradle wrapper is included; initial dependency resolution needs internet access. This project uses AGP 9.1.1 with its built-in Kotlin support and Gradle 9.3.1.

```powershell
.\gradlew.bat assembleDebug testDebugUnitTest lintDebug
```

The APK is produced at `app/build/outputs/apk/debug/app-debug.apk`. `connectedDebugAndroidTest` runs device instrumentation tests; select only a test emulator when invoking it. It installs test builds and may remove them afterward.

See `PIPER-VOICE-PLAN.md` for the voice customization path.
