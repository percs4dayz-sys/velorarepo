@echo off
setlocal
cd /d "%~dp0"
if not defined ANDROID_HOME if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
call gradlew.bat assembleDebug testDebugUnitTest lintDebug
if errorlevel 1 (
  echo Build failed. Read the error above.
  pause
  exit /b 1
)
echo APK: %CD%\app\build\outputs\apk\debug\app-debug.apk
pause
