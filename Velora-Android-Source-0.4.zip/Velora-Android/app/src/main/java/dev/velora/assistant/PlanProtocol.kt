package dev.velora.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.net.URLDecoder
import java.net.URLEncoder
import java.math.BigInteger
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.Signature
import java.security.spec.RSAPublicKeySpec
import java.util.Base64

/** OAuth and stream validation, separate from Android so failure paths can be tested. */
object PlanProtocol {
    const val ISSUER = "https://auth.openai.com"
    const val RESOURCE = "https://api.openai.com/v1"
    const val PLAN_SCOPE = "chatgpt.tokens.use.direct"
    const val SCOPES = "openid profile email offline_access resource.invoke $PLAN_SCOPE"
    fun random(): String = encode(ByteArray(32).also { SecureRandom().nextBytes(it) })
    fun encode(bytes: ByteArray): String = Base64.getUrlEncoder().withoutPadding().encodeToString(bytes)
    fun challenge(verifier: String): String = encode(MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII)))
    fun form(values: Map<String,String>): String = values.entries.joinToString("&") { "${URLEncoder.encode(it.key,"UTF-8")}=${URLEncoder.encode(it.value,"UTF-8")}" }
    fun query(value: String): Map<String,String> {
        val result=linkedMapOf<String,String>()
        value.split('&').filter { it.isNotBlank() }.forEach {
            val pair=it.split('=',limit=2)
            val key=URLDecoder.decode(pair[0],"UTF-8")
            require(!result.containsKey(key)) { "Duplicate callback parameter." }
            result[key]=URLDecoder.decode(pair.getOrElse(1){""},"UTF-8")
        }
        return result
    }
    fun callback(target: String, state: String, existingClient: String?): Pair<String,String> {
        require(target.substringBefore('?')=="/auth/callback") { "Unexpected callback path." }
        val q=query(target.substringAfter('?',""))
        require(MessageDigest.isEqual(q["state"].orEmpty().toByteArray(),state.toByteArray())) { "Sign-in state did not match. Try again." }
        if(q.containsKey("error")) throw IllegalStateException("ChatGPT sign-in was declined or cancelled.")
        val client=q["client_id"] ?: existingClient
        require(!client.isNullOrBlank() && client!="dynamic_agent_client" && client.length<=512) { "Registration did not return a client ID." }
        require(existingClient==null || client==existingClient) { "Sign-in returned a different registration." }
        val code=q["code"].orEmpty()
        require(code.isNotBlank() && code.length<=8192) { "Sign-in did not return a code." }
        return code to client
    }
    fun verifyId(token: String, jwks: JSONObject, client: String, nonce: String?, subject: String?=null, now: Long=System.currentTimeMillis()/1000): JSONObject {
        val parts=token.split('.')
        require(parts.size==3 && token.length<=65536) { "Invalid identity token." }
        val decoder=Base64.getUrlDecoder()
        val header=JSONObject(String(decoder.decode(parts[0]),Charsets.UTF_8))
        require(header.optString("alg")=="RS256") { "Unsupported identity signature." }
        val keys=jwks.getJSONArray("keys")
        val matches=(0 until keys.length()).map {keys.getJSONObject(it)}.filter {it.optString("kid")==header.getString("kid") && it.optString("kty")=="RSA" && it.optString("use","sig")=="sig" && it.optString("alg","RS256")=="RS256"}
        require(matches.size==1) { "Identity signing key unavailable." }
        val key=matches.single()
        val publicKey=KeyFactory.getInstance("RSA").generatePublic(RSAPublicKeySpec(BigInteger(1,decoder.decode(key.getString("n"))),BigInteger(1,decoder.decode(key.getString("e")))))
        val signature=Signature.getInstance("SHA256withRSA")
        signature.initVerify(publicKey);signature.update("${parts[0]}.${parts[1]}".toByteArray(Charsets.US_ASCII))
        require(signature.verify(decoder.decode(parts[2]))) { "Identity signature did not match." }
        val claims=JSONObject(String(decoder.decode(parts[1]),Charsets.UTF_8))
        val aud=claims.opt("aud")
        val audiences=if(aud is JSONArray)(0 until aud.length()).map {aud.getString(it)} else listOf(aud as? String ?: "")
        require(claims.optString("iss")==ISSUER && client in audiences) { "Identity issuer or audience did not match." }
        require((audiences.size==1 && !claims.has("azp")) || claims.optString("azp")==client) { "Identity authorized party did not match." }
        require(claims.optLong("exp",0)>now && claims.optLong("iat",now)<=now+60 && claims.optLong("nbf",0)<=now+60) { "Identity token has expired or is not yet valid." }
        require(claims.optString("sub").isNotBlank()) { "Identity subject is missing." }
        require(nonce==null || claims.optString("nonce")==nonce) { "Identity nonce did not match." }
        require(subject==null || claims.getString("sub")==subject) { "A different account was returned. Add it separately." }
        return claims
    }
    fun request(model: String, history: List<Pair<String,String>>, message: String): JSONObject {
        val input=JSONArray()
        history.takeLast(12).filter {it.first in listOf("user","assistant")}.forEach {(role,text)-> input.put(JSONObject().put("role",role).put("content",text.take(4000)))}
        input.put(JSONObject().put("role","user").put("content",message.take(4000)))
        return JSONObject().put("model",model).put("store",false).put("stream",true).put("input",input)
            .put("instructions",PhoneCommands.CHAT_INSTRUCTIONS)
    }
    /** Never report a partial or failed stream as a completed answer. */
    fun readStream(reader: BufferedReader, cancelled: ()->Boolean, onText:(String)->Unit): String {
        val text=StringBuilder();val data=StringBuilder();var completed=false
        fun event() {
            if(data.isEmpty())return
            val raw=data.toString();data.setLength(0)
            if(raw.trim()=="[DONE]")return
            val json=JSONObject(raw)
            when(json.optString("type")) {
                "response.output_text.delta", "response.refusal.delta" -> {
                    val delta=json.optString("delta")
                    require(text.length+delta.length<=12000) { "Reply exceeded the preview's length limit. Ask for a shorter reply." }
                    text.append(delta);onText(text.toString())
                }
                "response.completed" -> {
                    val response=json.optJSONObject("response")
                    require(response==null || response.optString("status","completed")=="completed") { "Reply did not complete." }
                    completed=true
                }
                "response.failed","error" -> {
                    val error=json.optJSONObject("response")?.optJSONObject("error") ?: json.optJSONObject("error") ?: json
                    throw PlanFailure(0,error.optString("code"),"stream")
                }
                "response.incomplete" -> throw IllegalStateException("The reply was incomplete. Try again; the partial text was not added to history.")
            }
        }
        while(true) {
            if(cancelled())throw InterruptedException()
            val line=reader.readLine() ?: break
            require(line.length<=1_000_000 && data.length+line.length<=1_000_000) { "Response event was too large." }
            if(line.isEmpty()) {event();if(completed)break}
            else if(line.startsWith("data:")) {if(data.isNotEmpty())data.append('\n');data.append(line.substring(5).removePrefix(" "))}
        }
        if(data.isNotEmpty()&&!completed)event()
        check(completed) { "Connection ended before the reply completed. Please try again." }
        check(text.isNotBlank()) { "The model completed without a text reply." }
        return text.toString()
    }
}

class PlanFailure(val status: Int, val code: String, val shape: String, val requestId: String="") : IllegalStateException(
    when {
        code=="subscription_sharing_usage_limit_exceeded" || status==429 -> "ChatGPT usage limit reached. Open Manage usage to check your plan and Velora's limit."
        code=="subscription_sharing_user_not_eligible" -> "ChatGPT plan use is not available for this account or workspace."
        code=="invalid_grant" || status==401 -> "Your ChatGPT connection needs a new sign-in. Open Settings → ChatGPT connection."
        status==403 -> "ChatGPT did not permit this request. Check account eligibility and workspace or region restrictions."
        status==503 || code=="subscription_sharing_usage_unavailable" -> "ChatGPT plan usage is temporarily unavailable or not enabled for this connection. Try later."
        code=="subscription_sharing_unsupported_capability" -> "This request or model isn't supported with ChatGPT plan usage. Choose another available model."
        else -> "ChatGPT request failed${if(status>0) " (HTTP $status)" else ""}. No paid API fallback was used."
    }
) {
    companion object {
        fun from(status: Int, body: String, requestId: String=""): PlanFailure {
            val json=runCatching {JSONObject(body)}.getOrNull()
            val error=json?.optJSONObject("error")
            return PlanFailure(status,error?.optString("code")?.takeIf{it!="null"} ?: json?.optString("error")?.takeIf{it!="null"}.orEmpty(),if(error!=null)"error object" else if(json?.has("detail")==true)"detail" else "other",requestId)
        }
    }
}
