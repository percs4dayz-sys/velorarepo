package dev.velora.assistant

import java.util.Locale

sealed class PhoneCommand {
    data class OpenApp(val name: String) : PhoneCommand()
    data class Dial(val recipient: String) : PhoneCommand()
    data class Text(val recipient: String, val body: String) : PhoneCommand()
    data class Navigate(val destination: String) : PhoneCommand()
    data class Rejected(val reason: String) : PhoneCommand()
    object Help : PhoneCommand()
}

/** Explicit user requests only. Model replies never enter this parser. */
object PhoneCommands {
    const val HELP = "Try: open Spotify; call Steve; text Steve saying I'm on my way; navigate to Central Park; navigate home; or set a 5 minute timer. Calls open the dialer and texts open a draft for you to review. I can't operate arbitrary app screens yet."
    const val CHAT_INSTRUCTIONS = "You are Velora, Steve's conversational assistant. Be warm and concise. The Android app handles explicit phone commands locally: open an installed app, prepare a call or text, show directions, and request a timer. You have no executable tools in this chat and cannot see the phone screen, contacts, installed apps, or action results. Never claim you performed a device action. If asked how, give a supported command example. Your character artwork is fictional."
    private val options = setOf(RegexOption.IGNORE_CASE)
    private fun pattern(value: String) = Regex(value, options)
    fun clean(text: String): String = text.trim()
        .replace(pattern("""^(?:hey\s+)?velora[,\s]+"""), "")
        .replace(pattern("""^(?:(?:can|could|would) you\s+)?(?:please\s+)?"""), "")
        .trim()

    fun phoneNumber(value: String): String? {
        if (!Regex("""\+?[0-9() .-]+""").matches(value.trim())) return null
        val compact = value.filter { it.isDigit() || it == '+' }
        return compact.takeIf { it.count(Char::isDigit) in 3..15 }
    }
    fun key(value: String) = value.lowercase(Locale.ROOT).replace(Regex("""[^\p{L}\p{N}]+"""), " ").trim()
    fun <T> matches(query: String, items: List<T>, label: (T) -> String): List<T> {
        val wanted = key(query)
        if (wanted.isEmpty()) return emptyList()
        val exact = items.filter { key(label(it)) == wanted }
        if (exact.isNotEmpty()) return exact
        return items.filter { (" " + key(label(it)) + " ").contains(" $wanted ") }
    }
    private fun target(value: String): String? {
        val result = value.trim().trimEnd('.', '!', '?')
        if (result.isEmpty() || result.length > 160 || result.any { it.isISOControl() }) return null
        if (pattern("""\b(?:and|then|but|except|instead|don't|dont|not|never|cancel)\b|[;&]|://""").containsMatchIn(result)) return null
        return result
    }
    fun parse(text: String): PhoneCommand? {
        val q = clean(text)
        val invalid = PhoneCommand.Rejected("Please give me one phone action at a time, with a specific app, person or destination. Nothing was opened.")
        if (pattern("""^(?:don't|don’t|dont|do not|never|cancel|stop)\b""").containsMatchIn(q)) return null
        if (q.lowercase(Locale.ROOT).trimEnd('.', '!', '?') in listOf("phone actions", "show phone actions", "what can you do on my phone", "what can you do with my phone")) return PhoneCommand.Help
        pattern("""^(?:send (?:a )?(?:text|message) to|draft (?:a )?(?:text|message) to|text|message)\s+(.+)$""").matchEntire(q)?.let {
            val rest = it.groupValues[1]
            val split = pattern("""^(.+?)(?:\s+(?:saying|that says)\s+|\s*:\s*)(.+)$""").matchEntire(rest)
            val recipient = target(split?.groupValues?.get(1) ?: rest) ?: return invalid
            // Everything after the delimiter is literal message content, never a second command.
            val body = split?.groupValues?.get(2).orEmpty()
            if (body.length > 2000) return PhoneCommand.Rejected("That draft is too long. Please keep it under 2,000 characters.")
            return PhoneCommand.Text(recipient, body)
        }
        pattern("""^(?:call|dial|phone)\s+(.+)$""").matchEntire(q)?.let {
            return PhoneCommand.Dial(target(it.groupValues[1]) ?: return invalid)
        }
        pattern("""^(?:navigate(?: to)?|directions to|take me to)\s+(.+)$""").matchEntire(q)?.let {
            return PhoneCommand.Navigate(target(it.groupValues[1]) ?: return invalid)
        }
        pattern("""^(?:open|launch|start)\s+(.+?)(?:\s+app)?$""").matchEntire(q)?.let {
            return PhoneCommand.OpenApp(target(it.groupValues[1]) ?: return invalid)
        }
        if (pattern("""^(?:call|dial|phone|text|message|navigate|send|draft|directions|take me|open|launch)\b""").containsMatchIn(q)) return invalid
        return null
    }
}
