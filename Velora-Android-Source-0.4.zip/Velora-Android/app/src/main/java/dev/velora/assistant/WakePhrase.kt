package dev.velora.assistant

import org.json.JSONObject
import java.util.Locale

object WakePhrase {
    const val GRAMMAR = "[\"hey v\", \"[unk]\"]"
    fun matches(result: String): Boolean {
        val json = try { JSONObject(result) } catch (_: Exception) { return false }
        val text = json.optString("text").lowercase(Locale.ROOT).trim().replace(Regex("\\s+"), " ")
        if (text !in listOf("hey v", "hey vee")) return false
        val words = json.optJSONArray("result") ?: return false
        if (words.length() != 2) return false
        val scores = (0 until words.length()).map { words.getJSONObject(it).optDouble("conf", 0.0) }
        return scores.all { it.isFinite() && it >= .55 } && scores.average() >= .80
    }
}
