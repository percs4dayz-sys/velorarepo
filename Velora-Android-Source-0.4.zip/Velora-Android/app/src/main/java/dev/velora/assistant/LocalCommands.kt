package dev.velora.assistant

sealed class LocalCommand {
    data class Timer(val seconds: Int) : LocalCommand()
    data class Emote(val name: String) : LocalCommand()
    data class Message(val text: String) : LocalCommand()
    data class Phone(val action: PhoneCommand) : LocalCommand()
    object Stop : LocalCommand()
    object Chat : LocalCommand()
}
object LocalCommands {
    fun parse(text: String): LocalCommand {
        val q = PhoneCommands.clean(text).lowercase().trimEnd('.', '!', '?')
        if (q in listOf("stop", "stop speaking", "be quiet")) return LocalCommand.Stop
        val negation = q.replace("do not disturb", "dnd")
        if (Regex("^(don't|don’t|dont|do not|never|cancel|stop)\\b").containsMatchIn(negation)) return LocalCommand.Message("No device action taken.")
        Regex("^(show|look|be) (neutral|happy|surprised|embarrassed|angry)$").matchEntire(q)?.let { return LocalCommand.Emote(it.groupValues[2]) }
        Regex("^(?:set|start) (?:a |an )?(\\d+) (second|minute|hour)s? timer$").matchEntire(q)?.let {
            val amount = it.groupValues[1].toLongOrNull() ?: return LocalCommand.Message("That timer is too long.")
            val factor = when (it.groupValues[2]) { "minute" -> 60L; "hour" -> 3600L; else -> 1L }
            if (amount !in 1..(86400 / factor)) return LocalCommand.Message("Choose a timer between one second and 24 hours.")
            return LocalCommand.Timer((amount * factor).toInt())
        }
        // Timer-like requests must not fall through to the app launcher when malformed.
        if (Regex("^(set|start)\\b.*\\btimer\\b").containsMatchIn(q)) return LocalCommand.Message("Please request one timer, between one second and 24 hours.")
        PhoneCommands.parse(text)?.let { return LocalCommand.Phone(it) }
        if (Regex("^(set|start|enable|disable|turn|lock|unlock|mute|unmute|run|launch|delete|open|buy|purchase|send|book)\\b").containsMatchIn(q)) return LocalCommand.Message("That action is not available yet. Say ‘phone actions’ to see what I can do on this phone.")
        return LocalCommand.Chat
    }
}
