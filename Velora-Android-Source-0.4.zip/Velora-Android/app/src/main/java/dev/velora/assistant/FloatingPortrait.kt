package dev.velora.assistant

import android.content.Context
import android.graphics.*
import android.view.View

/** Four alpha frames derived from the user's Desktop portraits. */
class FloatingPortrait(context: Context) : View(context) {
    private val image = context.assets.open("avatar/floating-strip.png").use { BitmapFactory.decodeStream(it)!! }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val source = Rect()
    private val destination = RectF()
    var mouth: Int? = null
        set(value) { field = value; invalidate() }
    init { contentDescription = "Velora floating portrait; drag to move" }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val frame = (mouth ?: 0).coerceIn(0, 3)
        val cell = image.width / 4
        val scale = minOf(width.toFloat() / cell, height.toFloat() / image.height)
        val drawWidth = cell * scale
        source.set(frame * cell, 0, (frame + 1) * cell, image.height)
        destination.set((width - drawWidth) / 2, 0f, (width + drawWidth) / 2, image.height * scale)
        canvas.drawBitmap(image, source, destination, paint)
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
