package dev.velora.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.text.InputFilter
import android.text.InputType
import android.widget.EditText
import java.util.concurrent.Executors

data class LaunchableApp(val label: String, val component: ComponentName)
data class PhoneRecipient(val name: String, val number: String)

/** Narrow Android handoffs. No arbitrary intents, shell commands, or model-generated execution. */
class PhoneActions(
    private val activity: Activity,
    private val report: (String) -> Unit,
    private val launch: (Intent) -> Unit = { activity.startActivity(it) }
) {
    companion object { const val CONTACT_PERMISSION = 42 }
    private val prefs = activity.getSharedPreferences("velora", Activity.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var generation = 0
    private var pendingContact: PhoneCommand? = null
    var dialog: AlertDialog? = null
        private set

    fun cancel() { generation++; pendingContact = null; dialog?.dismiss(); dialog = null }
    fun close() { cancel(); worker.shutdownNow() }
    private fun show(builder: AlertDialog.Builder) {
        dialog?.dismiss()
        dialog = builder.setOnCancelListener { report("Cancelled. Nothing was opened.") }.show()
    }
    private fun <T> load(read: () -> T, done: (T) -> Unit) {
        val token = generation
        worker.execute {
            try {
                val result = read()
                main.post { if (token == generation && !activity.isDestroyed && !activity.isFinishing) done(result) }
            } catch (_: Exception) {
                main.post { if (token == generation && !activity.isDestroyed) report("I couldn't read that phone information. Check permissions and try again.") }
            }
        }
    }
    fun run(command: PhoneCommand) {
        cancel()
        when (command) {
            is PhoneCommand.OpenApp -> load({ apps() }) { available ->
                val direct = PhoneCommands.matches(command.name, available) { it.label }
                val aliases = mapOf("texts" to "messages", "text messages" to "messages", "dialer" to "phone", "photos" to "gallery")
                val matches = if (direct.isNotEmpty()) direct else PhoneCommands.matches(aliases[PhoneCommands.key(command.name)].orEmpty(), available) { it.label }
                when (matches.size) {
                    0 -> report("I couldn't find an installed app named ${command.name}. Tap Phone actions → Installed apps to choose one.")
                    1 -> openApp(matches.single())
                    else -> chooseApp(matches)
                }
            }
            is PhoneCommand.Dial -> recipient(command.recipient, command)
            is PhoneCommand.Text -> recipient(command.recipient, command)
            is PhoneCommand.Navigate -> {
                if (PhoneCommands.key(command.destination) == "home") {
                    val home = prefs.getString("homeDestination", "").orEmpty()
                    if (home.isBlank()) editHome(true) else directions(home)
                } else directions(command.destination)
            }
            is PhoneCommand.Rejected -> report(command.reason)
            PhoneCommand.Help -> help()
        }
    }
    fun help() {
        cancel()
        show(AlertDialog.Builder(activity).setTitle("Phone actions")
            .setMessage(PhoneCommands.HELP + "\n\nContact matching stays on your phone. A named call or text asks for Contacts permission once. Commands don't need ChatGPT.\n\nApp control currently ends at opening the app or its action screen.")
            .setPositiveButton("Installed apps") { _, _ -> browseApps() }
            .setNeutralButton("Home destination") { _, _ -> editHome(false) }
            .setNegativeButton("Done") { _, _ -> report("Phone actions closed.") })
    }
    fun apps(): List<LaunchableApp> {
        val pm = activity.packageManager
        @Suppress("DEPRECATION")
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.exported && it.activityInfo.enabled && it.activityInfo.applicationInfo.enabled && it.activityInfo.packageName != activity.packageName }
            .map { LaunchableApp(it.loadLabel(pm).toString(), ComponentName(it.activityInfo.packageName, it.activityInfo.name)) }
            .distinctBy { it.component.packageName }.sortedBy { PhoneCommands.key(it.label) }
    }
    private fun browseApps() {
        cancel()
        load({ apps() }) { if (it.isEmpty()) report("No launchable apps are available in this phone profile.") else chooseApp(it) }
    }
    private fun chooseApp(items: List<LaunchableApp>) {
        val duplicateLabels = items.groupBy { it.label }.filterValues { it.size > 1 }.keys
        show(AlertDialog.Builder(activity).setTitle("Choose an app")
            .setItems(items.map { if (it.label in duplicateLabels) "${it.label} · ${it.component.packageName}" else it.label }.toTypedArray()) { _, index -> openApp(items[index]) }
            .setNegativeButton("Cancel") { _, _ -> report("Cancelled. No app opened.") })
    }
    private fun openApp(app: LaunchableApp) {
        handoff(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED),
            "Asked Android to open ${app.label}. I can't see or control its screen yet.")
    }
    private fun recipient(name: String, command: PhoneCommand) {
        val number = PhoneCommands.phoneNumber(name)
        if (number != null) { review(PhoneRecipient(name, number), command); return }
        if (name.any { it in "*#;:/" } || name.none { it.isLetter() }) {
            report("Use a contact name or a regular phone number. Dial codes and extensions aren't supported."); return
        }
        if (activity.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            show(AlertDialog.Builder(activity).setTitle("Find $name in your contacts?")
                .setMessage("Velora will match this name locally. Your contacts won't be sent to ChatGPT. You can use a phone number instead without Contacts permission.")
                .setNegativeButton("Cancel") { _, _ -> report("Cancelled. No contacts read or action opened.") }
                .setPositiveButton("Allow contact lookup") { _, _ ->
                    pendingContact = command
                    activity.requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), CONTACT_PERMISSION)
                })
            return
        }
        load({ contacts(name) }) { matches ->
            if (matches.isEmpty()) report("No matching phone number found for $name. Try their full saved name or a phone number.")
            else if (matches.size == 1) review(matches.single(), command)
            else show(AlertDialog.Builder(activity).setTitle("Which $name?")
                .setItems(matches.map { "${it.name}\n${it.number}" }.toTypedArray()) { _, index -> review(matches[index], command) }
                .setNegativeButton("Cancel") { _, _ -> report("Cancelled. No recipient selected.") })
        }
    }
    private fun contacts(name: String): List<PhoneRecipient> {
        val results = mutableListOf<PhoneRecipient>()
        val uri = Uri.withAppendedPath(Phone.CONTENT_FILTER_URI, Uri.encode(name))
        activity.contentResolver.query(uri, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER), null, null, null)?.use { cursor ->
            while (cursor.moveToNext()) {
                val number = PhoneCommands.phoneNumber(cursor.getString(1).orEmpty()) ?: continue
                results += PhoneRecipient(cursor.getString(0).orEmpty(), number)
            }
        }
        return PhoneCommands.matches(name, results.distinctBy { it.name to it.number }) { it.name }
    }
    fun permissionResult(granted: Boolean) {
        val command = pendingContact ?: return
        pendingContact = null
        if (!granted) { report("Contacts permission wasn't granted. You can still call or draft a text using a phone number."); return }
        run(command)
    }
    private fun review(person: PhoneRecipient, command: PhoneCommand) {
        val body = (command as? PhoneCommand.Text)?.body
        val text = if (body == null) "Open the dialer for ${person.name}\n${person.number}\n\nYou will press Call in the phone app."
            else "To: ${person.name}\n${person.number}\n\n${body.ifBlank { "Empty draft — write your message in the messaging app." }}\n\nReview and send it in your messaging app."
        show(AlertDialog.Builder(activity).setTitle(if (body == null) "Prepare call?" else "Prepare text?").setMessage(text)
            .setNegativeButton("Cancel") { _, _ -> report("Cancelled. No call or text was opened.") }
            .setPositiveButton(if (body == null) "Open dialer" else "Open draft") { _, _ ->
                if (body == null) handoff(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", person.number, null)), "Dialer requested for ${person.name}. Press Call there; Velora has not placed a call.")
                else handoff(Intent(Intent.ACTION_SENDTO, Uri.fromParts("smsto", person.number, null)).putExtra("sms_body", body), "Text draft requested for ${person.name}. Review and send it there; Velora has not sent a message.")
            })
    }
    private fun directions(destination: String) {
        show(AlertDialog.Builder(activity).setTitle("Open directions?")
            .setMessage("Destination: $destination\n\nCheck the location and route in your maps app. This shares the destination with that app.")
            .setNegativeButton("Cancel") { _, _ -> report("Cancelled. No directions opened.") }
            .setPositiveButton("Open directions") { _, _ ->
                val uri = Uri.parse("https://www.google.com/maps/dir/").buildUpon().appendQueryParameter("api", "1")
                    .appendQueryParameter("destination", destination).appendQueryParameter("travelmode", "driving").build()
                handoff(Intent(Intent.ACTION_VIEW, uri), "Directions requested for $destination. Check the route in Maps or your browser; navigation has not been verified.")
            })
    }
    private fun editHome(navigateAfter: Boolean) {
        val input = EditText(activity).apply {
            hint = "Home address or place"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_POSTAL_ADDRESS
            filters = arrayOf(InputFilter.LengthFilter(160)); setText(prefs.getString("homeDestination", ""))
        }
        show(AlertDialog.Builder(activity).setTitle("Home destination").setView(input)
            .setMessage("Saved only in Velora on this phone. It is shared with Maps when you request directions.")
            .setNegativeButton("Cancel") { _, _ -> report("Home destination unchanged.") }
            .setNeutralButton("Forget home") { _, _ -> prefs.edit().remove("homeDestination").apply(); report("Home destination removed from Velora.") }
            .setPositiveButton("Save") { _, _ ->
                val address = input.text.toString().trim()
                if (address.isBlank()) report("Enter a home destination first.")
                else { prefs.edit().putString("homeDestination", address).apply(); if (navigateAfter) directions(address) else report("Home destination saved on this phone.") }
            })
    }
    private fun handoff(intent: Intent, success: String) {
        try { launch(intent); report(success) }
        catch (_: ActivityNotFoundException) { report("No installed app can handle that request. Nothing was opened.") }
        catch (_: SecurityException) { report("Android didn't allow that action. Nothing was opened.") }
    }
}
