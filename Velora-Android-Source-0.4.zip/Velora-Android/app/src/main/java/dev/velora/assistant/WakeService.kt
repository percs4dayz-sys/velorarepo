package dev.velora.assistant

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.util.concurrent.Executors

class WakeService : Service() {
    companion object {
        const val STOP = "dev.velora.assistant.STOP_WAKE"
        const val SHOW = "dev.velora.assistant.SHOW_FLOATING"
        const val CHANNEL = "velora_wake"
        var current: WakeService? = null
            private set
        var appVisible = false
    }
    private enum class Phase { LOADING, ARMED, COMMAND, THINKING, SPEAKING, REVIEW, PAUSED }
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val chat = ChatClient()
    private val history = mutableListOf<Pair<String, String>>()
    private var accountId = ""
    private val prefs by lazy { getSharedPreferences("velora", MODE_PRIVATE) }
    private val wm by lazy { getSystemService(WindowManager::class.java) }
    private val keyguard by lazy { getSystemService(KeyguardManager::class.java) }
    private val power by lazy { getSystemService(PowerManager::class.java) }
    private val audio by lazy { getSystemService(AudioManager::class.java) }
    private var engine: OfflineWakeEngine? = null
    private var engineMode = OfflineWakeEngine.Mode.PAUSED
    private var modelReady = false
    private var phase = Phase.LOADING
    private var overlay: LinearLayout? = null
    private var portrait: FloatingPortrait? = null
    private var caption: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private lateinit var voice: VoiceController
    private var generation = 0
    private var spokenSince = 0L
    private var visibleSince = 0L
    private var notificationText = ""
    private var destroyed = false
    private var receiverRegistered = false
    private val screenEvents = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { reconcile() }
    }
    private val poll = object : Runnable {
        override fun run() { if (!destroyed) { reconcile(); main.postDelayed(this, 500) } }
    }
    override fun onBind(intent: Intent?) = null
    override fun onCreate() {
        super.onCreate(); current = this
        voice = VoiceController(this, { message ->
            if (phase == Phase.SPEAKING) caption?.text = message
            if (phase == Phase.SPEAKING && (message == "Here when you’re ready" || message.contains("failed", true) || message.contains("not ready") || message.contains("cannot") || message.contains("could not") || message.contains("Install a speech engine") || message.contains("unavailable") || message.contains("busy"))) arm()
        }, { portrait?.mouth = it })
        val filter = IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_USER_PRESENT); addAction(Intent.ACTION_SCREEN_ON) }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenEvents, filter, RECEIVER_NOT_EXPORTED) else registerReceiver(screenEvents, filter)
        receiverRegistered = true
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == STOP) { stopSelf(); return START_NOT_STICKY }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED || !Settings.canDrawOverlays(this)) {
            prefs.edit().putString("wakeStatus", "Microphone and appear-on-top permission are required.").apply(); stopSelf(); return START_NOT_STICKY
        }
        try {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL, "Hey V listener", NotificationManager.IMPORTANCE_LOW))
            if (Build.VERSION.SDK_INT >= 30) startForeground(41, notification("Preparing the on-device listener…"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(41, notification("Preparing the on-device listener…"))
        } catch (_: RuntimeException) {
            prefs.edit().putString("wakeStatus", "Open Velora and start Hey V again to allow microphone access.").apply(); stopSelf(); return START_NOT_STICKY
        }
        prefs.edit().putBoolean("wakeEnabled", true).apply()
        if (engine == null) {
            updateNotification("Preparing the on-device listener…")
            engine = OfflineWakeEngine(this, { modelReady = true; arm() }, { awaken() }, { heard(it) }, {
                prefs.edit().putString("wakeStatus", "The local listener couldn't start. Check microphone access and restart Hey V.").apply()
                stopSelf()
            })
            main.post(poll)
        }
        if (intent?.action == SHOW) showFloatingPreview()
        return START_NOT_STICKY
    }
    private fun notification(message: String): Notification {
        val app = PendingIntent.getActivity(this, 40, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop = PendingIntent.getService(this, 41, Intent(this, WakeService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE)
        val show = PendingIntent.getService(this, 42, Intent(this, WakeService::class.java).setAction(SHOW), PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL).setSmallIcon(R.drawable.ic_velora).setContentTitle("Velora · Hey V")
            .setContentText(message).setContentIntent(app).setOngoing(true).setOnlyAlertOnce(true)
            .setVisibility(Notification.VISIBILITY_PUBLIC).addAction(Notification.Action.Builder(null, "Show Velora", show).build())
            .addAction(Notification.Action.Builder(null, "Stop listening", stop).build()).build()
    }
    private fun updateNotification(message: String) {
        if (message == notificationText) return
        notificationText = message; prefs.edit().putString("wakeStatus", message).apply()
        getSystemService(NotificationManager::class.java).notify(41, notification(message))
    }
    private fun allowed(): Boolean = power.isInteractive && !keyguard.isKeyguardLocked && audio.mode == AudioManager.MODE_NORMAL
    private fun listen(mode: OfflineWakeEngine.Mode) {
        if (engineMode != mode) { engineMode = mode; engine?.mode(mode) }
    }
    private fun reconcile() {
        if (!Settings.canDrawOverlays(this) || checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { stopSelf(); return }
        if (!allowed() || appVisible) {
            if (!allowed()) removeOverlay()
            if (phase != Phase.PAUSED && phase != Phase.LOADING) {
                generation++; chat.cancel(); voice.stop(false); phase = Phase.PAUSED; listen(OfflineWakeEngine.Mode.PAUSED)
                removeOverlay()
            }
            if (modelReady) updateNotification(if (appVisible) "Paused in Velora. Leave the app to say Hey V." else "Paused while locked, screen off or in a call.")
            return
        }
        if (!modelReady) return
        if (phase == Phase.PAUSED) { voice.refreshPreferences(); arm() }
        // A broken speech engine must not leave an always-on session stuck forever.
        if (phase == Phase.SPEAKING && SystemClock.elapsedRealtime() - spokenSince > 90000) { voice.stop(false); caption?.text = "Voice timed out. Tap Talk to try again."; arm() }
        if (phase == Phase.ARMED && overlay != null && SystemClock.elapsedRealtime() - visibleSince > 45000) removeOverlay()
    }
    private fun arm() {
        if (destroyed) return
        phase = if (allowed() && !appVisible && modelReady) Phase.ARMED else Phase.PAUSED
        listen(if (phase == Phase.ARMED) OfflineWakeEngine.Mode.WAKE else OfflineWakeEngine.Mode.PAUSED)
        updateNotification(if (phase == Phase.ARMED) "Listening locally for Hey V · tap Stop to turn off" else "Paused. Unlock and leave Velora to say Hey V.")
        visibleSince = SystemClock.elapsedRealtime()
    }
    fun showFloatingPreview() {
        if (!allowed()) return
        showOverlay("Hey V is on. Leave Velora, then say ‘Hey V’ and pause.")
    }
    private fun awaken() {
        if (!allowed() || appVisible || !modelReady) { arm(); return }
        generation++; chat.cancel(); voice.stop(false)
        showOverlay("Listening… say your request")
        if (overlay == null) { arm(); return }
        phase = Phase.COMMAND
        listen(OfflineWakeEngine.Mode.COMMAND)
        updateNotification("Listening to your request on this phone…")
    }
    private fun heard(text: String) {
        if (phase != Phase.COMMAND || !allowed() || appVisible) { arm(); return }
        listen(OfflineWakeEngine.Mode.PAUSED)
        if (text.isBlank()) { caption?.text = "I didn't catch that. Tap Talk or say Hey V again."; arm(); return }
        val local = LocalCommands.parse(text)
        when (local) {
            LocalCommand.Stop -> hideAndArm()
            is LocalCommand.Message -> speak(local.text)
            is LocalCommand.Emote -> speak("You can choose my expressions in the Velora app.")
            is LocalCommand.Phone, is LocalCommand.Timer -> {
                phase = Phase.REVIEW; removeOverlay()
                try { startActivity(Intent(this, ActionReviewActivity::class.java).putExtra("command", text).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (_: RuntimeException) { showOverlay("Open Velora to finish that phone action."); arm() }
            }
            LocalCommand.Chat -> reply(text)
        }
    }
    private fun reply(text: String) {
        val session = ChatGptSession.get(this)
        val account = session.active()
        val model = account?.let { session.model(it.client) }.orEmpty()
        if (account?.signedIn != true || !account.permitted || model.isBlank() || !prefs.getBoolean("usePlan", true)) {
            speak("Open Velora and connect your ChatGPT plan for conversation. Phone commands work locally."); return
        }
        if (accountId != account.client) { accountId = account.client; history.clear() }
        phase = Phase.THINKING; caption?.text = "Thinking…"; updateNotification("Preparing a reply…")
        val token = ++generation; val past = history.toList()
        worker.execute {
            try {
                val result = chat.planReply({ session.access(account.client) }, model, past, text) { }
                main.post {
                    if (!destroyed && token == generation && session.active()?.client == account.client && allowed() && !appVisible) {
                        history.add("user" to text); history.add("assistant" to result)
                        while (history.size > 12) history.removeAt(0)
                        speak(result)
                    } else if (!destroyed && token == generation) {
                        arm()
                    }
                }
            } catch (_: Exception) { main.post { if (!destroyed && token == generation) { caption?.text = "Chat couldn't finish. Check your connection in Velora."; arm() } } }
        }
    }
    private fun speak(text: String) {
        listen(OfflineWakeEngine.Mode.PAUSED); phase = Phase.SPEAKING; spokenSince = SystemClock.elapsedRealtime()
        caption?.text = text.take(170); updateNotification("Velora is replying · wake listening paused")
        voice.speak(text)
    }
    fun actionFinished(message: String) {
        if (destroyed || phase != Phase.REVIEW) return
        if (allowed() && !appVisible) showOverlay(message)
        arm()
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun showOverlay(message: String) {
        if (overlay != null) { caption?.text = message; visibleSince = SystemClock.elapsedRealtime(); return }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.TRANSPARENT) }
        val face = FloatingPortrait(this); portrait = face
        root.addView(face, LinearLayout.LayoutParams(-1, dp(232)))
        caption = TextView(this).apply {
            text = message; textSize = 12f; setTextColor(Color.WHITE); maxLines = 4; gravity = Gravity.CENTER
            setPadding(dp(7), dp(5), dp(7), dp(5))
            background = GradientDrawable().apply { setColor(0xD017121E.toInt()); cornerRadius = dp(12).toFloat() }
        }
        root.addView(caption)
        val controls = LinearLayout(this)
        fun control(label: String, description: String, click: () -> Unit) {
            controls.addView(Button(this).apply {
                text = label; contentDescription = description; isAllCaps = false; textSize = 12f; minWidth = 0; minimumWidth = 0
                setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(0xDD352539.toInt())
                setOnClickListener { click() }
            }, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        control("Talk", "Talk to floating Velora") { if (!appVisible) awaken() else caption?.text = "Use Talk in the app, or leave Velora first." }
        control("App", "Open Velora app") { hideAndArm(); startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        control("×", "Hide Velora; Hey V stays on") { hideAndArm() }
        root.addView(controls)
        val screen = resources.displayMetrics
        val p = WindowManager.LayoutParams(dp(232), WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = prefs.getInt("floatingX", screen.widthPixels - dp(248)).coerceIn(0, maxOf(0, screen.widthPixels - dp(232)))
            y = prefs.getInt("floatingY", screen.heightPixels / 3).coerceIn(dp(32), maxOf(dp(32), screen.heightPixels - dp(370)))
        }
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        face.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> { startX = p.x; startY = p.y; touchX = event.rawX; touchY = event.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    p.x = (startX + event.rawX - touchX).toInt().coerceIn(0, maxOf(0, resources.displayMetrics.widthPixels - root.width))
                    p.y = (startY + event.rawY - touchY).toInt().coerceIn(dp(24), maxOf(dp(24), resources.displayMetrics.heightPixels - root.height - dp(24)))
                    if (overlay != null) try { wm.updateViewLayout(root, p) } catch (_: RuntimeException) { }
                    true
                }
                MotionEvent.ACTION_UP -> { prefs.edit().putInt("floatingX", p.x).putInt("floatingY", p.y).apply(); view.performClick(); true }
                else -> true
            }
        }
        try { wm.addView(root, p); overlay = root; params = p; visibleSince = SystemClock.elapsedRealtime() }
        catch (_: RuntimeException) { prefs.edit().putString("wakeStatus", "Allow Velora to appear on top in Android settings.").apply() }
    }
    private fun removeOverlay() {
        overlay?.let { try { wm.removeView(it) } catch (_: RuntimeException) { } }
        overlay = null; portrait = null; caption = null; params = null
    }
    private fun hideAndArm() { generation++; chat.cancel(); voice.stop(false); listen(OfflineWakeEngine.Mode.PAUSED); removeOverlay(); arm() }
    override fun onDestroy() {
        destroyed = true; generation++; main.removeCallbacksAndMessages(null); engine?.close(); engine = null
        chat.cancel(); voice.close(); worker.shutdownNow(); removeOverlay()
        if (receiverRegistered) unregisterReceiver(screenEvents)
        prefs.edit().putBoolean("wakeEnabled", false).apply(); current = null
        stopForeground(STOP_FOREGROUND_REMOVE); super.onDestroy()
    }
}
