package dev.velora.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.AlarmClock

/** Non-exported review surface for a request captured after the local wake phrase. */
class ActionReviewActivity : Activity() {
    private lateinit var actions: PhoneActions
    private var delivered = false
    private var timer: AlertDialog? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        actions = PhoneActions(this, { finishWith(it) })
        if (savedInstanceState != null || WakeService.current == null) { finishWith("Action cancelled. Please ask again."); return }
        when (val command = LocalCommands.parse(intent.getStringExtra("command").orEmpty().take(4000))) {
            is LocalCommand.Phone -> actions.run(command.action)
            is LocalCommand.Timer -> {
                timer = AlertDialog.Builder(this).setTitle("Open a timer in Clock?")
                    .setMessage("Request a ${command.seconds}-second timer. Check and start it in your Clock app.")
                    .setNegativeButton("Cancel") { _, _ -> finishWith("Cancelled. No timer requested.") }
                    .setOnCancelListener { finishWith("Cancelled. No timer requested.") }
                    .setPositiveButton("Open Clock") { _, _ ->
                        try {
                            startActivity(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, command.seconds)
                                .putExtra(AlarmClock.EXTRA_SKIP_UI, false).putExtra(AlarmClock.EXTRA_MESSAGE, "Velora timer"))
                            finishWith("Timer request sent to Clock. Check it there.")
                        } catch (_: RuntimeException) { finishWith("Clock could not open that timer.") }
                    }.show()
            }
            else -> finishWith("That request needs the Velora app.")
        }
    }
    private fun finishWith(message: String) {
        if (delivered) return
        delivered = true; WakeService.current?.actionFinished(message); finish()
    }
    override fun onRequestPermissionsResult(code: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, permissions, results)
        if (code == PhoneActions.CONTACT_PERMISSION) actions.permissionResult(results.firstOrNull() == PackageManager.PERMISSION_GRANTED)
    }
    override fun onDestroy() {
        if (::actions.isInitialized) actions.close(); timer?.dismiss()
        if (!delivered) WakeService.current?.actionFinished("Action cancelled. Please ask again.")
        super.onDestroy()
    }
}
