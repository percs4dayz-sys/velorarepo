package dev.velora.assistant

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.util.zip.ZipInputStream

/** One local microphone reader. Ambient audio is neither stored nor transmitted. */
class OfflineWakeEngine(
    private val context: Context,
    private val ready: () -> Unit,
    private val woke: () -> Unit,
    private val command: (String) -> Unit,
    private val failed: () -> Unit
) {
    enum class Mode { PAUSED, WAKE, COMMAND }
    @Volatile private var requested = Mode.PAUSED
    @Volatile private var closed = false
    @Volatile private var epoch = 0
    private val main = Handler(Looper.getMainLooper())
    private val thread = Thread({ loop() }, "Velora-local-wake")
    init { thread.start() }
    fun mode(value: Mode) { if (requested != value) { requested = value; epoch++ } }
    fun close() { closed = true; epoch++; thread.interrupt() }

    companion object {
        private val modelLock = Any()
        fun modelDirectory(context: Context): File = synchronized(modelLock) {
            val root = File(context.noBackupFilesDir, "wake-model-v1").apply { mkdirs() }
            val marker = File(root, "ready")
            val model = File(root, "vosk-model-small-en-us-0.15")
            if (!marker.exists()) {
                var bytes = 0L
                ZipInputStream(context.assets.open("wake-model.zip")).use { zip ->
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        val file = File(root, entry.name).canonicalFile
                        require(file.path.startsWith(root.canonicalPath + File.separator))
                        if (entry.isDirectory) file.mkdirs() else {
                            file.parentFile!!.mkdirs()
                            file.outputStream().use { out ->
                                val buffer = ByteArray(32768)
                                while (true) {
                                    val count = zip.read(buffer); if (count < 0) break
                                    bytes += count; require(bytes <= 100_000_000)
                                    out.write(buffer, 0, count)
                                }
                            }
                        }
                        zip.closeEntry()
                    }
                }
                require(File(model, "am/final.mdl").length() > 0)
                marker.writeText("bundled-en-us-0.15")
            }
            model
        }
    }
    @Suppress("MissingPermission")
    private fun loop() {
        try {
            LibVosk.setLogLevel(LogLevel.WARNINGS)
            Model(modelDirectory(context).absolutePath).use { model ->
                main.post { if (!closed) ready() }
                while (!closed) {
                    if (requested == Mode.PAUSED) { Thread.sleep(100); continue }
                    val current = requested; val token = epoch
                    val minimum = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                    require(minimum > 0)
                    val recorder = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minimum * 2, 16000))
                    try {
                        check(recorder.state == AudioRecord.STATE_INITIALIZED)
                        val recognizer = if (current == Mode.WAKE) Recognizer(model, 16000f, WakePhrase.GRAMMAR) else Recognizer(model, 16000f)
                        recognizer.use { r ->
                            r.setWords(true)
                            recorder.startRecording()
                            val start = SystemClock.elapsedRealtime()
                            val buffer = ShortArray(1600)
                            while (!closed && epoch == token) {
                                val count = recorder.read(buffer, 0, buffer.size)
                                check(count > 0)
                                if (r.acceptWaveForm(buffer, count)) {
                                    val result = r.result
                                    if (current == Mode.WAKE && WakePhrase.matches(result)) {
                                        requested = Mode.PAUSED
                                        main.post { if (!closed && epoch == token) woke() }
                                        break
                                    }
                                    if (current == Mode.COMMAND) {
                                        val text = JSONObject(result).optString("text").trim()
                                        if (text.isNotBlank()) {
                                            requested = Mode.PAUSED
                                            main.post { if (!closed && epoch == token) command(text) }
                                            break
                                        }
                                    }
                                }
                                if (current == Mode.COMMAND && SystemClock.elapsedRealtime() - start > 12000) {
                                    requested = Mode.PAUSED
                                    main.post { if (!closed && epoch == token) command("") }
                                    break
                                }
                            }
                        }
                    } finally {
                        try { recorder.stop() } catch (_: IllegalStateException) { }
                        recorder.release()
                    }
                }
            }
        } catch (_: InterruptedException) { }
        catch (_: Exception) { main.post { if (!closed) failed() } }
        catch (_: LinkageError) { main.post { if (!closed) failed() } }
    }
}
