package dev.velora.assistant

import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

/** Playback-clock envelope for standard PCM16 WAVE files, independent of Android. */
data class WaveEnvelope(val levels: FloatArray, val intervalMs: Int = 50) {
    fun frameAt(positionMs: Int): Int {
        val energy = levels.getOrElse((positionMs.coerceAtLeast(0) / intervalMs)) { 0f }
        return when { energy < .012 -> 0; energy < .06 -> 1; energy < .16 -> 2; else -> 3 }
    }
    companion object {
        fun parse(bytes: ByteArray): WaveEnvelope {
            require(bytes.size >= 44 && String(bytes, 0, 4) == "RIFF" && String(bytes, 8, 4) == "WAVE") { "Not a WAVE file" }
            val b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            var p = 12; var rate = 0; var channels = 0; var bits = 0; var format = 0; var offset = -1; var size = 0
            while (p + 8 <= bytes.size) {
                val id = String(bytes, p, 4); val length = b.getInt(p + 4)
                require(length >= 0 && p.toLong() + 8 + length <= bytes.size) { "Invalid WAVE chunk" }
                if (id == "fmt ") {
                    require(length >= 16)
                    format = b.getShort(p + 8).toInt(); channels = b.getShort(p + 10).toInt()
                    rate = b.getInt(p + 12); bits = b.getShort(p + 22).toInt()
                }
                if (id == "data") { offset = p + 8; size = length }
                p += 8 + length + (length % 2)
            }
            require(format == 1 && bits == 16 && channels in 1..2 && rate in 8000..192000 && offset >= 0) { "Voice must provide PCM16 WAVE audio" }
            val samplesPerWindow = (rate * channels / 20).coerceAtLeast(1)
            val count = size / 2
            val levels = FloatArray((count + samplesPerWindow - 1) / samplesPerWindow)
            for (window in levels.indices) {
                val start = window * samplesPerWindow; val end = minOf(count, start + samplesPerWindow)
                var sum = 0.0
                for (i in start until end) { val sample = b.getShort(offset + i * 2) / 32768.0; sum += sample * sample }
                levels[window] = sqrt(sum / (end - start)).toFloat() * 1.5f
            }
            return WaveEnvelope(levels)
        }
    }
}
