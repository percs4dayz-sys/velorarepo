package dev.velora.assistant

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object PlanHttp {
    fun connection(url: String): HttpURLConnection {
        require(url.startsWith("https://auth.openai.com/") || url.startsWith("https://api.openai.com/"))
        return (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout=15000;readTimeout=45000;instanceFollowRedirects=false
        }
    }
    fun json(url: String, form: Map<String,String>?=null, token: String?=null): JSONObject {
        // DNS failures occur before a request reaches the server, so retrying them
        // does not redeem a one-use authorization code a second time.
        for(attempt in 0..2) {
            try {return jsonOnce(url,form,token)} catch(e:java.net.UnknownHostException) {
                if(attempt==2)throw e
                Thread.sleep(750L*(attempt+1))
            }
        }
        error("Unreachable")
    }
    private fun jsonOnce(url: String, form: Map<String,String>?, token: String?): JSONObject {
        val c=connection(url)
        try {
            if(token!=null)c.setRequestProperty("Authorization","Bearer $token")
            if(form!=null) {
                c.requestMethod="POST";c.doOutput=true
                c.setRequestProperty("Content-Type","application/x-www-form-urlencoded")
                c.outputStream.use {it.write(PlanProtocol.form(form).toByteArray(Charsets.UTF_8))}
            }
            val status=c.responseCode
            val body=(if(status in 200..299)c.inputStream else c.errorStream)?.bufferedReader()?.use {reader->
                val out=StringBuilder();val buffer=CharArray(4096)
                while(true){val count=reader.read(buffer);if(count<0)break;check(out.length+count<=2_000_000){"Server response was too large."};out.append(buffer,0,count)}
                out.toString()
            }.orEmpty()
            if(status !in 200..299)throw PlanFailure.from(status,body,c.getHeaderField("x-request-id").orEmpty())
            return if(body.isBlank())JSONObject() else JSONObject(body)
        } finally {c.disconnect()}
    }
}
