package dev.velora.assistant

import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.ContentProviderOperation
import android.content.ContentUris
import android.provider.ContactsContract
import android.provider.ContactsContract.RawContacts as Raw
import android.provider.ContactsContract.Data as ContactData
import android.provider.ContactsContract.CommonDataKinds.StructuredName
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.os.SystemClock
import android.view.View
import android.widget.*
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test

class PhoneActionsTest {
    private class Harness(val scenario: ActivityScenario<MainActivity>, failLaunch: Boolean = false) {
        val sent = mutableListOf<Intent>()
        val results = mutableListOf<String>()
        lateinit var actions: PhoneActions
        init { step { activity -> actions = PhoneActions(activity, { results += it }, { if (failLaunch) throw ActivityNotFoundException() else sent += it }) } }
        fun step(block: (MainActivity) -> Unit) { scenario.onActivity { block(it) }; InstrumentationRegistry.getInstrumentation().waitForIdleSync() }
        fun run(command: PhoneCommand) = step { actions.run(command) }
        fun click(button: Int) = step { actions.dialog!!.getButton(button).performClick() }
        fun close() = step { actions.close() }
    }
    @Test fun callsAndTextsRequireReviewAndNeverSendDirectly() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            val h = Harness(scenario); val sent = h.sent; val results = h.results
            try {
                h.run(PhoneCommand.Dial("+1 (202) 555-0100"))
                assertTrue(sent.isEmpty())
                h.click(AlertDialog.BUTTON_NEGATIVE)
                assertTrue(sent.isEmpty()); assertTrue(results.last().contains("Cancelled"))
                h.run(PhoneCommand.Dial("+1 (202) 555-0100"))
                h.click(AlertDialog.BUTTON_POSITIVE)
                assertEquals(Intent.ACTION_DIAL, sent.single().action)
                assertEquals("tel", sent.single().data!!.scheme)
                assertEquals("+12025550100", sent.single().data!!.schemeSpecificPart)
                assertTrue(results.last().contains("has not placed a call"))
                h.step { sent.clear() }
                h.run(PhoneCommand.Text("2025550100", "Don't wait & call me!"))
                assertTrue(sent.isEmpty())
                h.click(AlertDialog.BUTTON_POSITIVE)
                assertEquals(Intent.ACTION_SENDTO, sent.single().action)
                assertEquals("smsto:2025550100", sent.single().data.toString())
                assertEquals("Don't wait & call me!", sent.single().getStringExtra("sms_body"))
                assertTrue(results.last().contains("has not sent a message"))
            } finally { h.close() }
        }
    }
    @Test fun mapDestinationIsEncodedAndCancelledRequestsDoNothing() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            val h = Harness(scenario); val sent = h.sent
            try {
                h.run(PhoneCommand.Navigate("100 Main Street #2 & parking"))
                h.click(AlertDialog.BUTTON_NEGATIVE)
                assertTrue(sent.isEmpty())
                h.run(PhoneCommand.Navigate("100 Main Street #2 & parking"))
                h.click(AlertDialog.BUTTON_POSITIVE)
                val uri = sent.single().data!!
                assertEquals("https", uri.scheme); assertEquals("www.google.com", uri.host)
                assertEquals("100 Main Street #2 & parking", uri.getQueryParameter("destination"))
                assertFalse(uri.queryParameterNames.contains("dir_action"))
                assertEquals(3, uri.queryParameterNames.size)
            } finally { h.close() }
        }
    }
    @Test fun missingHandlersAndDeniedContactsProduceHonestResults() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            val h = Harness(scenario, true); val results = h.results
            try {
                h.run(PhoneCommand.Text("2025550100", "test draft"))
                h.click(AlertDialog.BUTTON_POSITIVE)
                assertTrue(results.last().contains("Nothing was opened"))
                h.run(PhoneCommand.Dial("*#06#"))
                assertTrue(results.last().contains("Dial codes"))
                val context = InstrumentationRegistry.getInstrumentation().targetContext
                if (context.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    h.run(PhoneCommand.Dial("Velora Test Contact"))
                    // The permission rationale is shown before Android's permission prompt.
                    h.step { assertEquals("Allow contact lookup", h.actions.dialog!!.getButton(AlertDialog.BUTTON_POSITIVE).text.toString()) }
                    h.click(AlertDialog.BUTTON_NEGATIVE)
                    assertTrue(results.last().contains("No contacts read"))
                }
            } finally { h.close() }
        }
    }
    @Test fun installedAppsAreDiscoveredAndOnlyChosenComponentIsLaunched() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            var actions: PhoneActions? = null
            val sent = mutableListOf<Intent>()
            scenario.onActivity { activity ->
                actions = PhoneActions(activity, {}, { sent += it })
                val apps = actions!!.apps()
                assertTrue(apps.isNotEmpty())
                val settings = apps.first { it.component.packageName == "com.android.settings" }
                actions!!.run(PhoneCommand.OpenApp(settings.label))
            }
            val deadline = SystemClock.elapsedRealtime() + 5000
            var launched = false
            while (!launched && SystemClock.elapsedRealtime() < deadline) {
                SystemClock.sleep(50); scenario.onActivity { launched = sent.isNotEmpty() }
            }
            scenario.onActivity {
                try {
                    assertTrue(launched)
                    assertEquals("com.android.settings", sent.single().component!!.packageName)
                    assertEquals(Intent.ACTION_MAIN, sent.single().action)
                    assertTrue(sent.single().categories.contains(Intent.CATEGORY_LAUNCHER))
                } finally { actions!!.close() }
            }
        }
    }
    @Test fun namedContactsAreMatchedLocallyAndAmbiguousNamesRequireChoice() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val context = instrumentation.targetContext
        val automation = instrumentation.uiAutomation
        val rawIds = mutableListOf<Long>()
        // Test-emulator-only fixture; never run this suite on the user's phone.
        check(android.os.Build.FINGERPRINT.contains("generic") || android.os.Build.MODEL.contains("sdk"))
        automation.grantRuntimePermission(context.packageName, android.Manifest.permission.READ_CONTACTS)
        automation.adoptShellPermissionIdentity(android.Manifest.permission.WRITE_CONTACTS, android.Manifest.permission.READ_CONTACTS)
        try {
            for ((name, number) in listOf("VeloraFixture Alpha" to "2025550101", "VeloraFixture Beta" to "2025550102")) {
                val batch = arrayListOf(
                    ContentProviderOperation.newInsert(Raw.CONTENT_URI).withValue(Raw.ACCOUNT_TYPE, null).withValue(Raw.ACCOUNT_NAME, null).build(),
                    ContentProviderOperation.newInsert(ContactData.CONTENT_URI).withValueBackReference(ContactData.RAW_CONTACT_ID, 0)
                        .withValue(ContactData.MIMETYPE, StructuredName.CONTENT_ITEM_TYPE).withValue(StructuredName.DISPLAY_NAME, name).build(),
                    ContentProviderOperation.newInsert(ContactData.CONTENT_URI).withValueBackReference(ContactData.RAW_CONTACT_ID, 0)
                        .withValue(ContactData.MIMETYPE, Phone.CONTENT_ITEM_TYPE).withValue(Phone.NUMBER, number).withValue(Phone.TYPE, Phone.TYPE_MOBILE).build()
                )
                rawIds += ContentUris.parseId(context.contentResolver.applyBatch(ContactsContract.AUTHORITY, batch)[0].uri!!)
            }
            ActivityScenario.launch(MainActivity::class.java).use { scenario ->
                val h = Harness(scenario)
                try {
                    h.run(PhoneCommand.Dial("VeloraFixture"))
                    val end = SystemClock.elapsedRealtime() + 5000
                    var choices = 0
                    while (choices == 0 && SystemClock.elapsedRealtime() < end) {
                        SystemClock.sleep(50); h.step { choices = h.actions.dialog?.listView?.count ?: 0 }
                    }
                    assertEquals(2, choices); assertTrue(h.sent.isEmpty())
                    h.step { val list = h.actions.dialog!!.listView; list.performItemClick(list.getChildAt(1), 1, list.adapter.getItemId(1)) }
                    assertTrue(h.sent.isEmpty())
                    h.click(AlertDialog.BUTTON_POSITIVE)
                    assertEquals("tel:2025550102", h.sent.single().data.toString())
                } finally { h.close() }
            }
        } finally {
            rawIds.forEach { context.contentResolver.delete(ContentUris.withAppendedId(ContactsContract.RawContacts.CONTENT_URI, it), null, null) }
            automation.dropShellPermissionIdentity()
            // Revoking a runtime permission kills this instrumentation process. Gradle removes
            // the test app after the suite, which clears its grant. Never grant on a real phone.
        }
    }
    @Test fun typedPhoneRequestsStayLocalAndReceiptSurvivesRecreation() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            scenario.onActivity { activity ->
                val root = activity.findViewById<View>(android.R.id.content)
                root.findViewWithTag<EditText>("composer").setText("open Spotify and call Steve")
                root.findViewWithTag<Button>("send").performClick()
                assertTrue(root.findViewWithTag<TextView>("action-feedback").text.contains("Nothing was opened"))
                assertEquals(View.GONE, root.findViewWithTag<TextView>("transcript").visibility)
            }
            scenario.recreate()
            scenario.onActivity { activity ->
                val root = activity.findViewById<View>(android.R.id.content)
                assertTrue(root.findViewWithTag<TextView>("action-feedback").text.contains("Nothing was opened"))
                assertEquals(0, root.findViewWithTag<ScrollView>("conversation-scroll").scrollY)
            }
        }
    }
}
