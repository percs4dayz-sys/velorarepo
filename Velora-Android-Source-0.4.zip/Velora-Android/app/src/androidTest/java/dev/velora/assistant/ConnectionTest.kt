package dev.velora.assistant

import android.os.SystemClock
import android.view.View
import android.widget.*
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import org.json.JSONObject
import java.net.Socket

class ConnectionTest {
    private val context get()=InstrumentationRegistry.getInstrumentation().targetContext
    @Test fun repliesKeepPortraitPositionAndTranscriptIsOptIn() {
        context.getSharedPreferences("velora",0).edit().putBoolean("readAloud",false).commit()
        ActivityScenario.launch(MainActivity::class.java).use {scenario->
            InstrumentationRegistry.getInstrumentation().waitForIdleSync()
            scenario.onActivity {activity->
                val root=activity.findViewById<View>(android.R.id.content)
                assertEquals(View.GONE,root.findViewWithTag<TextView>("transcript").visibility)
                repeat(4) {
                    root.findViewWithTag<EditText>("composer").setText("look happy")
                    root.findViewWithTag<Button>("send").performClick()
                }
            }
            SystemClock.sleep(500)
            scenario.onActivity {activity->
                val root=activity.findViewById<View>(android.R.id.content)
                assertEquals(0,root.findViewWithTag<ScrollView>("conversation-scroll").scrollY)
                root.findViewWithTag<Button>("transcript-toggle").performClick()
                assertEquals(View.VISIBLE,root.findViewWithTag<TextView>("transcript").visibility)
            }
            SystemClock.sleep(200)
            scenario.onActivity {activity->
                val root=activity.findViewById<View>(android.R.id.content)
                root.findViewWithTag<ScrollView>("conversation-scroll").scrollTo(0,0)
                root.findViewWithTag<EditText>("composer").setText("look happy")
                root.findViewWithTag<Button>("send").performClick()
            }
            SystemClock.sleep(500)
            scenario.onActivity {activity->assertEquals(0,activity.findViewById<View>(android.R.id.content).findViewWithTag<ScrollView>("conversation-scroll").scrollY)}
        }
        context.getSharedPreferences("velora",0).edit().putBoolean("readAloud",true).commit()
    }
    @Test fun vaultEncryptsAndRoundTripsWithoutPlaintextCredentials() {
        // Isolated instrumentation storage, never the app's actual account vault.
        val testContext=object:android.content.ContextWrapper(context) {
            override fun getNoBackupFilesDir()=java.io.File(context.noBackupFilesDir,"vault-test").apply{mkdirs()}
        }
        val vault=PlanVault(testContext)
        val original=vault.read()
        try {
            vault.write(JSONObject().put("secret","test-only-fake-credential"))
            assertEquals("test-only-fake-credential",vault.read().getString("secret"))
            val bytes=java.io.File(testContext.noBackupFilesDir,"chatgpt-session.enc").readBytes()
            assertFalse(String(bytes).contains("test-only-fake-credential"))
        }finally{vault.write(original)}
    }
    @Test fun loopbackRejectsStrayStateAndAcceptsBoundDenialWithoutNetworkExchange() {
        val session=ChatGptSession.get(context)
        val uri=session.begin(null)
        val params=PlanProtocol.query(uri.encodedQuery!!)
        assertEquals("dynamic_agent_client",params["client_id"])
        assertEquals("Velora",params["agent_name_hint"])
        assertEquals("S256",params["code_challenge_method"])
        val callback=java.net.URI(params.getValue("redirect_uri"))
        assertEquals("127.0.0.1",callback.host)
        fun request(path:String):String=Socket(callback.host,callback.port).use{s->
            s.soTimeout=4000;s.getOutputStream().write("GET $path HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n".toByteArray());s.getInputStream().bufferedReader().readText()
        }
        try {
            assertTrue(request("/auth/callback?state=bad&code=unused&client_id=fake").startsWith("HTTP/1.1 400"))
            assertTrue(session.signingIn)
            request("/auth/callback?error=access_denied&state=${params.getValue("state")}")
            val end=SystemClock.elapsedRealtime()+4000
            while(session.signingIn&&SystemClock.elapsedRealtime()<end)SystemClock.sleep(50)
            assertFalse(session.signingIn)
            assertTrue(session.takeNotice().contains("declined"))
            val second=session.begin(null)
            assertEquals(params["ext_agent_host_id"],PlanProtocol.query(second.encodedQuery!!)["ext_agent_host_id"])
        }finally{session.cancelLogin()}
    }
}
