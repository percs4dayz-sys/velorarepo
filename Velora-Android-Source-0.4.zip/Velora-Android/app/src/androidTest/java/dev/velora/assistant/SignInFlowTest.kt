package dev.velora.assistant

import android.content.ContextWrapper
import android.os.SystemClock
import androidx.test.platform.app.InstrumentationRegistry
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.net.Socket
import java.net.URI
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.interfaces.RSAPublicKey
import java.util.UUID

/** Full local callback -> exchange -> validation -> storage -> model flow with fake credentials. */
class SignInFlowTest {
    private val context get()=InstrumentationRegistry.getInstrumentation().targetContext
    private fun isolatedContext():ContextWrapper {
        val folder=File(context.noBackupFilesDir,"auth-test-${UUID.randomUUID()}")
        return object:ContextWrapper(context){override fun getNoBackupFilesDir()=folder.apply{mkdirs()}}
    }
    private fun callback(params:Map<String,String>,suffix:String="&client_id=oaiapp_test"):String {
        val uri=URI(params.getValue("redirect_uri"))
        return Socket(uri.host,uri.port).use{s->
            s.soTimeout=5000
            s.getOutputStream().write("GET /auth/callback?code=FAKE_TEST_CODE&state=${params.getValue("state")}$suffix HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n".toByteArray())
            s.getInputStream().bufferedReader().readText()
        }
    }
    private fun finished(session:ChatGptSession){val deadline=SystemClock.elapsedRealtime()+8000;while(session.signingIn&&SystemClock.elapsedRealtime()<deadline)SystemClock.sleep(40);assertFalse("Local sign-in did not finish: ${session.connectionDetails()}",session.signingIn)}
    @Test fun successfulCallbackVerifiesSavesAndSelectsModelAcrossRecreation() {
        val testContext=isolatedContext()
        val pair=KeyPairGenerator.getInstance("RSA").apply{initialize(2048)}.generateKeyPair()
        val pub=pair.public as RSAPublicKey
        val keys=JSONObject().put("keys",JSONArray().put(JSONObject().put("kid","test").put("kty","RSA").put("alg","RS256").put("n",PlanProtocol.encode(pub.modulus.toByteArray())).put("e",PlanProtocol.encode(pub.publicExponent.toByteArray()))))
        var nonce="";var redirect="";var exchanges=0;var modelRequests=0
        val transport=PlanTransport {url,form,token->when {
            url.endsWith("/oauth/token")->{
                exchanges++;assertEquals("oaiapp_test",form!!["client_id"]);assertEquals(redirect,form["redirect_uri"])
                assertEquals("authorization_code",form["grant_type"]);assertTrue(form.getValue("code_verifier").length>=43)
                val now=System.currentTimeMillis()/1000
                val claims=JSONObject().put("iss",PlanProtocol.ISSUER).put("sub","test-user").put("aud","oaiapp_test").put("nonce",nonce).put("email","fake@example.test").put("iat",now).put("exp",now+3600)
                val data=PlanProtocol.encode("{\"alg\":\"RS256\",\"kid\":\"test\"}".toByteArray())+"."+PlanProtocol.encode(claims.toString().toByteArray())
                val signer=Signature.getInstance("SHA256withRSA").apply{initSign(pair.private);update(data.toByteArray())}
                JSONObject().put("access_token","FAKE_ACCESS").put("refresh_token","FAKE_REFRESH").put("id_token",data+"."+PlanProtocol.encode(signer.sign())).put("token_type","Bearer").put("expires_in",3600).put("scope",PlanProtocol.SCOPES)
            }
            url.endsWith("jwks.json")->keys
            url.endsWith("/models")->{modelRequests++;assertEquals("FAKE_ACCESS",token);JSONObject().put("models",JSONArray().put(JSONObject().put("visibility","list").put("slug","test-model").put("display_name","Test model")))}
            else->error("Unexpected endpoint")
        }}
        val session=ChatGptSession(testContext,transport)
        try {
            val params=PlanProtocol.query(session.begin(null).encodedQuery!!);nonce=params.getValue("nonce");redirect=params.getValue("redirect_uri")
            val page=callback(params)
            assertTrue(page.contains("Open Velora"));assertTrue(page.contains("still needs to verify"))
            SystemClock.sleep(300)
            assertEquals(0,exchanges)
            assertTrue(session.signingIn)
            session.setForeground(true)
            finished(session)
            assertEquals(1,exchanges);assertEquals(1,modelRequests)
            assertTrue(session.active()!!.signedIn);assertTrue(session.active()!!.permitted)
            assertEquals("test-model",session.model("oaiapp_test"))
            assertTrue(session.connectionMessage.contains("Ready to talk"))
            val restored=ChatGptSession(testContext,transport)
            assertTrue(restored.active()!!.signedIn);assertEquals("test-model",restored.model("oaiapp_test"))
            assertEquals(session.connectionMessage,restored.connectionMessage)
        }finally{session.cancelLogin()}
    }
    @Test fun exchangeFailureRemainsVisibleAfterNoticeConsumedAndProcessRecreation() {
        val testContext=isolatedContext()
        val transport=PlanTransport {_,_,_->throw PlanFailure(400,"invalid_grant","error object")}
        val session=ChatGptSession(testContext,transport)
        try {
            session.setForeground(true)
            callback(PlanProtocol.query(session.begin(null).encodedQuery!!));finished(session)
            assertNull(session.active());assertTrue(session.connectionDetails().contains("token exchange"))
            assertTrue(session.connectionDetails().contains("HTTP 400"));assertTrue(session.connectionDetails().contains("invalid_grant"))
            session.takeNotice()
            assertTrue(session.connectionMessage.isNotBlank())
            val restored=ChatGptSession(testContext,transport)
            assertEquals(session.connectionDetails(),restored.connectionDetails())
            assertFalse(restored.connectionDetails().contains("FAKE_TEST_CODE"))
        }finally{session.cancelLogin()}
    }
    @Test fun boundCallbackMissingClientFailsImmediatelyInsteadOfWaitingFiveMinutes() {
        val session=ChatGptSession(isolatedContext(),PlanTransport{_,_,_->error("Must not exchange")})
        try {
            callback(PlanProtocol.query(session.begin(null).encodedQuery!!),"");finished(session)
            assertTrue(session.connectionMessage.contains("Registration did not return a client ID"))
            assertNull(session.active())
        }finally{session.cancelLogin()}
    }
    @Test fun publicOpenAiMetadataCanBeFetchedFromAndroid() {
        // Public metadata only: no account, code, credentials, or inference request.
        val config=PlanHttp.json("${PlanProtocol.ISSUER}/.well-known/openid-configuration")
        assertEquals(PlanProtocol.ISSUER,config.getString("issuer"))
        val keys=PlanHttp.json(config.getString("jwks_uri"))
        assertTrue(keys.getJSONArray("keys").length()>0)
    }
}
