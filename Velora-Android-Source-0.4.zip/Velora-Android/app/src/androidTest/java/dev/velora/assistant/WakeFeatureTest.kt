package dev.velora.assistant

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import org.vosk.Model
import org.vosk.Recognizer
import java.nio.ByteBuffer
import java.nio.ByteOrder

class WakeFeatureTest {
    @Test fun foregroundListenerPausesAndOverlayStopsWithNotification() {
        // Never run device-state tests on a personal phone.
        org.junit.Assume.assumeTrue(android.os.Build.MODEL.contains("sdk") || android.os.Build.FINGERPRINT.contains("generic"))
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val context = instrumentation.targetContext
        val ui = instrumentation.uiAutomation
        fun shell(command: String) { ui.executeShellCommand(command).use { android.os.ParcelFileDescriptor.AutoCloseInputStream(it).readBytes() } }
        fun onMain(block: () -> Unit) = instrumentation.runOnMainSync(block)
        fun until(description: String, condition: () -> Boolean) {
            val deadline = android.os.SystemClock.elapsedRealtime() + 25000
            while (android.os.SystemClock.elapsedRealtime() < deadline) {
                var success = false; onMain { success = condition() }
                if (success) return
                Thread.sleep(100)
            }
            fail(description)
        }
        fun field(name: String): Any? = WakeService.current?.let { service -> WakeService::class.java.getDeclaredField(name).apply { isAccessible = true }.get(service) }
        shell("input keyevent KEYCODE_WAKEUP")
        shell("wm dismiss-keyguard")
        shell("pm grant ${context.packageName} android.permission.RECORD_AUDIO")
        shell("pm grant ${context.packageName} android.permission.POST_NOTIFICATIONS")
        shell("appops set ${context.packageName} SYSTEM_ALERT_WINDOW allow")
        val scenario = ActivityScenario.launch(MainActivity::class.java)
        try {
            scenario.onActivity { it.startForegroundService(android.content.Intent(it, WakeService::class.java)) }
            until("Listener did not load", { field("modelReady") == true })
            until("Listener must pause while main app is visible", { field("phase").toString() == "PAUSED" })
            scenario.moveToState(androidx.lifecycle.Lifecycle.State.CREATED)
            until("Listener did not arm outside app", { field("phase").toString() == "ARMED" })
            until("Microphone was not started", { context.getSystemService(android.media.AudioManager::class.java).activeRecordingConfigurations.isNotEmpty() })
            onMain { WakeService.current!!.showFloatingPreview() }
            until("Overlay was not attached", { (field("overlay") as? android.view.View)?.isAttachedToWindow == true })
            shell("input keyevent KEYCODE_SLEEP")
            until("Lock must hide overlay and pause listening", { field("phase").toString() == "PAUSED" && field("overlay") == null })
            until("Lock did not release microphone", { context.getSystemService(android.media.AudioManager::class.java).activeRecordingConfigurations.isEmpty() })
            shell("input keyevent KEYCODE_WAKEUP")
            shell("wm dismiss-keyguard")
            until("Listener did not resume after unlock", { field("phase").toString() == "ARMED" })
            scenario.moveToState(androidx.lifecycle.Lifecycle.State.RESUMED)
            until("Opening app must release microphone", { field("phase").toString() == "PAUSED" && context.getSystemService(android.media.AudioManager::class.java).activeRecordingConfigurations.isEmpty() })
            val notification = context.getSystemService(android.app.NotificationManager::class.java).activeNotifications.single { it.id == 41 }.notification
            notification.actions.single { it.title.toString() == "Stop listening" }.actionIntent.send()
            until("Notification Stop did not stop service", { WakeService.current == null })
        } finally {
            onMain { context.stopService(android.content.Intent(context, WakeService::class.java)) }
            scenario.close()
            shell("input keyevent KEYCODE_WAKEUP")
            shell("wm dismiss-keyguard")
            shell("appops set ${context.packageName} SYSTEM_ALERT_WINDOW default")
        }
    }
    @Test fun floatingPortraitHasRealTransparencyAndDistinctMouthFrames() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario -> scenario.onActivity { activity ->
            val portrait = FloatingPortrait(activity)
            portrait.layout(0, 0, 300, 300)
            val closed = Bitmap.createBitmap(300, 300, Bitmap.Config.ARGB_8888)
            portrait.draw(Canvas(closed))
            assertEquals(0, android.graphics.Color.alpha(closed.getPixel(0, 0)))
            assertTrue(android.graphics.Color.alpha(closed.getPixel(150, 150)) > 200)
            portrait.mouth = 3
            val open = Bitmap.createBitmap(300, 300, Bitmap.Config.ARGB_8888)
            portrait.draw(Canvas(open))
            assertFalse(open.sameAs(closed))
        } }
    }
    @Test fun bundledOfflineModelRecognizesSyntheticHeyV() {
        val instrumentation = InstrumentationRegistry.getInstrumentation()
        val context = instrumentation.targetContext
        val bytes = instrumentation.context.assets.open("hey-v.wav").use { it.readBytes() }
        val b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        var pos = 12; var offset = 0; var length = 0; var rate = 0
        while (pos + 8 <= bytes.size) {
            val name = String(bytes, pos, 4, Charsets.US_ASCII); val size = b.getInt(pos + 4)
            if (name == "fmt ") rate = b.getInt(pos + 12)
            if (name == "data") { offset = pos + 8; length = size; break }
            pos += 8 + size + (size % 2)
        }
        assertEquals(16000, rate); assertTrue(length > 0)
        Model(OfflineWakeEngine.modelDirectory(context).absolutePath).use { model ->
            Recognizer(model, 16000f, WakePhrase.GRAMMAR).use { recognizer ->
                recognizer.setWords(true)
                recognizer.acceptWaveForm(bytes.copyOfRange(offset, offset + length), length)
                val result = recognizer.finalResult
                assertTrue("Synthetic wake phrase was not recognized: $result", WakePhrase.matches(result))
            }
        }
    }
}
