package dev.velora.assistant

import android.graphics.Bitmap
import android.content.ContentValues
import android.provider.MediaStore
import android.os.SystemClock
import android.view.View
import android.widget.*
import androidx.test.core.app.ActivityScenario
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import java.io.File

class NativeSmokeTest {
    private fun waitFor(scenario:ActivityScenario<MainActivity>,predicate:(MainActivity)->Boolean) {
        val deadline=SystemClock.elapsedRealtime()+8000
        do {var result=false;scenario.onActivity{result=predicate(it)};if(result)return;SystemClock.sleep(100)} while(SystemClock.elapsedRealtime()<deadline)
        fail("Timed out waiting for native playback state")
    }
    @Test fun portraitRendersAndEmotesSwitch() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            waitFor(scenario){it.findViewById<View>(android.R.id.content).findViewWithTag<PortraitView>("portrait").width>0}
            scenario.onActivity {activity->
                val root=activity.findViewById<View>(android.R.id.content)
                val portrait=root.findViewWithTag<PortraitView>("portrait")
                root.findViewWithTag<Button>("emote-angry").performClick()
                assertEquals("angry",portrait.expression)
                root.findViewWithTag<Button>("emote-neutral").performClick()
                assertEquals("neutral",portrait.expression)
                assertTrue(portrait.height>200)
            }
        }
    }
    @Test fun sampleMovesMouthAndStopRestoresIdle() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            scenario.onActivity {it.findViewById<View>(android.R.id.content).findViewWithTag<Button>("sample").performClick()}
            waitFor(scenario){it.findViewById<View>(android.R.id.content).findViewWithTag<PortraitView>("portrait").mouth!=null}
            waitFor(scenario){(it.findViewById<View>(android.R.id.content).findViewWithTag<PortraitView>("portrait").mouth?:0)>0}
            scenario.onActivity {activity->
                val root=activity.findViewById<View>(android.R.id.content)
                assertTrue(root.findViewWithTag<TextView>("status").text.contains("Speaking"))
                root.findViewWithTag<Button>("stop").performClick()
                assertNull(root.findViewWithTag<PortraitView>("portrait").mouth)
                assertEquals("Here when you’re ready",root.findViewWithTag<TextView>("status").text.toString())
            }
            InstrumentationRegistry.getInstrumentation().waitForIdleSync()
            val screen=InstrumentationRegistry.getInstrumentation().uiAutomation.takeScreenshot()
            assertNotNull(screen)
            val context=InstrumentationRegistry.getInstrumentation().targetContext
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val values=ContentValues().apply {put(MediaStore.Images.Media.DISPLAY_NAME,"Velora-native.png");put(MediaStore.Images.Media.MIME_TYPE,"image/png");put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Velora")}
                val uri=context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values)!!
                context.contentResolver.openOutputStream(uri)!!.use {screen.compress(Bitmap.CompressFormat.PNG,100,it)}
            }
        }
    }
    @Test fun typedNegationCannotLaunchTimer() {
        val context=InstrumentationRegistry.getInstrumentation().targetContext
        context.getSharedPreferences("velora",0).edit().putBoolean("readAloud",false).commit()
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->scenario.onActivity {activity->
            val root=activity.findViewById<View>(android.R.id.content)
            root.findViewWithTag<EditText>("composer").setText("do not set a 10 minute timer")
            root.findViewWithTag<Button>("send").performClick()
            assertTrue(root.findViewWithTag<TextView>("transcript").text.contains("No device action taken."))
        } }
        context.getSharedPreferences("velora",0).edit().putBoolean("readAloud",true).commit()
    }
}
