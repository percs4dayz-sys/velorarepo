package dev.velora.assistant

import org.junit.Assert.*
import org.junit.Test
import java.nio.ByteBuffer
import java.nio.ByteOrder

class NativeLogicTest {
    @Test fun timerPreservesDurationAndBlocksInvalidRanges() {
        assertEquals(LocalCommand.Timer(2700),LocalCommands.parse("Velora, set a 45 minute timer"))
        assertEquals(LocalCommand.Timer(9),LocalCommands.parse("start a 9 second timer"))
        assertTrue(LocalCommands.parse("set a 0 second timer") is LocalCommand.Message)
        assertTrue(LocalCommands.parse("set a 999999999999999999999 hour timer") is LocalCommand.Message)
        assertTrue(LocalCommands.parse("set a 25 hour timer") is LocalCommand.Message)
    }
    @Test fun negatedAndCompoundCommandsDoNotExecute() {
        assertTrue(LocalCommands.parse("do not set a 10 minute timer") is LocalCommand.Message)
        assertTrue(LocalCommands.parse("set a 10 minute timer and lock my PC") is LocalCommand.Message)
        assertTrue(LocalCommands.parse("unlock my PC") is LocalCommand.Message)
        assertEquals(LocalCommand.Chat,LocalCommands.parse("How do timers work?"))
    }
    @Test fun emotesAndStopAreExplicit() {
        assertEquals(LocalCommand.Emote("happy"),LocalCommands.parse("look happy"))
        assertEquals(LocalCommand.Stop,LocalCommands.parse("stop speaking"))
        assertEquals(LocalCommand.Chat,LocalCommands.parse("What is your name?"))
    }
    @Test fun audioEnvelopeFollowsPlaybackAndReturnsToRest() {
        val samples=ShortArray(1600) { if(it<800)0 else 16000 }
        val bytes=ByteBuffer.allocate(44+samples.size*2).order(ByteOrder.LITTLE_ENDIAN)
        bytes.put("RIFF".toByteArray()).putInt(bytes.capacity()-8).put("WAVEfmt ".toByteArray()).putInt(16).putShort(1).putShort(1).putInt(16000).putInt(32000).putShort(2).putShort(16).put("data".toByteArray()).putInt(samples.size*2)
        samples.forEach{bytes.putShort(it)}
        val envelope=WaveEnvelope.parse(bytes.array())
        assertEquals(0,envelope.frameAt(0));assertEquals(3,envelope.frameAt(50));assertEquals(0,envelope.frameAt(5000))
        val fourLevels = WaveEnvelope(floatArrayOf(0f, .03f, .1f, .3f))
        assertEquals(listOf(0, 1, 2, 3), listOf(0, 50, 100, 150).map(fourLevels::frameAt))
    }
    @Test fun malformedAudioIsRejected() {
        assertThrows(IllegalArgumentException::class.java){WaveEnvelope.parse(ByteArray(44))}
    }
}
