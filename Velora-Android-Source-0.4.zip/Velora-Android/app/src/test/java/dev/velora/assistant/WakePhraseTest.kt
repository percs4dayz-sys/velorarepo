package dev.velora.assistant

import org.junit.Assert.*
import org.junit.Test

class WakePhraseTest {
    private fun result(text: String, a: Double = .95, b: Double = .95) = """{"text":"$text","result":[{"conf":$a},{"conf":$b}]}"""
    @Test fun onlyTheFullConfidentPhraseWakes() {
        assertTrue(WakePhrase.matches(result("hey v")))
        assertTrue(WakePhrase.matches(result("Hey Vee")))
        for (text in listOf("hey", "v", "heavy", "maybe", "hey steve", "[unk] hey v", "hey v open settings")) assertFalse(text, WakePhrase.matches(result(text)))
        assertFalse(WakePhrase.matches(result("hey v", .2, .99)))
        assertFalse(WakePhrase.matches(result("hey v", .7, .7)))
    }
    @Test fun PartialOrMalformedResultsCannotWake() {
        assertFalse(WakePhrase.matches("""{"partial":"hey v"}"""))
        assertFalse(WakePhrase.matches("""{"text":"hey v"}"""))
        assertFalse(WakePhrase.matches("broken"))
    }
}
