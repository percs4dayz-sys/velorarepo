package dev.velora.assistant

import org.junit.Assert.*
import org.junit.Test

class PhoneCommandsTest {
    @Test fun naturalRequestsRouteLocally() {
        assertEquals(LocalCommand.Phone(PhoneCommand.OpenApp("Spotify")), LocalCommands.parse("Hey Velora, could you please open Spotify?"))
        assertEquals(LocalCommand.Phone(PhoneCommand.Dial("Steve")), LocalCommands.parse("call Steve"))
        assertEquals(LocalCommand.Phone(PhoneCommand.Navigate("home")), LocalCommands.parse("navigate home"))
        assertEquals(LocalCommand.Phone(PhoneCommand.Navigate("Central Park")), LocalCommands.parse("take me to Central Park"))
        assertEquals(LocalCommand.Chat, LocalCommands.parse("How do I open Spotify on Android?"))
        assertEquals(LocalCommand.Phone(PhoneCommand.Help), LocalCommands.parse("what can you do on my phone?"))
    }
    @Test fun textIsLiteralAndPreservesCaseAndPunctuation() {
        assertEquals(PhoneCommand.Text("Steve", "Don't wait, call me!"), PhoneCommands.parse("text Steve saying Don't wait, call me!"))
        assertEquals(PhoneCommand.Text("+1 (202) 555-0100", "Open Spotify and delete NOTHING."), PhoneCommands.parse("send a text to +1 (202) 555-0100 saying Open Spotify and delete NOTHING."))
        assertEquals(PhoneCommand.Text("Alex", "I'll be there at 8:30?"), PhoneCommands.parse("message Alex: I'll be there at 8:30?"))
        assertEquals(PhoneCommand.Text("Steve", ""), PhoneCommands.parse("text Steve"))
    }
    @Test fun negationAndMultipleActionsCannotExecute() {
        for (text in listOf("don't open Spotify", "please do not call Steve", "Velora, don’t text Steve saying hello", "cancel navigation")) {
            assertTrue(text, LocalCommands.parse(text) is LocalCommand.Message)
        }
        for (text in listOf("open Spotify and call Steve", "call Steve then text Mom", "navigate to home; delete photos", "open intent://bad", "open Spotify\ncall Steve", "call Steve instead")) {
            assertTrue(text, (LocalCommands.parse(text) as? LocalCommand.Phone)?.action is PhoneCommand.Rejected)
        }
    }
    @Test fun numbersCannotBecomeDialCodesOrUriParameters() {
        assertEquals("+12025550100", PhoneCommands.phoneNumber("+1 (202) 555-0100"))
        for (value in listOf("*#06#", "123;456", "123?body=evil", "1+2345", "12", "1234567890123456", "Steve")) assertNull(value, PhoneCommands.phoneNumber(value))
    }
    @Test fun exactNamesWinAndAmbiguityIsPreserved() {
        val names = listOf("Steve Jones", "Steve Smith", "Steven Lewis", "Steve")
        assertEquals(listOf("Steve"), PhoneCommands.matches("steve", names) { it })
        assertEquals(listOf("Steve Jones", "Steve Smith"), PhoneCommands.matches("Steve", names.dropLast(1)) { it })
        assertEquals(emptyList<String>(), PhoneCommands.matches("Ste", names) { it })
        assertEquals(listOf("Messages", "Messages"), PhoneCommands.matches("messages", listOf("Messages", "Messages")) { it })
    }
    @Test fun malformedActionsAreNotChatOrPartialExecution() {
        for (text in listOf("call", "text", "navigate", "send money", "draft")) assertTrue(text, PhoneCommands.parse(text) is PhoneCommand.Rejected)
        assertTrue(PhoneCommands.parse("text Steve saying " + "x".repeat(2001)) is PhoneCommand.Rejected)
        assertTrue(LocalCommands.parse("start a five minute timer") is LocalCommand.Message)
    }
}
