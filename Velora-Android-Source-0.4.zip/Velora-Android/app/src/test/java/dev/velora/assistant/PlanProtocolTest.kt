package dev.velora.assistant

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.security.KeyPairGenerator
import java.security.Signature
import java.security.interfaces.RSAPublicKey

class PlanProtocolTest {
    private val client="oaiapp_test"
    private val pair=KeyPairGenerator.getInstance("RSA").apply{initialize(2048)}.generateKeyPair()
    private fun keys():JSONObject {
        val pub=pair.public as RSAPublicKey
        return JSONObject().put("keys",JSONArray().put(JSONObject().put("kid","test").put("kty","RSA").put("alg","RS256").put("n",PlanProtocol.encode(pub.modulus.toByteArray())).put("e",PlanProtocol.encode(pub.publicExponent.toByteArray()))))
    }
    private fun claims()=JSONObject().put("iss",PlanProtocol.ISSUER).put("aud",client).put("sub","user-test").put("nonce","expected-nonce").put("exp",2000).put("iat",900)
    private fun signed(c:JSONObject,algorithm:String="RS256"):String {
        val header=JSONObject().put("alg",algorithm).put("kid","test")
        val data=PlanProtocol.encode(header.toString().toByteArray())+"."+PlanProtocol.encode(c.toString().toByteArray())
        val signer=Signature.getInstance("SHA256withRSA");signer.initSign(pair.private);signer.update(data.toByteArray())
        return data+"."+PlanProtocol.encode(signer.sign())
    }
    private fun validate(c:JSONObject)=PlanProtocol.verifyId(signed(c),keys(),client,"expected-nonce",now=1000)
    @Test fun validSignatureAndIdentityAreRequired() {
        assertEquals("user-test",validate(claims()).getString("sub"))
        val original=signed(claims());val chunks=original.split('.').toMutableList()
        chunks[1]=PlanProtocol.encode(claims().put("sub","attacker").toString().toByteArray())
        assertThrows(IllegalArgumentException::class.java){PlanProtocol.verifyId(chunks.joinToString("."),keys(),client,"expected-nonce",now=1000)}
        assertThrows(IllegalArgumentException::class.java){PlanProtocol.verifyId(signed(claims(),"none"),keys(),client,"expected-nonce",now=1000)}
    }
    @Test fun identityRejectsWrongAudienceIssuerNonceAndExpiry() {
        for((key,value) in listOf("aud" to "another-client","iss" to "https://attacker.example","nonce" to "wrong","exp" to 999,"nbf" to 2000,"azp" to "another-client")) {
            assertThrows(IllegalArgumentException::class.java){validate(claims().put(key,value))}
        }
        assertThrows(IllegalArgumentException::class.java){PlanProtocol.verifyId(signed(claims()),keys(),client,"expected-nonce","different-user",1000)}
    }
    @Test fun callbackBindsStatePathAndClient() {
        assertEquals("abc" to client,PlanProtocol.callback("/auth/callback?code=abc&state=ok&client_id=$client","ok",null))
        assertEquals("abc" to client,PlanProtocol.callback("/auth/callback?code=abc&state=ok","ok",client))
        for(target in listOf("/callback?code=abc&state=ok&client_id=$client","/auth/callback?code=abc&state=bad&client_id=$client","/auth/callback?code=abc&state=ok&state=ok&client_id=$client","/auth/callback?code=abc&state=ok","/auth/callback?code=abc&state=ok&client_id=dynamic_agent_client")) {
            assertThrows(IllegalArgumentException::class.java){PlanProtocol.callback(target,"ok",null)}
        }
        assertThrows(IllegalArgumentException::class.java){PlanProtocol.callback("/auth/callback?code=abc&state=ok&client_id=other","ok",client)}
        assertThrows(IllegalStateException::class.java){PlanProtocol.callback("/auth/callback?error=access_denied&state=ok","ok",client)}
    }
    @Test fun pkceMatchesPublishedTestVector() {
        assertEquals("E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM",PlanProtocol.challenge("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk"))
        assertNotEquals(PlanProtocol.random(),PlanProtocol.random())
    }
    private fun delta(text:String)="data: "+JSONObject().put("type","response.output_text.delta").put("delta",text)+"\n\n"
    private val done="data: {\"type\":\"response.completed\",\"response\":{\"status\":\"completed\"}}\n\n"
    @Test fun streamingRequiresCompletionAndHandlesUtf8() {
        val updates=mutableListOf<String>()
        assertEquals("Hi 🌸",PlanProtocol.readStream((": ping\n\n"+delta("Hi ")+delta("🌸")+done).reader().buffered(),{false}){updates.add(it)})
        assertEquals(listOf("Hi ","Hi 🌸"),updates)
        assertThrows(IllegalStateException::class.java){PlanProtocol.readStream(delta("partial").reader().buffered(),{false}){}}
        assertThrows(InterruptedException::class.java){PlanProtocol.readStream((delta("a")+done).reader().buffered(),{true}){}}
    }
    @Test fun streamedUsageFailureAndIncompleteAreNotSuccess() {
        val failed=delta("Partial")+"data: {\"type\":\"response.failed\",\"response\":{\"error\":{\"code\":\"subscription_sharing_usage_limit_exceeded\"}}}\n\n"
        val e=assertThrows(PlanFailure::class.java){PlanProtocol.readStream(failed.reader().buffered(),{false}){}}
        assertTrue(e.message!!.contains("Manage usage"))
        assertThrows(IllegalStateException::class.java){PlanProtocol.readStream((delta("Partial")+"data: {\"type\":\"response.incomplete\"}\n\n").reader().buffered(),{false}){}}
    }
    @Test fun requestUsesPlanCompatibleFieldsAndBoundedHistory() {
        val request=PlanProtocol.request("account-model",List(20){"assistant" to "prior"},"hello")
        assertFalse(request.getBoolean("store"));assertTrue(request.getBoolean("stream"))
        assertEquals(13,request.getJSONArray("input").length())
        assertEquals(setOf("model","store","stream","input","instructions"),request.keys().asSequence().toSet())
        assertFalse(request.toString().contains("\"role\":\"system\""))
    }
    @Test fun admissionErrorsAreHandledWithoutAssumingApiShape() {
        assertEquals("detail",PlanFailure.from(403,"{\"detail\":\"restricted\"}").shape)
        assertEquals("invalid_grant",PlanFailure.from(400,"{\"error\":\"invalid_grant\"}").code)
        assertTrue(PlanFailure.from(503,"not JSON").message!!.contains("unavailable"))
    }
}
