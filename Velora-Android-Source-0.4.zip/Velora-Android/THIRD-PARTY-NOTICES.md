# Native speech dependencies

- Vosk Android 0.3.75, Alpha Cephei and contributors: https://github.com/alphacep/vosk-api . Used unmodified under Apache-2.0. License packaged in `app/src/main/assets/licenses/Vosk-Apache-2.0.txt`.
- Vosk small English (US) model 0.15: https://alphacephei.com/vosk/models . Apache-2.0 according to the model listing. Bundled unchanged as `wake-model.zip`; source download https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip . SHA-256: `30f26242c4eb449f948e42cb302dd7a686cb29a3423a8367f99ff41780942498`.
- Java Native Access 5.18.1 and its contributors: https://github.com/java-native-access/jna/tree/5.18.1 . Dual-licensed Apache-2.0 OR LGPL-2.1-or-later; this distribution uses the Apache-2.0 option. Upstream LICENSE and Apache license text are packaged in `app/src/main/assets/licenses/`.

The native dependencies and speech model are not Velora-authored assets. NekoSpeak is a separate installed Android application, not bundled or incorporated into this APK. Its engine and model licenses remain separate.

Portrait references were supplied by the user. Desktop originals were copied without pixel edits into the main portrait's four mouth slots. The floating PNG is an AI-generated transparent derivative of all four references, created with the imagegen edit tool; it is not a pixel-exact extraction. See `PORTRAIT-ASSETS.md` for provenance.
